DRIMAH MESHTOOLS 1.9

CONTENTS
- Integrated add-on: Drimah MeshTools 1.9.
- Modules: Inflate, Relax, and X-Ray.
- X-Ray includes adaptive quad edge-loop detection, progress status text, and a diagnostic report.
- User-facing interface language is English.

INSTALLATION
1. Close Blender completely before replacing an earlier package.
2. Install Drimah_MeshTools_1.9.zip from Blender Preferences / Extensions area.
3. Enable Drimah MeshTools.
4. In the 3D Viewport, press N and open the Drimah MeshTools tab.

X-RAY ADAPTIVE LOOPS
X-Ray compares quad edges against local transverse spacing, includes boundary edges as valid
ring seeds/members for open panel strips, traces opposite-edge rings through quad faces, and
estimates cut count from the ring-wide median ratio. Boundary-edge scoring is intended to
recover long strips near spoiler bases and panel rims that the prior version could skip. It avoids stopping solely because a ring touches
a marked-sharp vertex, since that over-protected many hard-surface meshes.

X-RAY DIAGNOSTIC TEST IN 1.6
The X-Ray Fix temporarily bypasses the _repair_quad_flow post-processing pass to isolate whether
that pass is responsible for unwanted topology changes. Loop detection and insertion remain enabled.
This is a diagnostic build, not a confirmed final fix.

LIMITATIONS / TESTING
The algorithm is heuristic and targets continuous quad regions. It does not solve arbitrary
retopology, and it may skip regions with triangles, poles, open/non-manifold topology, or
strongly uneven ring lengths. The package and Python syntax were checked, but the add-on
has not been run inside Blender 5.2 in this environment. Test on a duplicate mesh first.


X-RAY DIAGNOSTIC TEST IN 1.7
This build keeps the 1.6 diagnostic bypass of _repair_quad_flow and changes only subdivide_edges(use_grid_fill=False), to test whether grid-fill behavior causes unwanted topology changes. Loop detection, candidate selection, and cut counts remain unchanged. This is a diagnostic build, not a confirmed final fix.


X-RAY DIAGNOSTIC TEST IN 1.8
This build replaces connected face-region edge aggregation with opposite-edge ring tracing. It rejects rings with low candidate coverage or highly inconsistent edge lengths, and uses median candidate-face aspect ratio to estimate cuts. This is experimental; test on a duplicate mesh. Blender runtime testing was not available during packaging.


X-RAY DIAGNOSTIC TEST IN 1.9
This build keeps the 1.8 opposite-edge ring tracing but reduces collateral subdivision: a ring must have at least 85% overlap with edges independently identified as candidates, ring edge-length variation is limited to 3:1, the trace limit is 512 edges, and inserted cuts are capped at 3 per ring. The intent is to preserve the improvement around the spoiler while rejecting rings that extend through healthy regions. This is an experimental hypothesis, not a Blender-runtime-verified fix. Test on a duplicate mesh.


X-RAY TEST VARIANT (SAME VERSION 1.9)
This same-version experiment makes candidate selection more conservative: the face aspect-ratio threshold is raised from 1.9 to 2.4 and faces with strongly unequal short-side lengths are skipped. The purpose is to test whether the upper strip was selected merely for being elongated. This may also skip needed loops, so compare spoiler-base results carefully. It is not a confirmed fix and has not been runtime-tested in Blender.


X-RAY ADDITIONAL LOOPS CONTROL (1.9 same-version test)
- Added one field: Additional Loops.
- Default is 2, adding two extra cuts to each accepted ring, while retaining the conservative candidate selection.
- The value is included in custom preset save/import/export.
- Maximum cuts per accepted ring is capped at 8 to limit accidental extreme density.
- Not runtime-tested inside Blender in this environment. Test on a duplicate of the kart mesh.
