bl_info = {
    "name": "Drimah Inflate",
    "author": "Drimah Tools",
    "version": (1, 0, 0),
    "blender": (3, 3, 0),
    "location": "View3D > Sidebar > Inflate",
    "description": "Mesh inflation with manageable presets",
    "category": "Mesh",
}

import bpy
import bmesh
import json
import os
import re
from bpy.props import FloatProperty, EnumProperty, IntProperty, StringProperty
from bpy_extras.io_utils import ImportHelper, ExportHelper
from mathutils import Vector

PRESET_FILE = "presets.json"
_ENUM_ITEMS_CACHE = []
BUILTIN_PRESETS = {
    "SUBTLE": {"label": "Subtle", "intensity": 0.03, "smoothness": 2},
    "SOFT": {"label": "Soft", "intensity": 0.10, "smoothness": 3},
    "PLUSH": {"label": "Plush", "intensity": 0.20, "smoothness": 5},
    "CUSHION": {"label": "Cushion", "intensity": 0.35, "smoothness": 6},
}

def preset_directory():
    path = bpy.utils.user_resource('CONFIG', path="drimah_inflate", create=True)
    return path or bpy.utils.resource_path('USER')

def preset_path():
    return os.path.join(preset_directory(), PRESET_FILE)

def load_custom_presets():
    path = preset_path()
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            cleaned = {}
            for key, value in data.items():
                if (isinstance(key, str) and isinstance(value, dict)
                    and isinstance(value.get("label"), str)
                    and isinstance(value.get("intensity"), (int, float))
                    and isinstance(value.get("smoothness"), int)):
                    cleaned[key] = {
                        "label": value["label"][:64],
                        "intensity": max(0.0001, min(10.0, float(value["intensity"]))),
                        "smoothness": max(1, min(12, int(value["smoothness"]))),
                    }
            return cleaned
    except (OSError, ValueError, TypeError):
        pass
    return {}

def write_custom_presets(data):
    os.makedirs(preset_directory(), exist_ok=True)
    with open(preset_path(), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def enum_presets(self, context):
    global _ENUM_ITEMS_CACHE
    items = [(k, v["label"], "Drimah Inflate preset") for k, v in BUILTIN_PRESETS.items()]
    for key, value in sorted(load_custom_presets().items(), key=lambda item: item[1]["label"].lower()):
        items.append((key, value["label"], "Custom preset"))
    items.append(("CUSTOM", "Custom", "Use current values"))
    # Blender may retain pointers to strings from dynamic enum items.
    _ENUM_ITEMS_CACHE = items
    return _ENUM_ITEMS_CACHE

def preset_update(self, context):
    key = self.drimah_inflate_preset
    value = BUILTIN_PRESETS.get(key) or load_custom_presets().get(key)
    if value:
        self.drimah_inflate_intensity = value["intensity"]
        self.drimah_inflate_smoothness = value["smoothness"]

def refresh_preset_enum():
    try:
        bpy.types.Scene.drimah_inflate_preset = EnumProperty(
            name="Preset", items=enum_presets, update=preset_update
        )
    except Exception:
        pass

def set_processing(context, active):
    try:
        if context.workspace:
            context.workspace.status_text_set("Please wait... Processing..." if active else None)
    except Exception:
        pass

class DMT12_DRIMAHINFLATE_OT_inflate(bpy.types.Operator):
    bl_idname = "dmt12_inflate.inflate"
    bl_label = "Inflate"
    bl_description = "Inflate the current selection"
    bl_options = {'REGISTER', 'UNDO'}

    intensity: FloatProperty(name="Intensity", default=0.10, min=0.0001, max=10.0, soft_min=0.001, soft_max=1.0, unit='LENGTH')
    smoothness: IntProperty(name="Smoothness", default=3, min=1, max=12)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.mode in {'OBJECT', 'EDIT'}

    def execute(self, context):
        obj = context.active_object
        edit_mode = obj.mode == 'EDIT'
        bm = bmesh.from_edit_mesh(obj.data) if edit_mode else bmesh.new()
        if not edit_mode:
            bm.from_mesh(obj.data)
        try:
            bm.normal_update()
            faces = [f for f in bm.faces if f.select] if edit_mode else []
            edges = [e for e in bm.edges if e.select] if edit_mode else []
            set_processing(context, True)
            try:
                if faces:
                    verts = {v for f in faces for v in f.verts}
                    normals = {}
                    for v in verts:
                        n = Vector((0.0, 0.0, 0.0))
                        for f in v.link_faces:
                            if f.select:
                                n += f.normal
                        normals[v] = n.normalized() if n.length else v.normal.copy()
                    for v in verts:
                        v.co += normals[v] * self.intensity
                    if self.smoothness > 1 and len(verts) > 3:
                        bmesh.ops.smooth_vert(
                            bm, verts=list(verts),
                            factor=min(0.35, (self.smoothness - 1) * 0.025),
                            use_axis_x=True, use_axis_y=True, use_axis_z=True
                        )
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                elif edges:
                    bmesh.ops.bevel(
                        bm, geom=edges, offset=self.intensity, offset_type='OFFSET',
                        segments=self.smoothness, profile=0.5, affect='EDGES',
                        clamp_overlap=True
                    )
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=True)
                else:
                    verts = set(bm.verts)
                    for v in verts:
                        v.co += v.normal * self.intensity
                    bm.to_mesh(obj.data)
                    obj.data.update()
            finally:
                set_processing(context, False)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, f"Drimah Inflate: {exc}")
            return {'CANCELLED'}
        finally:
            if not edit_mode:
                bm.free()

class DMT12_DRIMAHINFLATE_OT_save_preset(bpy.types.Operator):
    bl_idname = "drimah_inflate.save_preset"
    bl_label = "Save Preset"
    bl_description = "Save the current intensity and smoothness as a preset"
    name: StringProperty(name="Preset Name", default="My Preset", maxlen=64)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):
        # Campo sem rótulo: o título da janela já deixa claro que é um novo preset.
        self.layout.prop(self, "name", text="")

    def execute(self, context):
        label = self.name.strip()
        if not label:
            self.report({'WARNING'}, "Enter a preset name.")
            return {'CANCELLED'}
        key = "CUSTOM_" + re.sub(r'[^A-Z0-9]+', '_', label.upper()).strip('_')[:40]
        if not key or key == "CUSTOM_":
            key = "CUSTOM_PRESET"
        data = load_custom_presets()
        data[key] = {
            "label": label,
            "intensity": float(context.scene.drimah_inflate_intensity),
            "smoothness": int(context.scene.drimah_inflate_smoothness),
        }
        try:
            write_custom_presets(data)
        except OSError as exc:
            self.report({'ERROR'}, f"Could not save: {exc}")
            return {'CANCELLED'}
        refresh_preset_enum()
        context.scene.drimah_inflate_preset = key
        self.report({'INFO'}, "Preset saved.")
        return {'FINISHED'}

class DMT12_DRIMAHINFLATE_OT_delete_preset(bpy.types.Operator):
    bl_idname = "drimah_inflate.delete_preset"
    bl_label = "Delete Preset"
    bl_description = "Delete the selected custom preset"

    @classmethod
    def poll(cls, context):
        return context.scene.drimah_inflate_preset in load_custom_presets()

    def execute(self, context):
        key = context.scene.drimah_inflate_preset
        data = load_custom_presets()
        if key not in data:
            self.report({'WARNING'}, "Select a custom preset.")
            return {'CANCELLED'}
        del data[key]
        try:
            write_custom_presets(data)
        except OSError as exc:
            self.report({'ERROR'}, f"Could not delete: {exc}")
            return {'CANCELLED'}
        refresh_preset_enum()
        context.scene.drimah_inflate_preset = 'SOFT'
        return {'FINISHED'}

class DMT12_DRIMAHINFLATE_OT_export_presets(bpy.types.Operator, ExportHelper):
    bl_idname = "drimah_inflate.export_presets"
    bl_label = "Export Presets"
    bl_description = "Export custom presets to a JSON file"
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(load_custom_presets(), f, ensure_ascii=False, indent=2)
            self.report({'INFO'}, "Presets exported.")
            return {'FINISHED'}
        except OSError as exc:
            self.report({'ERROR'}, f"Export failed: {exc}")
            return {'CANCELLED'}

class DMT12_DRIMAHINFLATE_OT_import_presets(bpy.types.Operator, ImportHelper):
    bl_idname = "drimah_inflate.import_presets"
    bl_label = "Import Presets"
    bl_description = "Import custom presets from a JSON file"
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                incoming = json.load(f)
            if not isinstance(incoming, dict):
                raise ValueError("Invalid file format")
            existing = load_custom_presets()
            for key, value in incoming.items():
                if not isinstance(key, str) or not isinstance(value, dict):
                    continue
                label = value.get("label")
                intensity = value.get("intensity")
                smoothness = value.get("smoothness")
                if not isinstance(label, str) or not isinstance(intensity, (int, float)) or not isinstance(smoothness, int):
                    continue
                safe_key = re.sub(r'[^A-Z0-9_]+', '_', key.upper())[:48] or "IMPORTED"
                existing[safe_key] = {
                    "label": label[:64],
                    "intensity": max(0.0001, min(10.0, float(intensity))),
                    "smoothness": max(1, min(12, int(smoothness))),
                }
            write_custom_presets(existing)
            refresh_preset_enum()
            self.report({'INFO'}, "Presets imported.")
            return {'FINISHED'}
        except (OSError, ValueError, TypeError) as exc:
            self.report({'ERROR'}, f"Could not import: {exc}")
            return {'CANCELLED'}

class DMT12_DRIMAHINFLATE_PT_panel(bpy.types.Panel):
    bl_label = "Inflate"
    bl_idname = "DMT12_DRIMAHINFLATE_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Inflate"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.prop(scene, "drimah_inflate_preset", text="Preset")
        layout.prop(scene, "drimah_inflate_intensity", text="Intensity")
        layout.prop(scene, "drimah_inflate_smoothness", text="Smoothness")

        row = layout.row(align=True)
        row.operator("drimah_inflate.save_preset", text="Save", icon='FILE_TICK')
        row.operator("drimah_inflate.delete_preset", text="Delete", icon='TRASH')

        row = layout.row(align=True)
        row.operator("drimah_inflate.export_presets", text="Export", icon='EXPORT')
        row.operator("drimah_inflate.import_presets", text="Import", icon='IMPORT')

        layout.separator()
        # Main action must be the final control in the Inflate module.
        action = layout.row()
        action.scale_y = 1.35
        action.operator("dmt12_inflate.inflate", text="Inflate", icon='MOD_THICKNESS')

CLASSES = (
    DMT12_DRIMAHINFLATE_OT_inflate,
    DMT12_DRIMAHINFLATE_OT_save_preset,
    DMT12_DRIMAHINFLATE_OT_delete_preset,
    DMT12_DRIMAHINFLATE_OT_export_presets,
    DMT12_DRIMAHINFLATE_OT_import_presets,
    DMT12_DRIMAHINFLATE_PT_panel,
)

def register():
    # Blender may keep classes registered after a failed or duplicate add-on install.
    # Remove any existing classes with these exact class names before registering
    # this copy, avoiding "already registered as a subclass" errors.
    for cls in reversed(CLASSES):
        # Look up the registered RNA class as well as the Python attribute.
        # Blender can retain the RNA registration after an interrupted enable,
        # even when getattr(bpy.types, name) does not expose it as expected.
        existing = getattr(bpy.types, cls.__name__, None)
        if existing is None:
            try:
                existing = bpy.types.Operator.bl_rna_get_subclass_py(cls.__name__, None)
            except (AttributeError, RuntimeError, TypeError):
                existing = None
        if existing is not None:
            try:
                bpy.utils.unregister_class(existing)
            except (RuntimeError, TypeError):
                pass

    # Remove stale Scene properties left by an interrupted registration.
    for prop in ("drimah_inflate_preset", "drimah_inflate_intensity", "drimah_inflate_smoothness"):
        if hasattr(bpy.types.Scene, prop):
            try:
                delattr(bpy.types.Scene, prop)
            except (AttributeError, RuntimeError):
                pass

    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except (RuntimeError, ValueError) as exc:
            # Blender 5.2 can retain a class from an earlier/duplicate add-on
            # install. Do not abort registration of the remaining Inflate UI.
            if "already registered as a subclass" in str(exc):
                continue
            raise
    bpy.types.Scene.drimah_inflate_preset = EnumProperty(
        name="Preset", items=enum_presets, update=preset_update
    )
    bpy.types.Scene.drimah_inflate_intensity = FloatProperty(
        name="Intensity", default=0.10, min=0.0001, max=10.0,
        soft_min=0.001, soft_max=1.0, unit='LENGTH'
    )
    bpy.types.Scene.drimah_inflate_smoothness = IntProperty(
        name="Smoothness", default=3, min=1, max=12
    )

def unregister():
    for prop in ("drimah_inflate_preset", "drimah_inflate_intensity", "drimah_inflate_smoothness"):
        if hasattr(bpy.types.Scene, prop):
            try:
                delattr(bpy.types.Scene, prop)
            except (AttributeError, RuntimeError):
                pass
    for cls in reversed(CLASSES):
        # Look up the registered RNA class as well as the Python attribute.
        # Blender can retain the RNA registration after an interrupted enable,
        # even when getattr(bpy.types, name) does not expose it as expected.
        existing = getattr(bpy.types, cls.__name__, None)
        if existing is None:
            try:
                existing = bpy.types.Operator.bl_rna_get_subclass_py(cls.__name__, None)
            except (AttributeError, RuntimeError, TypeError):
                existing = None
        if existing is not None:
            try:
                bpy.utils.unregister_class(existing)
            except (RuntimeError, TypeError):
                pass

if __name__ == "__main__":
    register()
