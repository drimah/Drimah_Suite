bl_info = {
    "name": "Drimah MeshTools - 1.9",
    "author": "Drimah Studio",
    "version": (1, 9, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Drimah MeshTools",
    "description": "Mesh tools with Inflate, Relax, and X-Ray modules.",
    "category": "Mesh",
}

import bpy
import json
import os
import re
from bpy.props import (
    BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
)
from bpy.types import Operator, Panel, PropertyGroup

# Inflate module source is integrated here; user-facing interface language is English.
# Both modules are registered under the same add-on.
from . import drimah_inflate, xray

RELAX_BUILTINS = {
    "SOFT": {"label": "Soft", "profile": "ORGANIC", "intensity": 0.20, "iterations": 3, "protect_boundary": True},
    "ORGANIC_PRESET": {"label": "Organic", "profile": "ORGANIC", "intensity": 0.35, "iterations": 5, "protect_boundary": True},
    "MECHANICAL_PRESET": {"label": "Mechanical", "profile": "MECHANICAL", "intensity": 0.12, "iterations": 2, "protect_boundary": True},
    "UNIFORM_PRESET": {"label": "Uniform", "profile": "UNIFORM", "intensity": 0.25, "iterations": 4, "protect_boundary": True},
}


def _relax_preset_path():
    base = bpy.utils.user_resource('CONFIG', path="drimah_meshtools", create=True)
    return os.path.join(base, "relax_presets.json")


def _load_relax_custom():
    try:
        with open(_relax_preset_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _write_relax_custom(data):
    path = _relax_preset_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


_RELAX_ENUM_ITEMS_CACHE = []

def _relax_preset_items(self, context):
    global _RELAX_ENUM_ITEMS_CACHE
    items = [(k, v["label"], "Built-in Relax preset") for k, v in RELAX_BUILTINS.items()]
    custom = _load_relax_custom()
    for key, value in sorted(custom.items(), key=lambda item: str(item[1].get("label", "")).lower()):
        if isinstance(value, dict) and isinstance(value.get("label"), str):
            items.append((key, value["label"], "Custom Relax preset"))
    if not items:
        items = [('SOFT', 'Soft', 'Built-in Relax preset')]
    # Keep dynamic enum strings alive; Blender can retain pointers between redraws.
    _RELAX_ENUM_ITEMS_CACHE = items
    return _RELAX_ENUM_ITEMS_CACHE


def _relax_preset_update(self, context):
    key = self.preset
    data = RELAX_BUILTINS.get(key) or _load_relax_custom().get(key)
    if not isinstance(data, dict):
        return
    self.profile = data.get("profile", "ORGANIC")
    self.intensity = max(0.01, min(1.0, float(data.get("intensity", 0.25))))
    self.iterations = max(1, min(100, int(data.get("iterations", 3))))
    self.protect_boundary = bool(data.get("protect_boundary", True))


def _is_mesh_editable(context):
    obj = context.active_object
    return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

def _boundary_vertices(bm):
    boundary = set()
    for edge in bm.edges:
        if len(edge.link_faces) == 1:
            boundary.update(edge.verts)
    return boundary

def _edge_sharp(edge):
    try:
        return bool(edge.smooth is False)
    except Exception:
        return False

def _relax_mesh(context, settings):
    import bmesh
    obj = context.edit_object
    bm = bmesh.from_edit_mesh(obj.data)
    selected = {v for v in bm.verts if v.select}
    if not selected:
        selected = set(bm.verts)
    if not selected:
        return 0

    boundary = _boundary_vertices(bm) if settings.protect_boundary else set()
    sharp_verts = set()
    if settings.profile == 'MECHANICAL':
        for edge in bm.edges:
            if _edge_sharp(edge):
                sharp_verts.update(edge.verts)

    movable = selected - boundary
    if settings.profile == 'MECHANICAL':
        movable -= sharp_verts
    if not movable:
        return 0

    # Laplacian relaxation with per-iteration snapshots. Coordinates are
    # computed from the previous iteration to avoid order-dependent drift.
    intensity = max(0.0, min(1.0, settings.intensity))
    iterations = max(1, min(100, settings.iterations))
    for _ in range(iterations):
        old = {v: v.co.copy() for v in bm.verts}
        updates = {}
        for v in movable:
            neighbors = [e.other_vert(v) for e in v.link_edges]
            if not neighbors:
                continue
            # Mechanical profile is deliberately conservative. The Organic
            # profile uses the same robust base operator with higher defaults.
            avg = sum((old[n] for n in neighbors), start=old[v].copy() * 0.0) / len(neighbors)
            updates[v] = old[v].lerp(avg, intensity)
        for v, co in updates.items():
            v.co = co

    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    return len(movable)

class DMT_Settings(PropertyGroup):
    preset: EnumProperty(name="Preset", items=_relax_preset_items, update=_relax_preset_update)
    profile: EnumProperty(
        name="Profile",
        description="Choose how Relax should process the geometry",
        items=[
            ('AUTO', "Automatic", "Suggests a profile based on geometry; not semantic classification"),
            ('ORGANIC', "Organic", "Prioritizes smoothness on organic surfaces"),
            ('MECHANICAL', "Mechanical", "Conservative; protects edges marked as sharp"),
            ('UNIFORM', "Uniform", "General geometric relaxation"),
        ],
        default='AUTO',
    )
    intensity: FloatProperty(name="Intensity", default=0.25, min=0.01, max=1.0, subtype='FACTOR')
    iterations: IntProperty(name="Iterations", default=3, min=1, max=100)
    protect_boundary: BoolProperty(name="Protect Open Boundaries", default=True)
    preset_name: StringProperty(name="Preset Name", default="My Preset")

class DMT_OT_relax(Operator):
    bl_idname = "dmt.relax"
    bl_label = "Apply Relax"
    bl_description = "Relax selected vertices; if none are selected, use the entire mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode in {'OBJECT', 'EDIT_MESH'}

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object.")
            return {'CANCELLED'}

        # Em Object Mode, o objeto selecionado inteiro é processado. Em Edit
        # Mode, respeitamos a seleção de vértices feita pelo usuário.
        started_in_object_mode = context.mode == 'OBJECT'
        try:
            if started_in_object_mode:
                bpy.ops.object.mode_set(mode='EDIT')
                # Object Mode means the user selected the object, not individual
                # vertices. Explicitly select every vertex so the operation is
                # deterministic and does not depend on stale Edit Mode selection.
                import bmesh
                bm = bmesh.from_edit_mesh(obj.data)
                for vert in bm.verts:
                    vert.select_set(True)
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

            s = context.scene.dmt_settings
            profile = s.profile
            if profile == 'AUTO':
                # Heurística simples, não é classificação por IA.
                import bmesh
                bm = bmesh.from_edit_mesh(context.edit_object.data)
                has_sharp = any(_edge_sharp(e) for e in bm.edges)
                profile = 'MECHANICAL' if has_sharp else 'ORGANIC'
            class Effective:
                pass
            effective = Effective()
            effective.profile = profile
            effective.intensity = s.intensity
            effective.iterations = s.iterations
            effective.protect_boundary = s.protect_boundary
            count = _relax_mesh(context, effective)
            if count == 0:
                self.report({'WARNING'}, "No vertices available to relax. Check the selection and boundary protection settings.")
                return {'CANCELLED'}
            self.report({'INFO'}, f"Relax applied to {count} vertices.")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, f"Failed to apply Relax: {exc}")
            return {'CANCELLED'}
        finally:
            if started_in_object_mode and context.mode == 'EDIT_MESH':
                bpy.ops.object.mode_set(mode='OBJECT')

class DMT_OT_save_preset(Operator):
    bl_idname = "dmt.save_preset"
    bl_label = "Save Preset"
    name: StringProperty(name="Preset Name", default="My Preset", maxlen=64)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):
        self.layout.prop(self, "name", text="")

    def execute(self, context):
        label = self.name.strip()
        if not label:
            self.report({'WARNING'}, "Enter a preset name.")
            return {'CANCELLED'}
        key = "CUSTOM_" + re.sub(r'[^A-Z0-9]+', '_', label.upper()).strip('_')[:40]
        data = _load_relax_custom()
        s = context.scene.dmt_settings
        data[key] = {"label": label, "profile": s.profile, "intensity": float(s.intensity),
                     "iterations": int(s.iterations), "protect_boundary": bool(s.protect_boundary)}
        try:
            _write_relax_custom(data)
        except OSError as exc:
            self.report({'ERROR'}, f"Could not save: {exc}")
            return {'CANCELLED'}
        s.preset = key
        self.report({'INFO'}, "Preset saved.")
        return {'FINISHED'}


class DMT_OT_delete_preset(Operator):
    bl_idname = "dmt.delete_preset"
    bl_label = "Delete Preset"
    @classmethod
    def poll(cls, context):
        return context.scene.dmt_settings.preset in _load_relax_custom()
    def execute(self, context):
        s = context.scene.dmt_settings
        key = s.preset
        data = _load_relax_custom()
        if key not in data:
            return {'CANCELLED'}
        del data[key]
        try:
            _write_relax_custom(data)
        except OSError as exc:
            self.report({'ERROR'}, f"Could not delete: {exc}")
            return {'CANCELLED'}
        s.preset = 'SOFT'
        return {'FINISHED'}


class DMT_OT_export_presets(Operator):
    bl_idname = "dmt.export_presets"
    bl_label = "Export Presets"
    filepath: StringProperty(subtype='FILE_PATH')
    def invoke(self, context, event):
        self.filepath = os.path.join(os.path.expanduser("~"), "drimah_relax_presets.json")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    def execute(self, context):
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(_load_relax_custom(), f, ensure_ascii=False, indent=2)
            return {'FINISHED'}
        except OSError as exc:
            self.report({'ERROR'}, f"Export failed: {exc}")
            return {'CANCELLED'}


class DMT_OT_import_presets(Operator):
    bl_idname = "dmt.import_presets"
    bl_label = "Import Presets"
    filepath: StringProperty(subtype='FILE_PATH', options={'HIDDEN'})
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    def execute(self, context):
        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                incoming = json.load(f)
            if not isinstance(incoming, dict):
                raise ValueError("Invalid preset file")
            existing = _load_relax_custom()
            for key, value in incoming.items():
                if not isinstance(value, dict):
                    continue
                label = value.get("label")
                if not isinstance(label, str):
                    continue
                safe_key = re.sub(r'[^A-Z0-9_]+', '_', str(key).upper())[:48] or "IMPORTED"
                existing[safe_key] = {"label": label[:64], "profile": value.get("profile", "ORGANIC") if value.get("profile", "ORGANIC") in {'AUTO','ORGANIC','MECHANICAL','UNIFORM'} else 'ORGANIC',
                    "intensity": max(0.01, min(1.0, float(value.get("intensity", 0.25)))),
                    "iterations": max(1, min(100, int(value.get("iterations", 3)))),
                    "protect_boundary": bool(value.get("protect_boundary", True))}
            _write_relax_custom(existing)
            _relax_preset_items(None, None)
            return {'FINISHED'}
        except (OSError, ValueError, TypeError) as exc:
            self.report({'ERROR'}, f"Import failed: {exc}")
            return {'CANCELLED'}

class DMT_PT_meshtools_root(Panel):
    bl_label = "Drimah MeshTools - 1.9"
    bl_idname = "DMT_PT_meshtools_root"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Drimah MeshTools"

    def draw(self, context):
        # This is the parent container only. The Inflate controls and button live
        # in DMT12_DRIMAHINFLATE_PT_panel, avoiding duplicate Inflate sections.
        pass

class DMT_PT_relax(Panel):
    bl_label = "Relax"
    bl_idname = "DMT_PT_relax"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Drimah MeshTools"
    bl_parent_id = "DMT_PT_meshtools_root"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        s = context.scene.dmt_settings
        layout.prop(s, "preset", text="Preset")
        layout.prop(s, "intensity", slider=True)
        layout.prop(s, "iterations")
        layout.prop(s, "protect_boundary")
        row = layout.row(align=True)
        row.operator("dmt.save_preset", text="Save", icon='FILE_TICK')
        row.operator("dmt.delete_preset", text="Delete", icon='TRASH')
        row = layout.row(align=True)
        row.operator("dmt.export_presets", text="Export", icon='EXPORT')
        row.operator("dmt.import_presets", text="Import", icon='IMPORT')
        layout.separator()
        action = layout.row()
        action.scale_y = 1.35
        action.operator("dmt.relax", text="Relax", icon='MOD_SMOOTH')

CLASSES = (
    DMT_Settings,
    DMT_OT_relax,
    DMT_OT_save_preset,
    DMT_OT_delete_preset,
    DMT_OT_export_presets,
    DMT_OT_import_presets,
    DMT_PT_meshtools_root,
    DMT_PT_relax,
)

XRAY_CLASSES = (
    xray.DMT_XRAY_Settings,
    xray.DMT_XRAY_OT_fix,
    xray.DMT_XRAY_OT_save_preset,
    xray.DMT_XRAY_OT_delete_preset,
    xray.DMT_XRAY_OT_export_presets,
    xray.DMT_XRAY_OT_import_presets,
    xray.DMT_XRAY_PT_panel,
)


def _dmt_all_registered_subclasses(base):
    """Walk Python subclasses to find stale Blender RNA classes by name."""
    found = []
    stack = list(base.__subclasses__())
    seen = set()
    while stack:
        item = stack.pop()
        if item in seen:
            continue
        seen.add(item)
        found.append(item)
        try:
            stack.extend(item.__subclasses__())
        except TypeError:
            pass
    return found


def _dmt_registered_class(cls):
    # First use Blender's RNA lookup, then inspect the Python subclass tree.
    for base in (bpy.types.Operator, bpy.types.Panel, bpy.types.PropertyGroup):
        try:
            found = base.bl_rna_get_subclass_py(cls.__name__, None)
        except (AttributeError, RuntimeError, TypeError):
            found = None
        if found is not None:
            return found
    for base in (bpy.types.Operator, bpy.types.Panel, bpy.types.PropertyGroup):
        for found in _dmt_all_registered_subclasses(base):
            if getattr(found, '__name__', None) == cls.__name__:
                return found
    return getattr(bpy.types, cls.__name__, None)


def _dmt_remove_stale_classes(classes):
    for cls in reversed(classes):
        existing = _dmt_registered_class(cls)
        if existing is not None:
            try:
                bpy.utils.unregister_class(existing)
            except (RuntimeError, TypeError, ValueError):
                pass


def _dmt_remove_legacy_inflate_classes():
    """Remove classes left registered by the former standalone Drimah Inflate add-on."""
    legacy_names = {
        "DRIMAHINFLATE_OT_inflate",
        "DRIMAHINFLATE_OT_save_preset",
        "DRIMAHINFLATE_OT_delete_preset",
        "DRIMAHINFLATE_OT_export_presets",
        "DRIMAHINFLATE_OT_import_presets",
        "DRIMAHINFLATE_PT_panel",
        # Previous integrated copies may leave these classes registered after reload.
        "DMT12_DRIMAHINFLATE_OT_inflate",
        "DMT12_DRIMAHINFLATE_OT_save_preset",
        "DMT12_DRIMAHINFLATE_OT_delete_preset",
        "DMT12_DRIMAHINFLATE_OT_export_presets",
        "DMT12_DRIMAHINFLATE_OT_import_presets",
        "DMT12_DRIMAHINFLATE_PT_panel",
    }
    bases = (bpy.types.Operator, bpy.types.Panel, bpy.types.PropertyGroup)
    # Search RNA first, then registered subclass trees; bpy.types attribute lookup
    # alone can miss a class retained after a failed add-on activation.
    found_classes = []
    for base in bases:
        for name in legacy_names:
            try:
                cls = base.bl_rna_get_subclass_py(name, None)
            except (AttributeError, RuntimeError, TypeError):
                cls = None
            if cls is not None and cls not in found_classes:
                found_classes.append(cls)
        for cls in _dmt_all_registered_subclasses(base):
            if getattr(cls, "__name__", None) in legacy_names and cls not in found_classes:
                found_classes.append(cls)
    for name in legacy_names:
        cls = getattr(bpy.types, name, None)
        if cls is not None and cls not in found_classes:
            found_classes.append(cls)
    for cls in reversed(found_classes):
        try:
            bpy.utils.unregister_class(cls)
        except (RuntimeError, TypeError, ValueError):
            pass


def _dmt_remove_scene_properties():
    for prop in ("dmt_settings", "dmt_xray_settings",
                 "drimah_inflate_preset", "drimah_inflate_intensity",
                 "drimah_inflate_smoothness"):
        if hasattr(bpy.types.Scene, prop):
            try:
                delattr(bpy.types.Scene, prop)
            except (AttributeError, RuntimeError, TypeError):
                pass


def _dmt_register_class_safe(cls):
    """Register once; if Blender retained a stale class, remove it and retry."""
    try:
        bpy.utils.register_class(cls)
        return
    except (RuntimeError, ValueError) as exc:
        if "already registered as a subclass" not in str(exc):
            raise
    existing = _dmt_registered_class(cls)
    if existing is not None:
        try:
            bpy.utils.unregister_class(existing)
        except (RuntimeError, TypeError, ValueError):
            pass
    # A stale duplicate can be hidden from RNA lookup; retry only after walking
    # all registered Operator/Panel/PropertyGroup subclasses by exact class name.
    existing = _dmt_registered_class(cls)
    if existing is not None:
        try:
            bpy.utils.unregister_class(existing)
        except (RuntimeError, TypeError, ValueError):
            pass
    bpy.utils.register_class(cls)


def register():
    # Clean up the old standalone Inflate classes before registering the integrated
    # module; they use the same operator identifiers and may survive failed installs.
    _dmt_remove_legacy_inflate_classes()
    all_classes = tuple(drimah_inflate.CLASSES) + tuple(XRAY_CLASSES) + tuple(CLASSES)
    _dmt_remove_stale_classes(all_classes)
    _dmt_remove_scene_properties()

    drimah_inflate.DMT12_DRIMAHINFLATE_PT_panel.bl_category = "Drimah MeshTools"
    drimah_inflate.DMT12_DRIMAHINFLATE_PT_panel.bl_label = "Inflate"
    drimah_inflate.DMT12_DRIMAHINFLATE_PT_panel.bl_parent_id = "DMT_PT_meshtools_root"
    drimah_inflate.DMT12_DRIMAHINFLATE_PT_panel.bl_options = {'DEFAULT_CLOSED'}

    # One registration path for the integrated add-on. Do not call each module's
    # register() function, which could register a class twice on partial reloads.
    for cls in tuple(CLASSES) + tuple(drimah_inflate.CLASSES) + tuple(XRAY_CLASSES):
        _dmt_register_class_safe(cls)

    bpy.types.Scene.dmt_settings = bpy.props.PointerProperty(type=DMT_Settings)
    bpy.types.Scene.dmt_xray_settings = bpy.props.PointerProperty(type=xray.DMT_XRAY_Settings)
    bpy.types.Scene.drimah_inflate_preset = EnumProperty(
        name="Preset", items=drimah_inflate.enum_presets,
        update=drimah_inflate.preset_update
    )
    bpy.types.Scene.drimah_inflate_intensity = FloatProperty(
        name="Intensity", default=0.10, min=0.0001, max=10.0,
        soft_min=0.001, soft_max=1.0, unit='LENGTH'
    )
    bpy.types.Scene.drimah_inflate_smoothness = IntProperty(
        name="Smoothness", default=3, min=1, max=12
    )


def unregister():
    all_classes = tuple(drimah_inflate.CLASSES) + tuple(XRAY_CLASSES) + tuple(CLASSES)
    _dmt_remove_scene_properties()
    _dmt_remove_stale_classes(all_classes)

if __name__ == "__main__":
    register()
