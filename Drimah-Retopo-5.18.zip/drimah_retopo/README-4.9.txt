Drimah Retopo 4.9: Stage 2 creates vertices only, with no edges or faces. Original object remains hidden, not deleted.
