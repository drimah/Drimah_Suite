Drimah Retopo 4.7 - Windows / Linux - Blender 5.2.2

Install this ZIP directly in Blender Preferences > Add-ons > Install from Disk.
The only add-on registered is Drimah Retopo.
QRemeshify source/QuadWild binaries are embedded as internal libraries, not separately installed.

Important: experimental QuadWild integration; Blender runtime not validated.
GPL-3.0-or-later applies to incorporated QRemeshify code.
