Versao 5.9: adicionado o botao "Remesh QuadWild (experimental)" ao painel existente.
O botao chama o operador interno QRemeshify/QuadWild ja empacotado; o objeto original deve ser preservado.
Nao foi alterado o restante do fluxo da interface.
