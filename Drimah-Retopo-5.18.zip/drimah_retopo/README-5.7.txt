Versao 5.7: registro do operador QuadWild na ativacao do Drimah, sem registro tardio durante a reconstrucao. Requer reiniciar Blender ao substituir 5.6.
