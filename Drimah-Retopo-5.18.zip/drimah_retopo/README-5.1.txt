Drimah Retopo 5.1 experimental.
Etapa 1: converter para quads, inalterada.
Etapa 2: Mostrar somente pontos -> Tracar guias -> Reconstruir superficie.
Tracar guias identifica contornos abertos e vincos de 40 graus, sem criar faces. Reconstruir superficie usa o motor QuadWild integrado e a superficie original para gerar nova conectividade quadrangular. As guias sao diagnosticas, NAO sao impostas como restricoes matematicas ao QuadWild nesta versao. Portanto o fluxo nao e garantido e o motor pode falhar. Os originais sao preservados.
