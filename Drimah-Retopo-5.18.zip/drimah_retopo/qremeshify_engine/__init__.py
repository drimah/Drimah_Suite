"""Internal QuadWild engine library for Drimah Retopo.
Not a separately installable Blender add-on.
Original QRemeshify copyright and GPL licensing retained in included source.
"""
