Drimah Retopo 5.9

Alvo: Blender 5.2.2.
Mudancas: versao visivel no cabecalho do painel e identificacao explicita do botao experimental QuadWild.

Instalacao limpa recomendada: no Blender, desative e remova a instalacao antiga do Drimah Retopo, reinicie o Blender, instale este ZIP e ative o complemento. Confirme que o painel mostra “Drimah Retopo 5.9”.

O motor QuadWild e experimental. A presenca do botao nao garante que a operacao conclua com sucesso; valide com uma copia do objeto.
