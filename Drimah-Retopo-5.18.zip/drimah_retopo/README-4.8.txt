Drimah Retopo 4.8 | Blender 5.2.2 | Windows + Linux
Botao 1 preservado. Botao 2 oferece modo conservador e modo Digitalizacao de pontos + QuadWild (experimental).
O novo modo examina vertices, conectividade, contornos e cantos, configura densidade do motor e reconstrói uma nova malha com validacao.
Nao e uma reconstrução independente a partir de nuvem de pontos pura; a superficie original continua sendo referencia necessaria.
Motor incorporado QRemeshify/QuadWild sob GPL conforme avisos originais.
Nao testado no Blender em execucao.
