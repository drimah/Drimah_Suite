Drimah Retopo 4.6 — Blender 5.2.x

Botao 1: conversao aprovada, inalterada.
Botao 2: reconstrucao por pontos com validacao de arestas, mais um teste
conservador de redistribuicao de vertices em regioes curvas, com projecao
sobre a superficie de referencia. Nao cria aneis novos nem substitui um
algoritmo global de quad meshing; a intensidade e configuravel.

O resultado e criado em um novo objeto, preservando a malha de entrada.
Se nenhuma regiao segura for encontrada, nao modifica o original.
Teste em copias dos arquivos e valide a exportacao OBJ antes de producao.
