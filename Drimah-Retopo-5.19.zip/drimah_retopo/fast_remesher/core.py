import bpy
import bmesh
import math
import heapq
import subprocess
import uuid

from mathutils.bvhtree import BVHTree

from . import surface_transfer


FASTREMESHER_BACKUP_REF_PROP = "fastremesher_backup_object"
FASTREMESHER_BACKUP_MARKER = "fastremesher_is_original_backup"
FASTREMESHER_BACKUP_UUID_PROP = "fastremesher_backup_uuid"
FASTREMESHER_BACKUP_COLLECTION = "Fast Remesher Backups"


def _ensure_backup_collection(context):
    collection = bpy.data.collections.get(FASTREMESHER_BACKUP_COLLECTION)
    if collection is None:
        collection = bpy.data.collections.new(FASTREMESHER_BACKUP_COLLECTION)
    scene = context.scene
    if collection.name not in {child.name for child in scene.collection.children}:
        scene.collection.children.link(collection)
    collection.hide_viewport = True
    collection.hide_render = True
    return collection


def _ensure_backup_uuid(obj):
    value = obj.get(FASTREMESHER_BACKUP_UUID_PROP, "") if obj is not None else ""
    if not value and obj is not None:
        value = uuid.uuid4().hex
        obj[FASTREMESHER_BACKUP_UUID_PROP] = value
    return value


def get_original_backup(obj):
    """Return the persistent original backup even if source/backup names change."""
    if obj is None:
        return None
    ref_name = obj.get(FASTREMESHER_BACKUP_REF_PROP, "")
    if ref_name:
        backup = bpy.data.objects.get(ref_name)
        if backup is not None and backup.type == 'MESH':
            return backup

    backup_uuid = obj.get(FASTREMESHER_BACKUP_UUID_PROP, "")
    if backup_uuid:
        for candidate in bpy.data.objects:
            if (
                candidate.type == 'MESH'
                and candidate.get(FASTREMESHER_BACKUP_MARKER, False)
                and candidate.get(FASTREMESHER_BACKUP_UUID_PROP, "") == backup_uuid
            ):
                obj[FASTREMESHER_BACKUP_REF_PROP] = candidate.name
                return candidate

    # Backward compatibility with pre-1.0 name-based backups.
    legacy = bpy.data.objects.get(obj.name + "_original_backup")
    if legacy is not None and legacy.type == 'MESH':
        backup_uuid = _ensure_backup_uuid(obj)
        obj[FASTREMESHER_BACKUP_REF_PROP] = legacy.name
        legacy[FASTREMESHER_BACKUP_MARKER] = True
        legacy[FASTREMESHER_BACKUP_UUID_PROP] = backup_uuid
        return legacy
    return None


def clear_original_backup_reference(obj):
    if obj is None:
        return
    if FASTREMESHER_BACKUP_REF_PROP in obj:
        del obj[FASTREMESHER_BACKUP_REF_PROP]
    if FASTREMESHER_BACKUP_UUID_PROP in obj:
        del obj[FASTREMESHER_BACKUP_UUID_PROP]


def _make_original_snapshot(obj, context):
    snap_mesh = obj.data.copy()
    snap_obj = obj.copy()
    snap_obj.data = snap_mesh
    snap_obj.name = obj.name + "_FastRemesher_snapshot"
    context.collection.objects.link(snap_obj)
    snap_obj.hide_viewport = True
    snap_obj.hide_render = True
    return snap_obj


def _backup_original(context, obj):
    backup_mesh = obj.data.copy()
    backup_obj = obj.copy()
    backup_obj.data = backup_mesh
    backup_obj.name = obj.name + "_original_backup"
    backup_obj.hide_viewport = True
    backup_obj.hide_render = True
    backup_obj.hide_select = True
    backup_uuid = _ensure_backup_uuid(obj)
    backup_obj[FASTREMESHER_BACKUP_MARKER] = True
    backup_obj[FASTREMESHER_BACKUP_UUID_PROP] = backup_uuid
    _ensure_backup_collection(context).objects.link(backup_obj)
    obj[FASTREMESHER_BACKUP_REF_PROP] = backup_obj.name
    return backup_obj


def ensure_fresh_original(context, obj):
    """Guarantee obj holds its true, never-before-remeshed geometry before
    any remesh runs. First call on an object creates the permanent backup.
    Every call after that restores FROM that backup, so repeated clicks
    (with different presets, settings, whatever) always start from the same
    untouched original — never from a previously remeshed result."""
    backup_obj = get_original_backup(obj)

    if backup_obj is None:
        backup_obj = _backup_original(context, obj)
    else:
        restored_mesh = backup_obj.data.copy()
        old_mesh = obj.data
        obj.data = restored_mesh
        if old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)

    return backup_obj


MAX_VOXEL_GRID_RESOLUTION = 400


def _count_islands(obj, max_faces_for_check=250000, stop_at=2, max_steps=300000):
    mesh = obj.data
    if len(mesh.polygons) > max_faces_for_check:
        return stop_at

    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()

    visited = [False] * len(bm.verts)
    island_count = 0
    steps = 0

    for start in bm.verts:
        if visited[start.index]:
            continue
        island_count += 1
        stack = [start]
        visited[start.index] = True
        while stack:
            steps += 1
            if steps > max_steps:
                # Large single blob taking too long to fully verify — treat as
                # clean rather than risk a long, UI-blocking traversal.
                bm.free()
                return 1
            v = stack.pop()
            for e in v.link_edges:
                other = e.other_vert(v)
                if not visited[other.index]:
                    visited[other.index] = True
                    stack.append(other)
        if island_count >= stop_at:
            bm.free()
            return island_count

    bm.free()
    return island_count


def _coarse_voxel_proxy(obj, context, target_faces, fragmented_coarseness=0.06, force_merge_floor=True):
    dims = obj.dimensions
    bbox_diagonal = (dims.x ** 2 + dims.y ** 2 + dims.z ** 2) ** 0.5
    if bbox_diagonal <= 0:
        return

    islands = _count_islands(obj)
    approx_faces = max(target_faces, 100)
    density_voxel_size = bbox_diagonal / (approx_faces ** 0.5) / 3.0
    density_voxel_size = max(density_voxel_size, 0.0005)

    if islands <= 1 or not force_merge_floor:
        # Organic remeshing must keep the requested density authoritative.
        # A fixed fragmented-mesh floor makes different Detail values collapse
        # to the same proxy density before QuadriFlow even starts.
        voxel_size = density_voxel_size
    else:
        # Hardsurface keeps the older merge floor because its fragmented
        # workflow intentionally favors solver stability over fine density.
        merge_safety_floor = bbox_diagonal * fragmented_coarseness
        voxel_size = max(density_voxel_size, merge_safety_floor)

    largest_dim = max(obj.dimensions.x, obj.dimensions.y, obj.dimensions.z)
    if largest_dim > 0:
        min_safe_size = largest_dim / MAX_VOXEL_GRID_RESOLUTION
        voxel_size = max(voxel_size, min_safe_size)

    mod = obj.modifiers.new(name="FastRemesher_CoarseProxy", type='REMESH')
    mod.mode = 'VOXEL'
    mod.voxel_size = voxel_size
    mod.adaptivity = 0.0
    mod.use_remove_disconnected = False

    depsgraph = context.evaluated_depsgraph_get()
    obj_eval = obj.evaluated_get(depsgraph)
    proxy_mesh = bpy.data.meshes.new_from_object(obj_eval)

    obj.modifiers.remove(mod)
    old_mesh = obj.data
    obj.data = proxy_mesh
    if old_mesh.users == 0:
        bpy.data.meshes.remove(old_mesh)

    return voxel_size, islands


def _shrinkwrap_onto(obj, context, target_obj):
    mod = obj.modifiers.new(name="FastRemesher_Shrinkwrap", type='SHRINKWRAP')
    mod.target = target_obj
    mod.wrap_method = 'NEAREST_SURFACEPOINT'

    depsgraph = context.evaluated_depsgraph_get()
    obj_eval = obj.evaluated_get(depsgraph)
    snapped_mesh = bpy.data.meshes.new_from_object(obj_eval)

    obj.modifiers.remove(mod)
    old_mesh = obj.data
    obj.data = snapped_mesh
    if old_mesh.users == 0:
        bpy.data.meshes.remove(old_mesh)


def _cleanup_snapshot(snap_obj):
    snap_mesh = snap_obj.data
    bpy.data.objects.remove(snap_obj, do_unlink=True)
    if snap_mesh.users == 0:
        bpy.data.meshes.remove(snap_mesh)


def _detect_circular_boundary_loops(mesh, max_loop_verts=64, min_loop_verts=6, roundness_tolerance=0.15):
    """Find small closed boundary loops (bolt holes, socket holes) on the
    ORIGINAL mesh that are close enough to circular to be worth forcing
    round after remeshing. Returns a list of dicts with center/radius/normal."""
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.edges.ensure_lookup_table()

    boundary_edges = [e for e in bm.edges if len(e.link_faces) == 1]
    visited = set()
    circles = []

    edge_lookup = {}
    for e in boundary_edges:
        edge_lookup.setdefault(e.verts[0], []).append(e)
        edge_lookup.setdefault(e.verts[1], []).append(e)

    for start_edge in boundary_edges:
        if start_edge.index in visited:
            continue
        loop_verts = []
        current_edge = start_edge
        current_vert = start_edge.verts[0]
        safety = 0
        while safety < max_loop_verts + 2:
            safety += 1
            visited.add(current_edge.index)
            loop_verts.append(current_vert)
            next_vert = current_edge.other_vert(current_vert)
            candidates = [e for e in edge_lookup.get(next_vert, []) if e.index != current_edge.index]
            if not candidates:
                break
            current_edge = candidates[0]
            current_vert = next_vert
            if current_vert == loop_verts[0]:
                break
        else:
            continue

        if not (min_loop_verts <= len(loop_verts) <= max_loop_verts):
            continue
        if loop_verts[0] != current_vert:
            continue

        coords = [v.co.copy() for v in loop_verts]
        center = sum(coords, coords[0].__class__((0, 0, 0))) / len(coords)
        radii = [(c - center).length for c in coords]
        avg_radius = sum(radii) / len(radii)
        if avg_radius <= 0:
            continue
        deviation = sum(abs(r - avg_radius) for r in radii) / len(radii)
        if deviation / avg_radius > roundness_tolerance:
            continue

        edge1 = coords[1] - coords[0]
        edge2 = coords[2] - coords[0] if len(coords) > 2 else edge1
        normal = edge1.cross(edge2)
        if normal.length == 0:
            continue
        normal.normalize()

        circles.append({"center": center, "radius": avg_radius, "normal": normal})

    bm.free()
    return circles


def _snap_boundary_loops_to_circles(obj, context, circles, match_tolerance_factor=2.0):
    if not circles:
        return

    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.edges.ensure_lookup_table()

    boundary_edges = [e for e in bm.edges if len(e.link_faces) == 1]
    edge_lookup = {}
    for e in boundary_edges:
        edge_lookup.setdefault(e.verts[0], []).append(e)
        edge_lookup.setdefault(e.verts[1], []).append(e)

    visited = set()
    for start_edge in boundary_edges:
        if start_edge.index in visited:
            continue
        loop_verts = []
        current_edge = start_edge
        current_vert = start_edge.verts[0]
        safety = 0
        while safety < 200:
            safety += 1
            visited.add(current_edge.index)
            loop_verts.append(current_vert)
            next_vert = current_edge.other_vert(current_vert)
            candidates = [e for e in edge_lookup.get(next_vert, []) if e.index != current_edge.index]
            if not candidates:
                break
            current_edge = candidates[0]
            current_vert = next_vert
            if current_vert == loop_verts[0]:
                break
        else:
            continue
        if loop_verts[0] != current_vert or len(loop_verts) < 3:
            continue

        coords = [v.co.copy() for v in loop_verts]
        loop_center = sum(coords, coords[0].__class__((0, 0, 0))) / len(coords)

        best_circle = None
        best_dist = None
        for circle in circles:
            dist = (loop_center - circle["center"]).length
            if dist <= circle["radius"] * match_tolerance_factor:
                if best_dist is None or dist < best_dist:
                    best_dist = dist
                    best_circle = circle
        if best_circle is None:
            continue

        center = best_circle["center"]
        normal = best_circle["normal"]
        radius = best_circle["radius"]

        tangent = (coords[0] - center)
        tangent = (tangent - normal * tangent.dot(normal))
        if tangent.length == 0:
            continue
        tangent.normalize()
        bitangent = normal.cross(tangent)

        for v in loop_verts:
            rel = v.co - center
            rel_plane = rel - normal * rel.dot(normal)
            if rel_plane.length == 0:
                continue
            angle_x = rel_plane.dot(tangent)
            angle_y = rel_plane.dot(bitangent)
            angle = math.atan2(angle_y, angle_x)
            v.co = center + tangent * (radius * math.cos(angle)) + bitangent * (radius * math.sin(angle))

    bm.to_mesh(mesh)
    bm.free()
    mesh.update()


def transfer_uv_and_materials(obj, context):
    """Transfer production data from the persistent original.

    The historical function name is retained to avoid changing the remesh
    pipelines. surface_transfer.py now handles materials, UV maps, vertex
    groups/skin weights and armature-binding validation.
    """
    backup_obj = get_original_backup(obj)
    if backup_obj is None:
        return {
            "success": False,
            "uv_layers": 0,
            "uv_loops_mapped": 0,
            "uv_misses": 0,
            "material_faces_mapped": 0,
            "error": "original backup not found",
        }

    return surface_transfer.transfer_surface_data(obj, backup_obj)


def _local_target_edge_length(obj, target_edge_length):
    """QuadriFlow's target_edge_length operates on the mesh's raw LOCAL
    coordinates, not what you actually see in the viewport. If the object
    has a non-1.0 scale, a 'visual' Quad Size has to be converted into the
    equivalent local-space value, or the setting silently means something
    different on every differently-scaled object."""
    scale = obj.scale
    avg_scale = (abs(scale.x) + abs(scale.y) + abs(scale.z)) / 3.0
    if avg_scale <= 1e-8:
        avg_scale = 1.0
    return target_edge_length / avg_scale


def resolve_target_edge_length(obj, detail_factor):
    """Convert a scale-invariant Detail factor (fraction of the object's
    own bounding box diagonal) into an actual world-space target edge
    length, computed fresh from THIS object's current dimensions.
    obj.dimensions is already correct world-space size regardless of
    whether scale is applied — so the same Detail value produces a
    correctly-proportioned result on any object, any scale, automatically."""
    dims = obj.dimensions
    bbox_diagonal = (dims.x ** 2 + dims.y ** 2 + dims.z ** 2) ** 0.5
    if bbox_diagonal <= 0:
        bbox_diagonal = 1.0
    return max(bbox_diagonal * detail_factor, 1e-6)


def _edge_crease_layer(bm):
    """Return the Blender 4.x/5.x edge crease layer when one exists."""
    for name in ("crease_edge", "crease"):
        try:
            layer = bm.edges.layers.float.get(name)
        except Exception:
            layer = None
        if layer is not None:
            return layer
    return None


FASTREMESHER_PRESERVE_LAYER = "fastremesher_preserve"


def _manual_preserve_layer(bm):
    """Return the dedicated Fast Remesher edge-preservation layer."""
    try:
        return bm.edges.layers.int.get(FASTREMESHER_PRESERVE_LAYER)
    except Exception:
        return None


def _edge_uv_discontinuity(edge, uv_layer, epsilon=1e-6):
    """Return True when the two sides of an edge use different UV corners.

    Blender UV data is face-corner data. Imported hard-surface meshes often
    have real UV island borders without a useful edge.seam flag, so checking
    only edge.seam is not enough when the user asks us to preserve UV seams.
    """
    if uv_layer is None or len(edge.link_faces) != 2:
        return False

    side_maps = []
    for face in edge.link_faces:
        values = {}
        for loop in face.loops:
            if loop.vert in edge.verts:
                try:
                    values[loop.vert.index] = loop[uv_layer].uv.copy()
                except Exception:
                    return False
        if len(values) != 2:
            return False
        side_maps.append(values)

    for vert in edge.verts:
        a = side_maps[0].get(vert.index)
        b = side_maps[1].get(vert.index)
        if a is None or b is None:
            return False
        if (a - b).length > epsilon:
            return True
    return False


def _hard_surface_protected_edges(
    bm,
    feature_angle,
    planar_angle,
    min_edge_length,
    preserve_uv_seams=True,
    preserve_material_boundaries=True,
    preserve_sharp=True,
    protect_symmetry_center=False,
    symmetry_tolerance=1e-6,
):
    """Classify edges that define design intent and must survive cleanup."""
    bm.edges.ensure_lookup_table()
    crease_layer = _edge_crease_layer(bm)
    manual_layer = _manual_preserve_layer(bm)
    try:
        uv_layer = bm.loops.layers.uv.active
    except Exception:
        uv_layer = None

    protected = set()
    stats = {
        "boundary": 0,
        "manual": 0,
        "uv_seam": 0,
        "uv_boundary": 0,
        "material_boundary": 0,
        "sharp": 0,
        "crease": 0,
        "symmetry_center": 0,
        "geometric_feature": 0,
        "unprotected_internal": 0,
    }

    effective_planar_angle = max(0.0, min(planar_angle, feature_angle))

    for edge in bm.edges:
        if len(edge.link_faces) != 2:
            protected.add(edge)
            stats["boundary"] += 1
            continue

        if manual_layer is not None:
            try:
                if int(edge[manual_layer]) != 0:
                    protected.add(edge)
                    stats["manual"] += 1
                    continue
            except Exception:
                pass

        if preserve_uv_seams:
            if getattr(edge, "seam", False):
                protected.add(edge)
                stats["uv_seam"] += 1
                continue
            if _edge_uv_discontinuity(edge, uv_layer):
                protected.add(edge)
                stats["uv_boundary"] += 1
                continue

        if preserve_material_boundaries:
            f0, f1 = edge.link_faces
            if f0.material_index != f1.material_index:
                protected.add(edge)
                stats["material_boundary"] += 1
                continue

        if crease_layer is not None:
            try:
                if float(edge[crease_layer]) > 1e-6:
                    protected.add(edge)
                    stats["crease"] += 1
                    continue
            except Exception:
                pass

        if protect_symmetry_center and all(abs(v.co.x) <= symmetry_tolerance for v in edge.verts):
            protected.add(edge)
            stats["symmetry_center"] += 1
            continue

        angle = edge.calc_face_angle(0.0)
        edge_length = edge.calc_length()

        # Imported meshes frequently mark every triangulation edge Sharp. A
        # Sharp flag only counts as design intent when geometry agrees with it.
        if preserve_sharp and not edge.smooth and angle > effective_planar_angle:
            protected.add(edge)
            stats["sharp"] += 1
            continue

        if angle >= feature_angle and (min_edge_length <= 0.0 or edge_length >= min_edge_length):
            protected.add(edge)
            stats["geometric_feature"] += 1
            continue

        stats["unprotected_internal"] += 1

    return protected, stats


def _hard_surface_edge_analysis(
    bm,
    feature_angle,
    planar_angle,
    min_edge_length,
    preserve_uv_seams=True,
    preserve_material_boundaries=True,
    preserve_sharp=True,
    protect_symmetry_center=False,
    symmetry_tolerance=1e-6,
):
    """Compatibility wrapper returning the old candidate-edge shape."""
    protected, stats = _hard_surface_protected_edges(
        bm,
        feature_angle=feature_angle,
        planar_angle=planar_angle,
        min_edge_length=min_edge_length,
        preserve_uv_seams=preserve_uv_seams,
        preserve_material_boundaries=preserve_material_boundaries,
        preserve_sharp=preserve_sharp,
        protect_symmetry_center=protect_symmetry_center,
        symmetry_tolerance=symmetry_tolerance,
    )

    effective_planar_angle = max(0.0, min(planar_angle, feature_angle))
    candidates = []
    stats["planar_candidates"] = 0
    stats["nonplanar"] = 0
    for edge in bm.edges:
        if edge in protected or len(edge.link_faces) != 2:
            continue
        if edge.calc_face_angle(0.0) <= effective_planar_angle:
            candidates.append(edge)
            stats["planar_candidates"] += 1
        else:
            stats["nonplanar"] += 1
    return candidates, stats


def _face_world_plane(face, matrix_world, normal_matrix):
    coords = [matrix_world @ vert.co for vert in face.verts]
    if not coords:
        return None, None
    center = coords[0].copy()
    center.zero()
    for co in coords:
        center += co
    center /= len(coords)
    normal = normal_matrix @ face.normal
    if normal.length <= 1e-12:
        return center, None
    normal.normalize()
    return center, normal


def _face_plane_error_world(face, matrix_world, plane_point, plane_normal):
    error = 0.0
    for vert in face.verts:
        co = matrix_world @ vert.co
        error = max(error, abs((co - plane_point).dot(plane_normal)))
    return error


def _boundary_edge_components(boundary_edges):
    """Return connected edge components plus whether each component is closed."""
    boundary_edges = set(boundary_edges)
    if not boundary_edges:
        return []

    by_vert = {}
    for edge in boundary_edges:
        for vert in edge.verts:
            by_vert.setdefault(vert, set()).add(edge)

    components = []
    remaining = set(boundary_edges)
    while remaining:
        seed = remaining.pop()
        comp_edges = {seed}
        stack = list(seed.verts)
        seen_verts = set()
        while stack:
            vert = stack.pop()
            if vert in seen_verts:
                continue
            seen_verts.add(vert)
            for edge in by_vert.get(vert, ()):
                if edge not in comp_edges:
                    comp_edges.add(edge)
                    remaining.discard(edge)
                    stack.extend(edge.verts)

        degree = {}
        perimeter = 0.0
        for edge in comp_edges:
            for vert in edge.verts:
                degree[vert] = degree.get(vert, 0) + 1
            perimeter += edge.calc_length()
        closed = bool(degree) and all(value == 2 for value in degree.values())
        components.append({
            "edges": comp_edges,
            "verts": set(degree.keys()),
            "closed": closed,
            "perimeter": perimeter,
        })
    return components


def _shortest_region_bridge(start_verts, goal_verts, allowed_edges, matrix_world):
    """Find a shortest existing-edge path joining an inner loop to the outer loop."""
    start_verts = set(start_verts)
    goal_verts = set(goal_verts)
    if not start_verts or not goal_verts:
        return None

    allowed_edges = set(allowed_edges)
    heap = []
    previous = {}
    distance = {}
    serial = 0

    for vert in start_verts:
        distance[vert] = 0.0
        heapq.heappush(heap, (0.0, serial, vert))
        serial += 1

    reached = None
    while heap:
        dist, _serial, vert = heapq.heappop(heap)
        if dist != distance.get(vert):
            continue
        if vert in goal_verts:
            reached = vert
            break
        for edge in vert.link_edges:
            if edge not in allowed_edges:
                continue
            other = edge.other_vert(vert)
            a = matrix_world @ vert.co
            b = matrix_world @ other.co
            new_dist = dist + (b - a).length
            if new_dist + 1e-12 < distance.get(other, float("inf")):
                distance[other] = new_dist
                previous[other] = (vert, edge)
                heapq.heappush(heap, (new_dist, serial, other))
                serial += 1

    if reached is None:
        return None

    path_edges = []
    current = reached
    while current not in start_verts:
        item = previous.get(current)
        if item is None:
            return None
        prev_vert, edge = item
        path_edges.append(edge)
        current = prev_vert
    return path_edges


def _collect_planar_regions(
    bm,
    obj,
    protected_edges,
    planar_angle,
    feature_angle,
    plane_distance_tolerance,
):
    """Flood-fill coherent planar patches instead of judging edges in isolation.

    A region can absorb mild import noise as long as all of its vertices remain
    within the allowed world-space plane error. This is what lets a triangulated
    CAD/GLTF panel collapse as one unit without flattening a real bevel/fillet.
    """
    bm.faces.ensure_lookup_table()
    matrix_world = obj.matrix_world.copy()
    try:
        normal_matrix = matrix_world.to_3x3().inverted().transposed()
    except Exception:
        normal_matrix = matrix_world.to_3x3()

    face_plane = {}
    for face in bm.faces:
        face_plane[face] = _face_world_plane(face, matrix_world, normal_matrix)

    # Permit a little more local normal noise than the UI planar tolerance,
    # but never enough to walk through a real design edge.
    grow_angle = max(planar_angle * 2.0, math.radians(0.15))
    grow_angle = min(grow_angle, max(planar_angle, feature_angle * 0.45))
    cos_limit = math.cos(max(grow_angle, 1e-8))

    visited = set()
    regions = []
    skipped_nonplanar = 0

    for seed in bm.faces:
        if seed in visited:
            continue
        plane_point, plane_normal = face_plane.get(seed, (None, None))
        if plane_point is None or plane_normal is None:
            visited.add(seed)
            continue

        region_faces = {seed}
        queue = [seed]
        while queue:
            face = queue.pop()
            for edge in face.edges:
                if edge in protected_edges or len(edge.link_faces) != 2:
                    continue
                other = edge.link_faces[0] if edge.link_faces[1] is face else edge.link_faces[1]
                if other in visited or other in region_faces:
                    continue
                _center, other_normal = face_plane.get(other, (None, None))
                if other_normal is None:
                    continue
                if plane_normal.dot(other_normal) < cos_limit:
                    continue
                if _face_plane_error_world(
                    other,
                    matrix_world,
                    plane_point,
                    plane_normal,
                ) > plane_distance_tolerance:
                    continue
                region_faces.add(other)
                queue.append(other)

        visited.update(region_faces)
        if len(region_faces) < 2:
            continue

        max_plane_error = 0.0
        max_normal_angle = 0.0
        all_edges = set()
        for face in region_faces:
            max_plane_error = max(
                max_plane_error,
                _face_plane_error_world(face, matrix_world, plane_point, plane_normal),
            )
            _center, normal = face_plane.get(face, (None, None))
            if normal is not None:
                dot = max(-1.0, min(1.0, plane_normal.dot(normal)))
                max_normal_angle = max(max_normal_angle, math.acos(dot))
            all_edges.update(face.edges)

        if max_plane_error > plane_distance_tolerance:
            skipped_nonplanar += 1
            continue

        internal_edges = set()
        boundary_edges = set()
        for edge in all_edges:
            linked_inside = sum(1 for face in edge.link_faces if face in region_faces)
            if linked_inside == 2 and edge not in protected_edges:
                internal_edges.add(edge)
            elif linked_inside == 1:
                boundary_edges.add(edge)

        if not internal_edges:
            continue

        components = _boundary_edge_components(boundary_edges)
        closed_components = [component for component in components if component["closed"]]
        holes = max(0, len(closed_components) - 1)

        regions.append({
            "faces": region_faces,
            "internal_edges": internal_edges,
            "boundary_edges": boundary_edges,
            "boundary_components": components,
            "closed_boundary_components": closed_components,
            "holes": holes,
            "max_plane_error": max_plane_error,
            "max_normal_angle": max_normal_angle,
            "plane_point": plane_point,
            "plane_normal": plane_normal,
        })

    return regions, skipped_nonplanar


def _closest_component_vertex_pair(component_a, component_b, matrix_world):
    """Return the closest vertex pair between two boundary components."""
    best = None
    best_distance = float("inf")
    verts_a = component_a.get("verts", set())
    verts_b = component_b.get("verts", set())
    for vert_a in verts_a:
        world_a = matrix_world @ vert_a.co
        for vert_b in verts_b:
            distance = (matrix_world @ vert_b.co - world_a).length
            if distance < best_distance:
                best_distance = distance
                best = (vert_a, vert_b)
    return best_distance, best


def _minimum_component_bridge_tree(components, matrix_world):
    """Build a short bridge tree instead of radiating every hole to the rim.

    Blender cannot represent a polygon with holes, so some bridge topology is
    unavoidable. The old implementation connected every opening independently
    to the outer boundary, producing the spoke pattern visible on CAD/imported
    panels. Prim-style growth connects each new opening to the nearest already
    connected boundary component, minimizing total bridge length.
    """
    if len(components) <= 1:
        return []

    outer_index = max(
        range(len(components)),
        key=lambda index: components[index].get("perimeter", 0.0),
    )
    connected = {outer_index}
    remaining = set(range(len(components))) - connected
    links = []

    while remaining:
        best = None
        best_distance = float("inf")
        for from_index in connected:
            for to_index in remaining:
                distance, pair = _closest_component_vertex_pair(
                    components[from_index],
                    components[to_index],
                    matrix_world,
                )
                if pair is not None and distance < best_distance:
                    best_distance = distance
                    best = (from_index, to_index, pair[0], pair[1])
        if best is None:
            break
        links.append(best)
        connected.add(best[1])
        remaining.remove(best[1])

    return links


def _direct_region_bridge_edges(bm, region, matrix_world):
    """Create a minimal, short bridge network for planar openings.

    Direct bridges are preferred because they replace arbitrary imported
    triangulation paths with clean topology. If Blender cannot split a region
    directly for a particular link, the existing-edge shortest path is used as
    a conservative fallback.
    """
    closed = list(region.get("closed_boundary_components") or [])
    if len(closed) <= 1:
        return set(), 0, True, 0, 0

    links = _minimum_component_bridge_tree(closed, matrix_world)
    opening_count = max(0, len(closed) - 1)
    if len(links) != opening_count:
        return set(), opening_count, False, 0, 0

    original_region_faces = set(region.get("faces", set()))
    faces_exclude = [face for face in bm.faces if face not in original_region_faces]
    allowed = set(region.get("internal_edges", set()))
    bridges = set()
    direct_links = 0
    fallback_links = 0

    for _from_index, _to_index, vert_a, vert_b in links:
        if not vert_a.is_valid or not vert_b.is_valid:
            return bridges, opening_count, False, direct_links, fallback_links

        existing = next(
            (edge for edge in vert_a.link_edges if edge.is_valid and edge.other_vert(vert_a) is vert_b),
            None,
        )
        if existing is not None:
            bridges.add(existing)
            direct_links += 1
            continue

        created = []
        try:
            result = bmesh.ops.connect_vert_pair(
                bm,
                verts=[vert_a, vert_b],
                faces_exclude=faces_exclude,
            )
            created = [edge for edge in result.get("edges", []) if edge.is_valid]
        except Exception:
            created = []

        if created:
            bridges.update(created)
            direct_links += 1
            continue

        path = _shortest_region_bridge(
            {vert_a},
            {vert_b},
            {edge for edge in allowed if edge.is_valid},
            matrix_world,
        )
        if not path:
            return bridges, opening_count, False, direct_links, fallback_links
        bridges.update(edge for edge in path if edge.is_valid)
        fallback_links += 1

    return bridges, opening_count, True, direct_links, fallback_links


def _face_center_world_cached(face, matrix_world, cache):
    center = cache.get(face)
    if center is not None:
        return center
    if not face.verts:
        center = matrix_world.translation.copy()
    else:
        center = matrix_world @ face.calc_center_median()
    cache[face] = center
    return center


def _faces_touching_boundary_component(component, region_faces):
    faces = set()
    for edge in component.get("edges", set()):
        for face in edge.link_faces:
            if face in region_faces and face.is_valid:
                faces.add(face)
    return faces


def _expand_feature_cell_faces(seed_faces, region_faces, protected_edges, rings=1):
    """Grow a compact local face cell around an embedded feature.

    The cell intentionally keeps a small amount of source topology around
    sockets, recesses and cut-outs. The rest of the panel is then free to
    collapse into large n-gons without sending arbitrary bridge edges across
    the entire surface.
    """
    region_faces = set(region_faces)
    cell = {face for face in seed_faces if face in region_faces and face.is_valid}
    frontier = set(cell)
    for _ in range(max(0, int(rings))):
        next_frontier = set()
        for face in frontier:
            for edge in face.edges:
                if edge in protected_edges:
                    continue
                for other in edge.link_faces:
                    if other is face or other not in region_faces or other in cell:
                        continue
                    if other.is_valid:
                        next_frontier.add(other)
        if not next_frontier:
            break
        cell.update(next_frontier)
        frontier = next_frontier
    return cell


def _region_face_components(faces, protected_edges=None):
    """Connected components of a face subset.

    Protected edges are treated as cuts. This lets the caller collapse each
    simple planar patch independently while feature cells/corridors remain as
    intentional boundaries.
    """
    remaining = {face for face in faces if face.is_valid}
    protected_edges = set(protected_edges or ())
    components = []
    while remaining:
        seed = remaining.pop()
        comp = {seed}
        stack = [seed]
        while stack:
            face = stack.pop()
            for edge in face.edges:
                if edge in protected_edges:
                    continue
                for other in edge.link_faces:
                    if other in remaining:
                        remaining.remove(other)
                        comp.add(other)
                        stack.append(other)
        components.append(comp)
    return components


def _shortest_face_corridor(
    region_faces,
    start_faces,
    goal_faces,
    protected_edges,
    matrix_world,
    center_cache,
):
    """Shortest face path used as an intentional narrow feature corridor.

    This path is fundamentally different from the old edge bridge. It leaves a
    thin strip of actual panel faces between a feature cell and the connected
    boundary network, so the surrounding panel can dissolve cleanly without a
    single giant diagonal edge spanning the model.
    """
    region_faces = set(region_faces)
    starts = {face for face in start_faces if face in region_faces and face.is_valid}
    goals = {face for face in goal_faces if face in region_faces and face.is_valid}
    if not starts or not goals:
        return None, float("inf")
    if starts & goals:
        face = next(iter(starts & goals))
        return [face], 0.0

    heap = []
    distance = {}
    previous = {}
    serial = 0
    for face in starts:
        distance[face] = 0.0
        heapq.heappush(heap, (0.0, serial, face))
        serial += 1

    reached = None
    while heap:
        dist, _serial, face = heapq.heappop(heap)
        if dist != distance.get(face):
            continue
        if face in goals:
            reached = face
            break
        center_a = _face_center_world_cached(face, matrix_world, center_cache)
        for edge in face.edges:
            if edge in protected_edges or len(edge.link_faces) != 2:
                continue
            other = edge.link_faces[0] if edge.link_faces[1] is face else edge.link_faces[1]
            if other not in region_faces or not other.is_valid:
                continue
            center_b = _face_center_world_cached(other, matrix_world, center_cache)
            step = max((center_b - center_a).length, 1e-12)
            # Slightly prefer crossing short shared edges. This avoids paths
            # wandering across very large faces when a compact local route is
            # available, while remaining deterministic and scale-independent.
            world_a = matrix_world @ edge.verts[0].co
            world_b = matrix_world @ edge.verts[1].co
            step += (world_b - world_a).length * 0.05
            new_dist = dist + step
            if new_dist + 1e-12 < distance.get(other, float("inf")):
                distance[other] = new_dist
                previous[other] = face
                heapq.heappush(heap, (new_dist, serial, other))
                serial += 1

    if reached is None:
        return None, float("inf")

    path = [reached]
    current = reached
    while current not in starts:
        current = previous.get(current)
        if current is None:
            return None, float("inf")
        path.append(current)
    path.reverse()
    return path, distance.get(reached, float("inf"))


def _build_feature_cell_cut_network(bm, region, protected_edges, matrix_world):
    """Build local topology cells and a minimal face-corridor cut network.

    Blender polygons cannot contain true holes. The old implementation solved
    that with long edge bridges, which was topologically valid but visually
    poor. Here each internal opening gets a compact local cell and those cells
    connect to the outer rim through one-face-wide corridors. Removing those
    cells/corridors from the planar remainder turns the remainder into simple
    patches that can be dissolved into large clean n-gons.
    """
    region_faces = {face for face in region.get("faces", set()) if face.is_valid}
    closed = [component for component in region.get("closed_boundary_components", []) if component.get("closed")]
    if len(closed) <= 1:
        return {
            "success": True,
            "feature_cells": [],
            "corridor_faces": set(),
            "outer_faces": set(),
            "outer_component": None,
            "opening_count": 0,
            "corridor_links": 0,
        }

    outer_component = max(closed, key=lambda component: component.get("perimeter", 0.0))
    inner_components = [component for component in closed if component is not outer_component]
    outer_faces = _faces_touching_boundary_component(outer_component, region_faces)
    if not outer_faces:
        return {"success": False, "reason": "outer boundary has no region faces"}

    # A single expansion ring is enough to localize most recess/socket
    # topology while preventing the cell from consuming large portions of the
    # panel. Cells may overlap; overlapping cells are merged naturally by the
    # connected cut network below.
    feature_cells = []
    for component in inner_components:
        seeds = _faces_touching_boundary_component(component, region_faces)
        if not seeds:
            return {"success": False, "reason": "opening has no adjacent faces"}
        cell_faces = _expand_feature_cell_faces(
            seeds, region_faces, protected_edges, rings=1
        )
        if not cell_faces:
            return {"success": False, "reason": "opening cell is empty"}
        feature_cells.append({
            "component": component,
            "faces": cell_faces,
        })

    center_cache = {}
    connected = set(outer_faces)
    corridor_faces = set()
    remaining = list(feature_cells)
    corridor_links = 0

    # Prim-like growth in face space. Each feature connects to whichever part
    # of the already-connected cut network is cheapest to reach. This avoids
    # the old star/spoke pattern and automatically shares corridors where
    # neighboring features are close together.
    safety = 0
    while remaining and safety < len(feature_cells) * 4 + 4:
        safety += 1
        best_index = None
        best_path = None
        best_cost = float("inf")
        for index, cell in enumerate(remaining):
            path, cost = _shortest_face_corridor(
                region_faces,
                cell["faces"],
                connected,
                protected_edges,
                matrix_world,
                center_cache,
            )
            if path and cost < best_cost:
                best_index = index
                best_path = path
                best_cost = cost

        if best_index is None or not best_path:
            return {"success": False, "reason": "could not route feature corridor"}

        chosen = remaining.pop(best_index)
        corridor_links += 1
        connected.update(chosen["faces"])
        connected.update(best_path)
        corridor_faces.update(best_path)

        # A newly-routed corridor can run through another feature cell. Treat
        # that as a valid shared connection rather than routing a duplicate
        # branch to the same area.
        newly_connected = []
        for cell in remaining:
            if cell["faces"] & connected:
                connected.update(cell["faces"])
                newly_connected.append(cell)
        if newly_connected:
            remaining = [cell for cell in remaining if cell not in newly_connected]

    if remaining:
        return {"success": False, "reason": "feature corridor network incomplete"}

    return {
        "success": True,
        "feature_cells": feature_cells,
        "corridor_faces": corridor_faces,
        "outer_faces": outer_faces,
        "outer_component": outer_component,
        "opening_count": len(inner_components),
        "corridor_links": corridor_links,
    }


def _collapse_planar_region_with_feature_cells(
    bm,
    region,
    protected_edges,
    matrix_world,
):
    """Collapse a planar region while keeping compact topology around holes.

    Returns metrics and leaves the region untouched when a clean cut network
    cannot be produced. This is local rollback by construction.
    """
    region_faces = {face for face in region.get("faces", set()) if face.is_valid}
    if len(region_faces) < 2:
        return {"success": False, "reason": "region too small"}

    network = _build_feature_cell_cut_network(
        bm, region, protected_edges, matrix_world
    )
    if not network.get("success"):
        return {
            "success": False,
            "reason": network.get("reason", "feature-cell network failed"),
        }

    feature_cell_faces = set()
    for cell in network.get("feature_cells", []):
        feature_cell_faces.update(
            face for face in cell.get("faces", set()) if face.is_valid
        )
    corridor_faces = {
        face for face in network.get("corridor_faces", set()) if face.is_valid
    }

    cut_faces = feature_cell_faces | corridor_faces
    remainder = {face for face in region_faces if face.is_valid and face not in cut_faces}

    # No openings: collapse the entire region directly.
    if not network.get("opening_count"):
        try:
            bmesh.ops.dissolve_faces(bm, faces=list(region_faces), use_verts=False)
            return {
                "success": True,
                "opening_count": 0,
                "feature_cells": 0,
                "feature_cell_faces": 0,
                "corridor_faces": 0,
                "corridor_links": 0,
                "panel_patches": 1,
            }
        except Exception as exc:
            return {"success": False, "reason": str(exc)}

    if not remainder:
        # Extremely dense feature cluster; retaining the local cells is safer
        # than forcing a destructive dissolve.
        return {
            "success": True,
            "opening_count": network.get("opening_count", 0),
            "feature_cells": len(network.get("feature_cells", [])),
            "feature_cell_faces": len(feature_cell_faces),
            "corridor_faces": len(corridor_faces),
            "corridor_links": network.get("corridor_links", 0),
            "panel_patches": 0,
        }

    components = _region_face_components(remainder, protected_edges=protected_edges)
    patches = 0
    for component in sorted(components, key=len, reverse=True):
        live_faces = [face for face in component if face.is_valid]
        if len(live_faces) < 2:
            continue
        try:
            bmesh.ops.dissolve_faces(bm, faces=live_faces, use_verts=False)
            patches += 1
        except Exception:
            # If one local patch cannot dissolve, leave that patch alone. The
            # rest of the panel still benefits from successful patch collapse.
            continue

    return {
        "success": True,
        "opening_count": network.get("opening_count", 0),
        "feature_cells": len(network.get("feature_cells", [])),
        "feature_cell_faces": len(feature_cell_faces),
        "corridor_faces": len(corridor_faces),
        "corridor_links": network.get("corridor_links", 0),
        "panel_patches": patches,
    }

def _build_world_bvh(mesh, matrix_world):
    verts = [matrix_world @ v.co for v in mesh.vertices]
    polygons = [tuple(poly.vertices) for poly in mesh.polygons if len(poly.vertices) >= 3]
    if not verts or not polygons:
        return None
    try:
        return BVHTree.FromPolygons(verts, polygons, all_triangles=False)
    except Exception:
        return None


def _sample_surface_points_world(mesh, matrix_world, max_samples=4000):
    """Sample points guaranteed to lie on Blender's rendered tessellation.

    Polygon.center is unsafe for concave n-gons because the center may lie
    outside the polygon. Sampling loop-triangle centroids avoids false
    deviation failures after planar regions are dissolved into n-gons.
    """
    mesh.calc_loop_triangles()
    triangles = mesh.loop_triangles
    count = len(triangles)
    if count == 0:
        return []
    step = max(1, math.ceil(count / max_samples))
    points = []
    for i in range(0, count, step):
        tri = triangles[i]
        a = matrix_world @ mesh.vertices[tri.vertices[0]].co
        b = matrix_world @ mesh.vertices[tri.vertices[1]].co
        c = matrix_world @ mesh.vertices[tri.vertices[2]].co
        points.append((a + b + c) / 3.0)
    return points


def _distance_summary(values):
    if not values:
        return {"max": 0.0, "mean": 0.0, "p95": 0.0, "p99": 0.0, "count": 0}
    ordered = sorted(float(v) for v in values)
    count = len(ordered)
    def pct(frac):
        idx = int(round((count - 1) * frac))
        idx = max(0, min(count - 1, idx))
        return ordered[idx]
    return {
        "max": ordered[-1],
        "mean": sum(ordered) / count,
        "p95": pct(0.95),
        "p99": pct(0.99),
        "count": count,
    }


def _measure_surface_deviation(source_obj, result_obj, max_samples=4000):
    """Measure bidirectional world-space surface error.

    Hard-surface retopology should not be rejected because of one isolated
    sample near an open boundary. Keep the absolute maximum for reporting, but
    also expose directional P95/P99 values so curved-panel validation can use
    robust surface coverage rather than a single worst-case point.
    """
    source_bvh = _build_world_bvh(source_obj.data, source_obj.matrix_world)
    result_bvh = _build_world_bvh(result_obj.data, result_obj.matrix_world)
    if source_bvh is None or result_bvh is None:
        return None

    result_to_source = []
    source_to_result = []

    for point in _sample_surface_points_world(result_obj.data, result_obj.matrix_world, max_samples):
        hit = source_bvh.find_nearest(point)
        if hit is not None and len(hit) >= 4 and hit[3] is not None:
            result_to_source.append(float(hit[3]))

    for point in _sample_surface_points_world(source_obj.data, source_obj.matrix_world, max_samples):
        hit = result_bvh.find_nearest(point)
        if hit is not None and len(hit) >= 4 and hit[3] is not None:
            source_to_result.append(float(hit[3]))

    r2s = _distance_summary(result_to_source)
    s2r = _distance_summary(source_to_result)
    combined_max = max(r2s["max"], s2r["max"])
    return {
        "max_distance": combined_max,
        "samples": r2s["count"] + s2r["count"],
        "result_to_source_max": r2s["max"],
        "result_to_source_mean": r2s["mean"],
        "result_to_source_p95": r2s["p95"],
        "result_to_source_p99": r2s["p99"],
        "source_to_result_max": s2r["max"],
        "source_to_result_mean": s2r["mean"],
        "source_to_result_p95": s2r["p95"],
        "source_to_result_p99": s2r["p99"],
    }


def _curved_deviation_acceptable(deviation, limit):
    """Robust acceptance rule for smooth/open hard-surface panels.

    After shrinkwrap, result->source should be extremely close. The reverse
    direction measures how well the new faces cover the original surface. We
    accept a small number of boundary outliers, but not broad shape drift.
    """
    if not deviation:
        return False
    r2s_p99 = deviation.get("result_to_source_p99", deviation.get("max_distance", 0.0))
    s2r_p95 = deviation.get("source_to_result_p95", deviation.get("max_distance", 0.0))
    s2r_p99 = deviation.get("source_to_result_p99", deviation.get("max_distance", 0.0))
    maximum = deviation.get("max_distance", float("inf"))
    return (
        r2s_p99 <= max(limit * 0.75, 1e-8)
        and s2r_p95 <= limit
        and s2r_p99 <= limit * 1.75
        and maximum <= limit * 4.0
    )

def _simplify_hardsurface_planar_regions(
    obj,
    feature_angle,
    planar_angle,
    min_edge_length,
    preserve_uv_seams=True,
    preserve_material_boundaries=True,
    preserve_sharp=True,
    use_symmetry=False,
    plane_distance_tolerance=1e-6,
):
    """Feature-cell hard-surface cleanup.

    v0.4 stops representing every opening with a long bridge edge. Planar
    regions are segmented first; embedded openings receive compact local cells
    and a minimal face-corridor cut network. The remaining simply-connected
    panel patches are dissolved into large n-gons.
    """
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    if len(bm.verts):
        min_x = min(v.co.x for v in bm.verts)
        max_x = max(v.co.x for v in bm.verts)
        span_x = max(max_x - min_x, 1e-9)
    else:
        span_x = 1.0
    symmetry_tolerance = span_x * 1e-6

    edges_before = len(bm.edges)
    faces_before = len(bm.faces)

    protected_edges, protected_stats = _hard_surface_protected_edges(
        bm,
        feature_angle=feature_angle,
        planar_angle=planar_angle,
        min_edge_length=min_edge_length,
        preserve_uv_seams=preserve_uv_seams,
        preserve_material_boundaries=preserve_material_boundaries,
        preserve_sharp=preserve_sharp,
        protect_symmetry_center=use_symmetry,
        symmetry_tolerance=symmetry_tolerance,
    )

    regions, skipped_nonplanar = _collect_planar_regions(
        bm,
        obj,
        protected_edges,
        planar_angle=planar_angle,
        feature_angle=feature_angle,
        plane_distance_tolerance=max(plane_distance_tolerance, 1e-10),
    )

    matrix_world = obj.matrix_world.copy()
    regions_simplified = 0
    regions_feature_failed = 0
    openings_protected = 0
    feature_cells = 0
    feature_cell_faces = 0
    corridor_faces = 0
    corridor_links = 0
    panel_patches = 0
    max_region_plane_error = 0.0

    # Process larger regions first. BMesh operations can invalidate face/edge
    # references in neighboring tiny regions; each iteration checks validity
    # and simply skips a region whose source faces were consumed already.
    ordered_regions = sorted(
        regions,
        key=lambda region: len(region.get("faces", set())),
        reverse=True,
    )

    for region in ordered_regions:
        live_region_faces = {
            face for face in region.get("faces", set()) if face.is_valid
        }
        if len(live_region_faces) < 2:
            continue
        region["faces"] = live_region_faces
        max_region_plane_error = max(
            max_region_plane_error, region.get("max_plane_error", 0.0)
        )

        result = _collapse_planar_region_with_feature_cells(
            bm, region, protected_edges, matrix_world
        )
        if not result.get("success"):
            regions_feature_failed += 1
            continue

        openings_protected += result.get("opening_count", 0)
        feature_cells += result.get("feature_cells", 0)
        feature_cell_faces += result.get("feature_cell_faces", 0)
        corridor_faces += result.get("corridor_faces", 0)
        corridor_links += result.get("corridor_links", 0)
        panel_patches += result.get("panel_patches", 0)
        regions_simplified += 1

    bm.normal_update()
    edges_after = len(bm.edges)
    faces_after = len(bm.faces)
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()

    return {
        "candidate_edges": max(0, edges_before - edges_after),
        "edges_before": edges_before,
        "edges_after": edges_after,
        "faces_before": faces_before,
        "faces_after": faces_after,
        "edges_removed": max(0, edges_before - edges_after),
        "faces_removed": max(0, faces_before - faces_after),
        "protected": protected_stats,
        "regions_found": len(regions),
        "regions_simplified": regions_simplified,
        "regions_skipped_nonplanar": skipped_nonplanar,
        "regions_bridge_failed": regions_feature_failed,
        "regions_feature_failed": regions_feature_failed,
        "openings_protected": openings_protected,
        # Compatibility keys retained so older UI/report code does not break.
        "bridge_edges_kept": corridor_faces,
        "bridge_direct_links": 0,
        "bridge_fallback_links": 0,
        # v0.4 diagnostics.
        "feature_cells": feature_cells,
        "feature_cell_faces": feature_cell_faces,
        "corridor_faces": corridor_faces,
        "corridor_links": corridor_links,
        "panel_patches": panel_patches,
        "max_region_plane_error": max_region_plane_error,
        "plane_distance_tolerance": plane_distance_tolerance,
    }

def _restore_from_snapshot(obj, snapshot_obj):
    restored_mesh = snapshot_obj.data.copy()
    old_mesh = obj.data
    obj.data = restored_mesh
    if old_mesh.users == 0:
        bpy.data.meshes.remove(old_mesh)


def _replace_object_mesh(obj, new_mesh):
    old_mesh = obj.data
    obj.data = new_mesh
    if old_mesh.users == 0:
        bpy.data.meshes.remove(old_mesh)


def _uv_discontinuity_ratio(mesh, max_edges=20000):
    """Estimate how fragmented the active UV map is across internal edges.

    Some imported glTF/CAD assets carry tiny UV discontinuities on a huge
    percentage of triangulation edges. Treating every one as a protected seam
    prevents any useful hard-surface cleanup. A high ratio is therefore a
    signal to preserve explicit Blender seams but let surface-transfer rebuild
    the UVs after topology cleanup.
    """
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        try:
            uv_layer = bm.loops.layers.uv.active
        except Exception:
            uv_layer = None
        if uv_layer is None:
            return 0.0
        internal = [edge for edge in bm.edges if len(edge.link_faces) == 2]
        if not internal:
            return 0.0
        step = max(1, math.ceil(len(internal) / max_edges))
        sampled = internal[::step]
        if not sampled:
            return 0.0
        discontinuous = sum(
            1 for edge in sampled if _edge_uv_discontinuity(edge, uv_layer, epsilon=1e-5)
        )
        return discontinuous / float(len(sampled))
    finally:
        bm.free()


def _apply_isolated_decimate(
    obj,
    context,
    decimate_type,
    angle_limit=0.0,
    ratio=1.0,
    preserve_uv_seams=True,
    preserve_material_boundaries=True,
    protect_uv_boundaries=True,
    use_symmetry=False,
):
    """Evaluate Blender's native Decimate modifier without touching the
    customer's modifier stack.

    A temporary mesh object is used so Bevel, Boolean, Mirror, Armature and
    other live modifiers on the real object cannot accidentally become baked
    into the remesh result.
    """
    temp_mesh = obj.data.copy()
    temp_obj = bpy.data.objects.new("FastRemesher_DecimateTemp", temp_mesh)
    temp_obj.matrix_world = obj.matrix_world.copy()
    context.collection.objects.link(temp_obj)

    try:
        mod = temp_obj.modifiers.new(name="FastRemesher_AdaptiveDecimate", type='DECIMATE')
        mod.decimate_type = decimate_type

        if decimate_type == 'DISSOLVE':
            mod.angle_limit = max(0.0, float(angle_limit))
            delimit = {'NORMAL'}
            if preserve_material_boundaries:
                delimit.add('MATERIAL')
            if preserve_uv_seams:
                delimit.add('SEAM')
                if protect_uv_boundaries:
                    delimit.add('UV')
            # Do not delimit by SHARP: CAD/glTF imports frequently mark every
            # triangulation edge sharp even when the surface is truly flat.
            try:
                mod.delimit = delimit
                mod.use_dissolve_boundaries = False
            except Exception:
                pass
        else:
            mod.ratio = max(0.01, min(float(ratio), 1.0))
            try:
                mod.use_collapse_triangulate = False
                mod.use_symmetry = bool(use_symmetry)
                mod.symmetry_axis = 'X'
            except Exception:
                pass

        context.view_layer.update()
        depsgraph = context.evaluated_depsgraph_get()
        evaluated = temp_obj.evaluated_get(depsgraph)
        result_mesh = bpy.data.meshes.new_from_object(evaluated)
    finally:
        bpy.data.objects.remove(temp_obj, do_unlink=True)
        if temp_mesh.users == 0:
            bpy.data.meshes.remove(temp_mesh)

    _replace_object_mesh(obj, result_mesh)
    obj.data.update()


def _boundary_component_count(mesh):
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        boundary = [edge for edge in bm.edges if len(edge.link_faces) == 1]
        if not boundary:
            return 0
        remaining = set(boundary)
        count = 0
        while remaining:
            count += 1
            seed = remaining.pop()
            stack = list(seed.verts)
            seen = set()
            while stack:
                vert = stack.pop()
                if vert in seen:
                    continue
                seen.add(vert)
                for edge in vert.link_edges:
                    if edge in remaining and len(edge.link_faces) == 1:
                        remaining.remove(edge)
                        stack.extend(edge.verts)
        return count
    finally:
        bm.free()


def _join_hardsurface_triangles(obj, face_angle=math.radians(25.0)):
    """Pair compatible triangles after Collapse decimation.

    Collapse is substantially more robust than a custom curved-surface
    reconstructor, but it naturally produces triangles. Blender's own BMesh
    join operator gives us a conservative quad recovery pass without moving
    vertices or inventing a new surface.
    """
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    before = len(bm.faces)
    triangles = [face for face in bm.faces if len(face.verts) == 3]
    if triangles:
        try:
            bmesh.ops.join_triangles(
                bm,
                faces=triangles,
                cmp_seam=False,
                cmp_sharp=False,
                cmp_uvs=False,
                cmp_vcols=False,
                cmp_materials=True,
                angle_face_threshold=face_angle,
                angle_shape_threshold=face_angle,
                topology_influence=0.5,
            )
        except TypeError:
            bmesh.ops.join_triangles(
                bm,
                faces=triangles,
                cmp_seam=False,
                cmp_sharp=False,
                cmp_uvs=False,
                cmp_vcols=False,
                cmp_materials=True,
                angle_face_threshold=face_angle,
                angle_shape_threshold=face_angle,
            )
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    return max(0, before - len(obj.data.polygons))


def _hard_surface_curvature_metrics(mesh, max_edges=30000):
    """Measure local hard-surface curvature from adjacent face angles.

    Smooth vehicle panels differ from triangulated flat CAD panels in one
    important way: many neighboring triangles have a small but non-zero
    dihedral angle. Flat imports are dominated by virtually zero-degree
    internal edges, with occasional large jumps only at real design features.
    """
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        internal = [edge for edge in bm.edges if len(edge.link_faces) == 2]
        if not internal:
            return {
                "samples": 0,
                "flat_ratio": 1.0,
                "gentle_ratio": 0.0,
                "sharp_ratio": 0.0,
                "median_angle_degrees": 0.0,
                "p75_angle_degrees": 0.0,
            }
        step = max(1, math.ceil(len(internal) / max_edges))
        sampled = internal[::step]
        angles = []
        flat = 0
        gentle = 0
        sharp = 0
        flat_limit = math.radians(0.25)
        gentle_limit = math.radians(12.0)
        for edge in sampled:
            angle = max(0.0, float(edge.calc_face_angle(0.0)))
            angles.append(angle)
            if angle <= flat_limit:
                flat += 1
            elif angle <= gentle_limit:
                gentle += 1
            else:
                sharp += 1
        angles.sort()
        count = max(1, len(angles))
        median = angles[min(count - 1, count // 2)]
        p75 = angles[min(count - 1, int((count - 1) * 0.75))]
        return {
            "samples": len(angles),
            "flat_ratio": flat / count,
            "gentle_ratio": gentle / count,
            "sharp_ratio": sharp / count,
            "median_angle_degrees": math.degrees(median),
            "p75_angle_degrees": math.degrees(p75),
        }
    finally:
        bm.free()


def _auto_hardsurface_profile(obj):
    """Choose the hard-surface engine from local curvature, not polygon type.

    This deliberately distinguishes a smooth tessellated car panel from a
    triangulated planar CAD panel. Both can be 100% triangles, so triangle
    ratio alone is not a useful classifier.
    """
    metrics = _hard_surface_curvature_metrics(obj.data)
    faces = len(obj.data.polygons)
    gentle = metrics["gentle_ratio"]
    flat = metrics["flat_ratio"]
    p75 = metrics["p75_angle_degrees"]

    # Smooth curved panels: a meaningful share of internal edges carry small,
    # continuous curvature rather than being exactly coplanar.
    if (
        gentle >= 0.22
        or (faces >= 800 and gentle >= 0.14 and flat < 0.72)
        or (faces >= 1200 and p75 >= 0.35 and p75 <= 12.0 and flat < 0.78)
    ):
        return "VEHICLE", metrics

    # Dense mostly-flat parts with many tiny feature transitions are better
    # handled as fine mechanical/greeble assets.
    dims = obj.dimensions
    bbox_diagonal = (dims.x ** 2 + dims.y ** 2 + dims.z ** 2) ** 0.5
    faces_per_unit = faces / bbox_diagonal if bbox_diagonal > 1e-9 else faces
    if faces_per_unit > 5000 and flat >= 0.55:
        return "GREEBLE", metrics

    return "MECHANICAL", metrics


def _hard_surface_profile(profile, detail_factor, planar_angle):
    profile = (profile or 'AUTO').upper()
    if profile == 'VEHICLE':
        return {
            "name": "VEHICLE",
            "detail_factor": 0.025,
            "planar_angles": [1.5, 1.0, 0.5, 0.25, 0.1],
            "curved": True,
            "min_collapse_ratio": 0.42,
            "quad_join_angle": 28.0,
        }
    if profile == 'GREEBLE':
        return {
            "name": "GREEBLE",
            "detail_factor": 0.004,
            "planar_angles": [1.5, 1.0, 0.5, 0.25, 0.1],
            "curved": False,
            "min_collapse_ratio": 0.78,
            "quad_join_angle": 18.0,
        }
    if profile == 'GAME_LOD':
        return {
            "name": "GAME_LOD",
            "detail_factor": 0.04,
            "planar_angles": [8.0, 5.0, 3.0, 2.0, 1.0],
            "curved": True,
            "min_collapse_ratio": 0.28,
            "quad_join_angle": 32.0,
        }
    if profile == 'CUSTOM':
        degrees = math.degrees(max(0.0, planar_angle))
        values = [degrees, degrees * 0.5, degrees * 0.25, 0.1]
        cleaned = []
        for value in values:
            value = max(0.0, min(value, 10.0))
            if not any(abs(value - existing) <= 1e-6 for existing in cleaned):
                cleaned.append(value)
        return {
            "name": "CUSTOM",
            "detail_factor": detail_factor,
            "planar_angles": cleaned,
            "curved": False,
            "min_collapse_ratio": 0.65,
            "quad_join_angle": 25.0,
        }
    return {
        "name": "MECHANICAL",
        "detail_factor": 0.012,
        "planar_angles": [5.0, 3.0, 2.0, 1.0, 0.5, 0.25],
        "curved": False,
        "min_collapse_ratio": 0.62,
        "quad_join_angle": 22.0,
    }


def _adaptive_planar_pass(
    obj,
    context,
    source_obj,
    deviation_limit,
    angle_degrees,
    preserve_uv_seams,
    preserve_material_boundaries,
    protect_uv_boundaries,
):
    source_faces = len(source_obj.data.polygons)
    source_boundaries = _boundary_component_count(source_obj.data)
    attempts = 0

    for degrees in angle_degrees:
        _restore_from_snapshot(obj, source_obj)
        attempts += 1
        _apply_isolated_decimate(
            obj,
            context,
            'DISSOLVE',
            angle_limit=math.radians(max(0.0, degrees)),
            preserve_uv_seams=preserve_uv_seams,
            preserve_material_boundaries=preserve_material_boundaries,
            protect_uv_boundaries=protect_uv_boundaries,
        )

        deviation = _measure_surface_deviation(source_obj, obj)
        measured = deviation.get("max_distance") if deviation else None
        boundaries = _boundary_component_count(obj.data)
        topology_safe = boundaries == source_boundaries
        geometry_safe = measured is not None and measured <= deviation_limit
        if topology_safe and geometry_safe:
            return {
                "success": True,
                "angle_degrees": degrees,
                "attempts": attempts,
                "faces_before": source_faces,
                "faces_after": len(obj.data.polygons),
                "deviation": deviation,
                "boundary_components": boundaries,
            }

    _restore_from_snapshot(obj, source_obj)
    return {
        "success": False,
        "angle_degrees": 0.0,
        "attempts": attempts,
        "faces_before": source_faces,
        "faces_after": source_faces,
        "deviation": {"max_distance": 0.0, "samples": 0},
        "boundary_components": source_boundaries,
    }


def _adaptive_collapse_curved_pass(
    obj,
    context,
    source_obj,
    deviation_limit,
    detail_factor,
    min_ratio,
    use_symmetry,
    quad_join_angle,
    preserve_uv_seams,
    preserve_material_boundaries,
):
    base_mesh = obj.data.copy()
    base_faces = len(base_mesh.polygons)
    source_boundaries = _boundary_component_count(source_obj.data)

    target_edge = resolve_target_edge_length(source_obj, detail_factor)
    surface_area = _world_surface_area(source_obj)
    if surface_area > 0.0 and target_edge > 0.0 and base_faces > 0:
        estimated_faces = max(64, int(round(surface_area / (target_edge * target_edge))))
        desired_ratio = estimated_faces / float(base_faces)
    else:
        desired_ratio = min_ratio
    desired_ratio = max(min_ratio, min(desired_ratio, 0.88))

    candidate_ratios = []
    for ratio in (
        desired_ratio,
        min(0.94, desired_ratio + (1.0 - desired_ratio) * 0.35),
        min(0.97, desired_ratio + (1.0 - desired_ratio) * 0.65),
        0.98,
    ):
        ratio = max(0.01, min(ratio, 0.99))
        if not any(abs(ratio - existing) <= 1e-4 for existing in candidate_ratios):
            candidate_ratios.append(ratio)

    attempts = 0
    best = None
    try:
        for ratio in candidate_ratios:
            _replace_object_mesh(obj, base_mesh.copy())
            attempts += 1
            _apply_isolated_decimate(
                obj,
                context,
                'COLLAPSE',
                ratio=ratio,
                use_symmetry=use_symmetry,
            )

            # Put surviving vertices back on the exact source surface. This is
            # especially useful for vehicle panels and dense CAD tessellation.
            _shrinkwrap_onto(obj, context, source_obj)
            quads_joined = _join_hardsurface_triangles(
                obj, face_angle=math.radians(quad_join_angle)
            )

            # A final tiny planar dissolve removes triangle pairs that landed
            # on truly flat patches after shrinkwrap.
            _apply_isolated_decimate(
                obj,
                context,
                'DISSOLVE',
                angle_limit=math.radians(0.35),
                preserve_uv_seams=preserve_uv_seams,
                preserve_material_boundaries=preserve_material_boundaries,
                protect_uv_boundaries=False,
            )

            deviation = _measure_surface_deviation(source_obj, obj)
            measured = deviation.get("max_distance") if deviation else None
            boundaries = _boundary_component_count(obj.data)
            if measured is None or measured > deviation_limit or boundaries != source_boundaries:
                continue

            best = {
                "success": True,
                "ratio": ratio,
                "attempts": attempts,
                "faces_before": base_faces,
                "faces_after": len(obj.data.polygons),
                "quads_joined": quads_joined,
                "deviation": deviation,
                "boundary_components": boundaries,
            }
            break
    finally:
        if base_mesh.users == 0:
            bpy.data.meshes.remove(base_mesh)

    if best is not None:
        return best
    return {
        "success": False,
        "ratio": 1.0,
        "attempts": attempts,
        "faces_before": base_faces,
        "faces_after": base_faces,
        "quads_joined": 0,
        "deviation": None,
        "boundary_components": source_boundaries,
    }


def _curved_candidate_status(source_obj, obj, deviation_limit, source_boundaries):
    deviation = _measure_surface_deviation(source_obj, obj)
    boundaries = _boundary_component_count(obj.data)
    if boundaries != source_boundaries:
        return False, "BOUNDARY", deviation, boundaries
    if not _curved_deviation_acceptable(deviation, deviation_limit):
        return False, "DEVIATION", deviation, boundaries
    return True, None, deviation, boundaries


def _adaptive_quadriflow_curved_pass(
    obj,
    context,
    source_obj,
    deviation_limit,
    candidate_ratios,
    use_symmetry,
    seed=0,
):
    """Native Blender quad fallback for smooth hard-surface panels."""
    source_faces = len(source_obj.data.polygons)
    source_boundaries = _boundary_component_count(source_obj.data)
    attempts = 0
    rejections = []
    last_error = None

    for ratio in candidate_ratios:
        _restore_from_snapshot(obj, source_obj)
        attempts += 1
        target_faces = max(64, int(round(source_faces * ratio)))
        try:
            context.view_layer.objects.active = obj
            obj.select_set(True)
            bpy.ops.object.quadriflow_remesh(
                target_faces=target_faces,
                use_mesh_symmetry=bool(use_symmetry),
                use_preserve_sharp=False,
                use_preserve_boundary=source_boundaries > 0,
                smooth_normals=False,
                mode='FACES',
                seed=seed,
            )
        except RuntimeError as exc:
            last_error = str(exc)
            rejections.append(f"QF{target_faces}:SOLVER")
            continue

        _shrinkwrap_onto(obj, context, source_obj)
        safe, reason, deviation, boundaries = _curved_candidate_status(
            source_obj, obj, deviation_limit, source_boundaries
        )
        if not safe:
            rejections.append(f"QF{target_faces}:{reason}")
            continue

        return {
            "success": True,
            "method": "QUADRIFLOW",
            "ratio": ratio,
            "target_faces": target_faces,
            "attempts": attempts,
            "faces_before": source_faces,
            "faces_after": len(obj.data.polygons),
            "quads_joined": 0,
            "quads": sum(1 for poly in obj.data.polygons if len(poly.vertices) == 4),
            "tris_remaining": sum(1 for poly in obj.data.polygons if len(poly.vertices) == 3),
            "deviation": deviation,
            "boundary_components": boundaries,
            "rejections": rejections,
            "error": None,
        }

    _restore_from_snapshot(obj, source_obj)
    return {
        "success": False,
        "method": "QUADRIFLOW",
        "ratio": 1.0,
        "target_faces": source_faces,
        "attempts": attempts,
        "faces_before": source_faces,
        "faces_after": source_faces,
        "quads_joined": 0,
        "deviation": None,
        "boundary_components": source_boundaries,
        "rejections": rejections,
        "error": last_error,
    }



def _vehicle_quad_recovery_pass(
    obj,
    source_obj,
    deviation_limit,
    preserve_uv_seams=True,
    preserve_material_boundaries=True,
    feature_angle=math.radians(30.0),
):
    """Recover export-triangulated vehicle panels back into quads in-place.

    Many glTF/FBX vehicle assets are authored as quads and triangulated only
    for interchange. In that case a full remesher is unnecessary and can make
    the surface worse. Blender's triangle pairing keeps every source vertex in
    place, so this path is both faster and much more faithful to Class-A-style
    curved panels. Multiple thresholds are tried automatically; only a result
    that preserves boundary topology and passes surface validation is kept.
    """
    source_faces = len(source_obj.data.polygons)
    source_boundaries = _boundary_component_count(source_obj.data)
    source_tris = sum(1 for poly in source_obj.data.polygons if len(poly.vertices) == 3)
    tri_ratio = source_tris / float(max(1, source_faces))

    if source_faces < 16 or tri_ratio < 0.55:
        return {
            "success": False,
            "method": "QUAD_RECOVERY",
            "attempts": 0,
            "faces_before": source_faces,
            "faces_after": source_faces,
            "quads_joined": 0,
            "quads": sum(1 for p in source_obj.data.polygons if len(p.vertices) == 4),
            "tris_remaining": source_tris,
            "deviation": None,
            "boundary_components": source_boundaries,
            "tri_ratio": tri_ratio,
            "rejections": ["RECOVERY:NOT_TRIANGULATED"],
            "error": None,
        }

    attempts = 0
    rejections = []
    best = None

    # Start permissive because the face-angle gate still prevents crossing
    # hard design edges. Fall back to stricter pairing if tessellation changes
    # produce measurable surface drift on non-planar triangle pairs.
    for face_deg, shape_deg, topo in (
        (40.0, 40.0, 1.50),
        (25.0, 35.0, 1.25),
        (12.0, 30.0, 1.00),
        (6.0, 25.0, 0.75),
    ):
        _restore_from_snapshot(obj, source_obj)
        attempts += 1

        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            manual_layer = _manual_preserve_layer(bm)
            temporary_seams = []
            protected_feature_edges = 0
            # Imported vehicle meshes often have meaningless Sharp flags, so
            # protect real geometric creases by measured dihedral angle instead.
            # A lower cap than the general feature angle protects panel seams,
            # bevel-band boundaries and wheel-arch creases while still allowing
            # gentle Class-A curvature to pair back into quads.
            geometric_feature_angle = min(
                max(math.radians(8.0), float(feature_angle) * 0.5),
                math.radians(18.0),
            )
            for edge in bm.edges:
                preserve = False
                if manual_layer is not None:
                    try:
                        preserve = int(edge[manual_layer]) != 0
                    except Exception:
                        preserve = False
                if not preserve and len(edge.link_faces) == 2:
                    try:
                        preserve = float(edge.calc_face_angle(0.0)) >= geometric_feature_angle
                    except Exception:
                        preserve = False
                if preserve:
                    protected_feature_edges += 1
                    if not edge.seam:
                        edge.seam = True
                        temporary_seams.append(edge)

            triangles = [face for face in bm.faces if len(face.verts) == 3]
            before = len(bm.faces)
            if triangles:
                bmesh.ops.join_triangles(
                    bm,
                    faces=triangles,
                    cmp_seam=bool(preserve_uv_seams or temporary_seams),
                    cmp_sharp=False,
                    # Surface-transfer rebuilds UVs after topology changes.
                    # Comparing UV corners here would freeze triangulated
                    # imported UV layouts and defeat recovery.
                    cmp_uvs=False,
                    cmp_vcols=False,
                    cmp_materials=bool(preserve_material_boundaries),
                    angle_face_threshold=math.radians(face_deg),
                    angle_shape_threshold=math.radians(shape_deg),
                    topology_influence=topo,
                    deselect_joined=False,
                )

            for edge in temporary_seams:
                if edge.is_valid:
                    edge.seam = False

            bm.to_mesh(obj.data)
            obj.data.update()
            after = len(obj.data.polygons)
        finally:
            bm.free()

        quads = sum(1 for poly in obj.data.polygons if len(poly.vertices) == 4)
        tris = sum(1 for poly in obj.data.polygons if len(poly.vertices) == 3)
        joined = max(0, before - after)
        reduction = joined / float(max(1, source_faces))
        boundaries = _boundary_component_count(obj.data)
        deviation = _measure_surface_deviation(source_obj, obj)

        if boundaries != source_boundaries:
            rejections.append(f"RECOVERY{face_deg:g}:BOUNDARY")
            continue
        if not _curved_deviation_acceptable(deviation, deviation_limit):
            max_dev = deviation.get("max_distance", 0.0) if deviation else 0.0
            p99 = deviation.get("source_to_result_p99", 0.0) if deviation else 0.0
            rejections.append(
                f"RECOVERY{face_deg:g}:DEVIATION(p99={p99:.4g},max={max_dev:.4g})"
            )
            continue

        result = {
            "success": joined > 0,
            "method": "QUAD_RECOVERY",
            "ratio": after / float(max(1, source_faces)),
            "target_faces": after,
            "attempts": attempts,
            "faces_before": source_faces,
            "faces_after": after,
            "quads_joined": joined,
            "quads": quads,
            "tris_remaining": tris,
            "deviation": deviation,
            "boundary_components": boundaries,
            "tri_ratio": tri_ratio,
            "recovery_face_angle": face_deg,
            "recovery_shape_angle": shape_deg,
            "feature_edges_protected": protected_feature_edges,
            "rejections": list(rejections),
            "error": None,
        }

        # A useful vehicle recovery should remove a meaningful amount of
        # interchange triangulation. Keep the best safe candidate and accept
        # immediately once roughly one fifth of the mesh has been recovered.
        if best is None or result["faces_after"] < best["faces_after"]:
            best_mesh = obj.data.copy()
            if best is not None and best.get("_mesh") is not None:
                old_best = best["_mesh"]
                if old_best.users == 0:
                    bpy.data.meshes.remove(old_best)
            best = dict(result)
            best["_mesh"] = best_mesh

        if reduction >= 0.18 and quads >= max(1, tris):
            if best is not None and best.get("_mesh") is not None:
                best_mesh = best.pop("_mesh")
                if best_mesh is not obj.data:
                    _replace_object_mesh(obj, best_mesh.copy())
                if best_mesh.users == 0:
                    bpy.data.meshes.remove(best_mesh)
                best["faces_after"] = len(obj.data.polygons)
                best["quads"] = sum(1 for p in obj.data.polygons if len(p.vertices) == 4)
                best["tris_remaining"] = sum(1 for p in obj.data.polygons if len(p.vertices) == 3)
                return best
            return result

    if best is not None and best.get("_mesh") is not None:
        # Even if recovery is modest, prefer an exact/safe improvement over
        # invoking a field remesher when at least 8% of the export diagonals
        # were recovered.
        best_reduction = 1.0 - best["faces_after"] / float(max(1, source_faces))
        best_mesh = best.pop("_mesh")
        if best_reduction >= 0.08:
            _replace_object_mesh(obj, best_mesh.copy())
            if best_mesh.users == 0:
                bpy.data.meshes.remove(best_mesh)
            best["faces_after"] = len(obj.data.polygons)
            best["quads"] = sum(1 for p in obj.data.polygons if len(p.vertices) == 4)
            best["tris_remaining"] = sum(1 for p in obj.data.polygons if len(p.vertices) == 3)
            return best
        if best_mesh.users == 0:
            bpy.data.meshes.remove(best_mesh)

    _restore_from_snapshot(obj, source_obj)
    return {
        "success": False,
        "method": "QUAD_RECOVERY",
        "ratio": 1.0,
        "target_faces": source_faces,
        "attempts": attempts,
        "faces_before": source_faces,
        "faces_after": source_faces,
        "quads_joined": 0,
        "quads": sum(1 for p in source_obj.data.polygons if len(p.vertices) == 4),
        "tris_remaining": source_tris,
        "deviation": None,
        "boundary_components": source_boundaries,
        "tri_ratio": tri_ratio,
        "feature_edges_protected": 0,
        "rejections": rejections,
        "error": None,
    }



def _quad_face_shape_metrics(mesh, poly):
    """Measure quad shape without punishing valid directional panel flow."""
    coords = [mesh.vertices[index].co.copy() for index in poly.vertices]
    eps = 1e-12
    lengths = []
    edges = []
    for i in range(4):
        edge = coords[(i + 1) % 4] - coords[i]
        edges.append(edge)
        lengths.append(max(edge.length, eps))

    min_length = min(lengths)
    max_length = max(lengths)
    aspect = max_length / max(min_length, eps)

    tri_a = (coords[1] - coords[0]).cross(coords[2] - coords[0])
    tri_b = (coords[2] - coords[0]).cross(coords[3] - coords[0])
    area = 0.5 * (tri_a.length + tri_b.length)
    area_ratio = area / max(max_length * max_length, eps)

    if tri_a.length > eps and tri_b.length > eps:
        twist_degrees = math.degrees(tri_a.angle(tri_b, 0.0))
        reference_normal = tri_a + tri_b
    else:
        twist_degrees = 180.0
        reference_normal = tri_a if tri_a.length > tri_b.length else tri_b

    if reference_normal.length > eps:
        reference_normal.normalize()

    min_corner = 180.0
    max_corner = 0.0
    valid_angles = True
    turn_signs = []
    for i in range(4):
        prev_vec = coords[(i - 1) % 4] - coords[i]
        next_vec = coords[(i + 1) % 4] - coords[i]
        if prev_vec.length <= eps or next_vec.length <= eps:
            valid_angles = False
            break
        angle = math.degrees(prev_vec.angle(next_vec, 0.0))
        min_corner = min(min_corner, angle)
        max_corner = max(max_corner, angle)
        if reference_normal.length > eps:
            turn = prev_vec.cross(next_vec).dot(reference_normal)
            if abs(turn) > eps:
                turn_signs.append(1 if turn > 0.0 else -1)

    concave = bool(turn_signs) and min(turn_signs) < 0 < max(turn_signs)

    alignment_values = []
    for a, b in ((edges[0], edges[2]), (edges[1], edges[3])):
        if a.length <= eps or b.length <= eps:
            alignment_values.append(0.0)
        else:
            alignment_values.append(abs(a.normalized().dot(b.normalized())))
    flow_alignment = min(alignment_values) if alignment_values else 0.0

    opposite_balance = 0.0
    balance_values = []
    for a, b in ((lengths[0], lengths[2]), (lengths[1], lengths[3])):
        balance_values.append(min(a, b) / max(max(a, b), eps))
    if balance_values:
        opposite_balance = min(balance_values)

    degenerate = (not valid_angles) or area <= eps or area_ratio < 0.008
    corner_extreme = valid_angles and (min_corner < 15.0 or max_corner > 165.0)
    strong_twist = twist_degrees > 35.0
    aspect_failure = (
        aspect > 20.0
        or (
            aspect > 12.0
            and (flow_alignment < 0.65 or min_corner < 28.0 or max_corner > 152.0)
        )
    )
    severe = bool(degenerate or concave or corner_extreme or strong_twist or aspect_failure)

    warning = bool(
        severe
        or min_corner < 25.0
        or max_corner > 155.0
        or twist_degrees > 22.0
        or flow_alignment < 0.45
        or (aspect > 8.0 and flow_alignment < 0.72)
        or aspect > 12.0
    )

    flow_aligned_elongated = bool(
        not severe
        and aspect > 8.0
        and flow_alignment >= 0.75
        and min_corner >= 28.0
        and max_corner <= 152.0
        and twist_degrees <= 20.0
    )

    return {
        "severe": severe,
        "warning": warning,
        "concave": concave,
        "degenerate": degenerate,
        "aspect": aspect,
        "area_ratio": area_ratio,
        "min_corner": min_corner if valid_angles else 0.0,
        "max_corner": max_corner if valid_angles else 180.0,
        "twist_degrees": twist_degrees,
        "flow_alignment": flow_alignment,
        "opposite_balance": opposite_balance,
        "flow_aligned_elongated": flow_aligned_elongated,
    }


def _quad_quality_metrics(mesh):
    """Return panel-aware quad quality statistics.

    Automotive and other hard-surface panels legitimately contain directional
    quads that are longer in one axis. Aspect ratio alone is therefore not a
    failure. A quad is considered genuinely bad only when elongation combines
    with poor flow/corner geometry, or when it is concave, degenerate, folded,
    or otherwise close to collapse.
    """
    quads = 0
    severe_bad = 0
    warnings = 0
    aligned_elongated = 0
    concave = 0
    twisted = 0
    worst_aspect = 1.0
    worst_corner_degrees = 90.0
    worst_twist_degrees = 0.0
    worst_flow_alignment = 1.0

    for poly in mesh.polygons:
        if len(poly.vertices) != 4:
            continue
        quads += 1
        metrics = _quad_face_shape_metrics(mesh, poly)
        if metrics["severe"]:
            severe_bad += 1
        if metrics["warning"]:
            warnings += 1
        if metrics["flow_aligned_elongated"]:
            aligned_elongated += 1
        if metrics["concave"]:
            concave += 1
        if metrics["twist_degrees"] > 35.0:
            twisted += 1

        worst_aspect = max(worst_aspect, metrics["aspect"])
        corner_extreme = min(metrics["min_corner"], 180.0 - metrics["max_corner"])
        worst_corner_degrees = min(worst_corner_degrees, corner_extreme)
        worst_twist_degrees = max(worst_twist_degrees, metrics["twist_degrees"])
        worst_flow_alignment = min(worst_flow_alignment, metrics["flow_alignment"])

    denominator = float(max(1, quads))
    return {
        "quads": quads,
        "bad_quads": severe_bad,
        "bad_quad_ratio": severe_bad / denominator,
        "warning_quads": warnings,
        "warning_quad_ratio": warnings / denominator,
        "flow_aligned_elongated": aligned_elongated,
        "flow_aligned_elongated_ratio": aligned_elongated / denominator,
        "concave_quads": concave,
        "twisted_quads": twisted,
        "worst_aspect": worst_aspect,
        "worst_corner_degrees": worst_corner_degrees,
        "worst_twist_degrees": worst_twist_degrees,
        "worst_flow_alignment": worst_flow_alignment,
    }


def _triangle_cluster_metrics(mesh):
    """Measure connected islands made only from residual triangle faces.

    Two triangles belong to the same cluster when they share a mesh edge.
    Large connected clusters are a much stronger signal of unfinished
    topology than a few isolated termination triangles.
    """
    tri_indices = {
        poly.index for poly in mesh.polygons if len(poly.vertices) == 3
    }
    if not tri_indices:
        return {
            "cluster_count": 0,
            "largest_cluster": 0,
            "large_clusters": 0,
            "isolated_triangles": 0,
            "clustered_triangles": 0,
            "clustered_triangle_ratio": 0.0,
            "sizes": [],
        }

    edge_faces = {}
    for poly in mesh.polygons:
        if poly.index not in tri_indices:
            continue
        verts = list(poly.vertices)
        for i, v1 in enumerate(verts):
            v2 = verts[(i + 1) % len(verts)]
            key = (v1, v2) if v1 < v2 else (v2, v1)
            edge_faces.setdefault(key, []).append(poly.index)

    adjacency = {idx: set() for idx in tri_indices}
    for faces in edge_faces.values():
        if len(faces) != 2:
            continue
        a, b = faces
        adjacency[a].add(b)
        adjacency[b].add(a)

    sizes = []
    pending = set(tri_indices)
    while pending:
        start = pending.pop()
        stack = [start]
        size = 1
        while stack:
            current = stack.pop()
            for neighbor in adjacency[current]:
                if neighbor in pending:
                    pending.remove(neighbor)
                    stack.append(neighbor)
                    size += 1
        sizes.append(size)

    sizes.sort(reverse=True)
    isolated = sum(1 for size in sizes if size == 1)
    clustered = sum(size for size in sizes if size >= 2)
    return {
        "cluster_count": len(sizes),
        "largest_cluster": sizes[0] if sizes else 0,
        "large_clusters": sum(1 for size in sizes if size >= 4),
        "isolated_triangles": isolated,
        "clustered_triangles": clustered,
        "clustered_triangle_ratio": clustered / float(max(1, len(tri_indices))),
        "sizes": sizes,
    }


def _topology_quality_metrics(mesh):
    """Score hard-surface topology using panel-aware quad quality."""
    faces = len(mesh.polygons)
    quads = sum(1 for poly in mesh.polygons if len(poly.vertices) == 4)
    tris = sum(1 for poly in mesh.polygons if len(poly.vertices) == 3)
    ngons = sum(1 for poly in mesh.polygons if len(poly.vertices) > 4)
    quad_ratio = quads / float(max(1, faces))
    quad_quality = _quad_quality_metrics(mesh)
    clusters = _triangle_cluster_metrics(mesh)

    edge_face_count = [0] * len(mesh.edges)
    vertex_valence = [0] * len(mesh.vertices)
    for edge in mesh.edges:
        vertex_valence[edge.vertices[0]] += 1
        vertex_valence[edge.vertices[1]] += 1
    edge_lookup = {}
    for edge in mesh.edges:
        a, b = edge.vertices
        key = (a, b) if a < b else (b, a)
        edge_lookup[key] = edge.index
    for poly in mesh.polygons:
        verts = list(poly.vertices)
        for i, v1 in enumerate(verts):
            v2 = verts[(i + 1) % len(verts)]
            key = (v1, v2) if v1 < v2 else (v2, v1)
            edge_index = edge_lookup.get(key)
            if edge_index is not None:
                edge_face_count[edge_index] += 1

    boundary_vertices = set()
    for edge in mesh.edges:
        if edge_face_count[edge.index] < 2:
            boundary_vertices.update(edge.vertices)

    interior = 0
    irregular_poles = 0
    high_valence_poles = 0
    for index, valence in enumerate(vertex_valence):
        if index in boundary_vertices or valence <= 0:
            continue
        interior += 1
        if valence != 4:
            irregular_poles += 1
        if valence >= 6:
            high_valence_poles += 1
    pole_ratio = irregular_poles / float(max(1, interior))

    tri_ratio = tris / float(max(1, faces))
    clustered_face_ratio = clusters["clustered_triangles"] / float(max(1, faces))
    severe_ratio = quad_quality["bad_quad_ratio"]
    warning_ratio = quad_quality["warning_quad_ratio"]

    score = 100.0 * (
        0.58 * quad_ratio
        + 0.18 * (1.0 - min(1.0, severe_ratio / 0.08))
        + 0.08 * (1.0 - min(1.0, warning_ratio / 0.25))
        + 0.10 * (1.0 - min(1.0, clustered_face_ratio / 0.25))
        + 0.06 * (1.0 - min(1.0, pole_ratio / 0.55))
    )
    score = max(0.0, min(100.0, score))

    largest = clusters["largest_cluster"]
    if quad_ratio >= 0.95 and severe_ratio <= 0.01 and warning_ratio <= 0.08 and largest <= 2:
        grade = "EXCELLENT"
    elif quad_ratio >= 0.90 and severe_ratio <= 0.02 and warning_ratio <= 0.12 and largest <= 4:
        grade = "CLEAN"
    elif quad_ratio >= 0.82 and severe_ratio <= 0.035 and warning_ratio <= 0.18 and largest <= 10:
        grade = "GOOD"
    elif quad_ratio >= 0.75 and severe_ratio <= 0.05 and warning_ratio <= 0.25:
        grade = "ACCEPTABLE"
    else:
        grade = "NEEDS_REFINEMENT"

    return {
        "score": score,
        "grade": grade,
        "faces": faces,
        "quads": quads,
        "tris": tris,
        "ngons": ngons,
        "quad_ratio": quad_ratio,
        "tri_ratio": tri_ratio,
        "bad_quads": quad_quality["bad_quads"],
        "bad_quad_ratio": severe_ratio,
        "warning_quads": quad_quality["warning_quads"],
        "warning_quad_ratio": warning_ratio,
        "flow_aligned_elongated": quad_quality["flow_aligned_elongated"],
        "flow_aligned_elongated_ratio": quad_quality["flow_aligned_elongated_ratio"],
        "concave_quads": quad_quality["concave_quads"],
        "twisted_quads": quad_quality["twisted_quads"],
        "worst_aspect": quad_quality["worst_aspect"],
        "worst_corner_degrees": quad_quality["worst_corner_degrees"],
        "worst_twist_degrees": quad_quality["worst_twist_degrees"],
        "worst_flow_alignment": quad_quality["worst_flow_alignment"],
        "interior_vertices": interior,
        "irregular_poles": irregular_poles,
        "high_valence_poles": high_valence_poles,
        "pole_ratio": pole_ratio,
        **clusters,
    }


def _bmesh_triangle_clusters(
    bm,
    preserve_uv_seams=True,
    preserve_material_boundaries=True,
    manual_layer=None,
):
    """Return residual triangle clusters split at protected design edges."""
    triangles = {face for face in bm.faces if len(face.verts) == 3}
    pending = set(triangles)
    clusters = []

    while pending:
        start = pending.pop()
        cluster = {start}
        stack = [start]
        while stack:
            face = stack.pop()
            for edge in face.edges:
                if len(edge.link_faces) != 2:
                    continue
                if preserve_uv_seams and edge.seam:
                    continue
                if manual_layer is not None:
                    try:
                        if int(edge[manual_layer]) != 0:
                            continue
                    except Exception:
                        pass
                f1, f2 = edge.link_faces
                other = f2 if f1 is face else f1
                if other not in triangles or other not in pending:
                    continue
                if preserve_material_boundaries and other.material_index != face.material_index:
                    continue
                pending.remove(other)
                cluster.add(other)
                stack.append(other)
        clusters.append(cluster)

    clusters.sort(key=len, reverse=True)
    return clusters


def _vehicle_local_triangle_refinement_pass(
    obj,
    source_obj,
    deviation_limit,
    preserve_uv_seams=True,
    preserve_material_boundaries=True,
):
    """Refine only connected residual-triangle clusters.

    Isolated termination triangles are deliberately left alone. Larger
    clusters receive local edge rotations and a more permissive pairing pass,
    but the candidate is kept only when whole-mesh topology quality improves
    and the already-proven geometry/boundary guarantees still pass.
    """
    baseline_mesh = obj.data.copy()
    baseline_boundaries = _boundary_component_count(obj.data)
    baseline_quality = _topology_quality_metrics(obj.data)

    if (
        baseline_quality["tris"] < 2
        or baseline_quality["grade"] in {"EXCELLENT", "CLEAN"}
        or baseline_quality["quad_ratio"] >= 0.97
        or baseline_quality["clustered_triangles"] < 2
    ):
        if baseline_mesh.users == 0:
            bpy.data.meshes.remove(baseline_mesh)
        return {
            "applied": False,
            "attempts": 0,
            "joined": 0,
            "quality_before": baseline_quality,
            "quality_after": baseline_quality,
            "rejections": [],
        }

    configs = (
        ("ANGLE", 18.0, 74.0, 78.0, 2.40, 2),
        ("AREA", 26.0, 84.0, 84.0, 2.70, 3),
        ("ANGLE", 34.0, 92.0, 88.0, 3.00, 4),
    )
    attempts = 0
    rejections = []
    best = None

    for method, rotate_deg, face_deg, shape_deg, topo, min_cluster in configs:
        _replace_object_mesh(obj, baseline_mesh.copy())
        attempts += 1
        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            manual_layer = _manual_preserve_layer(bm)
            temporary_seams = []
            if manual_layer is not None:
                for edge in bm.edges:
                    try:
                        if int(edge[manual_layer]) != 0 and not edge.seam:
                            edge.seam = True
                            temporary_seams.append(edge)
                    except Exception:
                        continue

            clusters = _bmesh_triangle_clusters(
                bm,
                preserve_uv_seams=preserve_uv_seams,
                preserve_material_boundaries=preserve_material_boundaries,
                manual_layer=manual_layer,
            )
            target_clusters = [cluster for cluster in clusters if len(cluster) >= min_cluster]
            if not target_clusters:
                for edge in temporary_seams:
                    if edge.is_valid:
                        edge.seam = False
                rejections.append(f"LOCAL{attempts}:NO_CLUSTER")
                continue

            target_faces = set().union(*target_clusters)
            eligible_edges = []
            rotate_limit = math.radians(rotate_deg)
            for edge in bm.edges:
                if len(edge.link_faces) != 2:
                    continue
                f1, f2 = edge.link_faces
                if f1 not in target_faces or f2 not in target_faces:
                    continue
                if preserve_uv_seams and edge.seam:
                    continue
                if preserve_material_boundaries and f1.material_index != f2.material_index:
                    continue
                try:
                    if edge.calc_face_angle(0.0) > rotate_limit:
                        continue
                except Exception:
                    continue
                eligible_edges.append(edge)

            if eligible_edges:
                try:
                    bmesh.ops.beautify_fill(
                        bm,
                        faces=list(target_faces),
                        edges=eligible_edges,
                        use_restrict_tag=False,
                        method=method,
                    )
                except (TypeError, RuntimeError, ValueError):
                    pass

            bm.faces.ensure_lookup_table()
            clusters = _bmesh_triangle_clusters(
                bm,
                preserve_uv_seams=preserve_uv_seams,
                preserve_material_boundaries=preserve_material_boundaries,
                manual_layer=manual_layer,
            )
            residual = [
                face
                for cluster in clusters
                if len(cluster) >= min_cluster
                for face in cluster
                if face.is_valid and len(face.verts) == 3
            ]
            before_join = len(bm.faces)
            if residual:
                try:
                    bmesh.ops.join_triangles(
                        bm,
                        faces=residual,
                        cmp_seam=bool(preserve_uv_seams or temporary_seams),
                        cmp_sharp=False,
                        cmp_uvs=False,
                        cmp_vcols=False,
                        cmp_materials=bool(preserve_material_boundaries),
                        angle_face_threshold=math.radians(face_deg),
                        angle_shape_threshold=math.radians(shape_deg),
                        topology_influence=topo,
                        deselect_joined=False,
                    )
                except TypeError:
                    bmesh.ops.join_triangles(
                        bm,
                        faces=residual,
                        cmp_seam=bool(preserve_uv_seams or temporary_seams),
                        cmp_sharp=False,
                        cmp_uvs=False,
                        cmp_vcols=False,
                        cmp_materials=bool(preserve_material_boundaries),
                        angle_face_threshold=math.radians(face_deg),
                        angle_shape_threshold=math.radians(shape_deg),
                    )

            for edge in temporary_seams:
                if edge.is_valid:
                    edge.seam = False

            bm.to_mesh(obj.data)
            obj.data.update()
            joined = max(0, before_join - len(obj.data.polygons))
        finally:
            bm.free()

        quality = _topology_quality_metrics(obj.data)
        boundaries = _boundary_component_count(obj.data)
        deviation = _measure_surface_deviation(source_obj, obj)

        if boundaries != baseline_boundaries:
            rejections.append(f"LOCAL{attempts}:BOUNDARY")
            continue
        if not _curved_deviation_acceptable(deviation, deviation_limit):
            rejections.append(f"LOCAL{attempts}:DEVIATION")
            continue
        if quality["tris"] >= baseline_quality["tris"]:
            rejections.append(f"LOCAL{attempts}:NO_TRI_GAIN")
            continue
        if quality["bad_quad_ratio"] > max(0.055, baseline_quality["bad_quad_ratio"] + 0.012):
            rejections.append(f"LOCAL{attempts}:QUAD_QUALITY")
            continue

        cluster_improved = (
            quality["clustered_triangles"] < baseline_quality["clustered_triangles"]
            or quality["largest_cluster"] < baseline_quality["largest_cluster"]
        )
        score_gain = quality["score"] - baseline_quality["score"]
        quad_gain = quality["quad_ratio"] - baseline_quality["quad_ratio"]
        if not cluster_improved or (score_gain < -0.75 and quad_gain < 0.025):
            rejections.append(f"LOCAL{attempts}:NO_QUALITY_GAIN")
            continue

        candidate_score = (
            quality["score"]
            + quality["quad_ratio"] * 8.0
            - quality["large_clusters"] * 0.75
            - quality["largest_cluster"] * 0.03
        )
        if best is None or candidate_score > best["candidate_score"]:
            if best is not None and best["mesh"].users == 0:
                bpy.data.meshes.remove(best["mesh"])
            best = {
                "mesh": obj.data.copy(),
                "candidate_score": candidate_score,
                "joined": joined,
                "quality": quality,
                "deviation": deviation,
                "method": method,
                "rotate_degrees": rotate_deg,
                "face_degrees": face_deg,
                "min_cluster": min_cluster,
            }

    if best is not None:
        _replace_object_mesh(obj, best["mesh"].copy())
        if best["mesh"].users == 0:
            bpy.data.meshes.remove(best["mesh"])
        if baseline_mesh.users == 0:
            bpy.data.meshes.remove(baseline_mesh)
        return {
            "applied": True,
            "attempts": attempts,
            "joined": max(0, baseline_quality["faces"] - best["quality"]["faces"]),
            "quality_before": baseline_quality,
            "quality_after": best["quality"],
            "method": best["method"],
            "rotate_degrees": best["rotate_degrees"],
            "face_degrees": best["face_degrees"],
            "min_cluster": best["min_cluster"],
            "deviation": best["deviation"],
            "rejections": rejections,
        }

    _replace_object_mesh(obj, baseline_mesh.copy())
    if baseline_mesh.users == 0:
        bpy.data.meshes.remove(baseline_mesh)
    return {
        "applied": False,
        "attempts": attempts,
        "joined": 0,
        "quality_before": baseline_quality,
        "quality_after": baseline_quality,
        "rejections": rejections,
    }

def _vehicle_quad_flow_optimization_pass(
    obj,
    context,
    source_obj,
    deviation_limit,
    preserve_uv_seams=True,
    preserve_material_boundaries=True,
):
    """Relax only genuinely malformed interior quads, then reproject.

    The pass does not change topology. Boundary vertices, UV seams, material
    borders, explicitly preserved edges, non-quad neighborhoods, poles, and
    high-curvature feature edges are excluded. Each candidate is shrinkwrapped
    back to the untouched source and retained only when severe quad quality
    improves without increasing geometric deviation beyond the vehicle budget.
    """
    baseline_mesh = obj.data.copy()
    baseline_boundaries = _boundary_component_count(obj.data)
    baseline_quality = _topology_quality_metrics(obj.data)

    if (
        baseline_quality["quads"] < 4
        or baseline_quality["bad_quads"] == 0
        or baseline_quality["bad_quad_ratio"] <= 0.01
    ):
        if baseline_mesh.users == 0:
            bpy.data.meshes.remove(baseline_mesh)
        return {
            "applied": False,
            "attempts": 0,
            "moved_vertices": 0,
            "quality_before": baseline_quality,
            "quality_after": baseline_quality,
            "rejections": [],
        }

    bad_face_indices = {
        poly.index
        for poly in obj.data.polygons
        if len(poly.vertices) == 4 and _quad_face_shape_metrics(obj.data, poly)["severe"]
    }
    if not bad_face_indices:
        if baseline_mesh.users == 0:
            bpy.data.meshes.remove(baseline_mesh)
        return {
            "applied": False,
            "attempts": 0,
            "moved_vertices": 0,
            "quality_before": baseline_quality,
            "quality_after": baseline_quality,
            "rejections": [],
        }

    attempts = 0
    rejections = []
    best = None
    configs = (0.04, 0.08, 0.12)
    feature_limit = math.radians(12.0)

    for factor in configs:
        _replace_object_mesh(obj, baseline_mesh.copy())
        attempts += 1
        bm = bmesh.new()
        target_count = 0
        try:
            bm.from_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            manual_layer = _manual_preserve_layer(bm)

            protected_verts = set()
            for edge in bm.edges:
                protect = len(edge.link_faces) != 2
                if preserve_uv_seams and edge.seam:
                    protect = True
                if manual_layer is not None:
                    try:
                        if int(edge[manual_layer]) != 0:
                            protect = True
                    except Exception:
                        pass
                if preserve_material_boundaries and len(edge.link_faces) == 2:
                    if edge.link_faces[0].material_index != edge.link_faces[1].material_index:
                        protect = True
                if len(edge.link_faces) == 2:
                    try:
                        if edge.calc_face_angle(0.0) > feature_limit:
                            protect = True
                    except Exception:
                        protect = True
                if protect:
                    protected_verts.update(edge.verts)

            target_verts = set()
            for face_index in bad_face_indices:
                if face_index >= len(bm.faces):
                    continue
                face = bm.faces[face_index]
                if not face.is_valid or len(face.verts) != 4:
                    continue
                for vert in face.verts:
                    if vert in protected_verts:
                        continue
                    if len(vert.link_edges) != 4:
                        continue
                    if any(len(link_face.verts) != 4 for link_face in vert.link_faces):
                        continue
                    target_verts.add(vert)

            target_count = len(target_verts)
            if not target_verts:
                rejections.append(f"FLOW{attempts}:NO_SAFE_VERTS")
                continue

            try:
                bmesh.ops.smooth_vert(
                    bm,
                    verts=list(target_verts),
                    factor=factor,
                    use_axis_x=True,
                    use_axis_y=True,
                    use_axis_z=True,
                )
            except TypeError:
                bmesh.ops.smooth_vert(bm, verts=list(target_verts), factor=factor)

            bm.to_mesh(obj.data)
            obj.data.update()
        finally:
            bm.free()

        _shrinkwrap_onto(obj, context, source_obj)
        quality = _topology_quality_metrics(obj.data)
        boundaries = _boundary_component_count(obj.data)
        deviation = _measure_surface_deviation(source_obj, obj)

        if boundaries != baseline_boundaries:
            rejections.append(f"FLOW{attempts}:BOUNDARY")
            continue
        if not _curved_deviation_acceptable(deviation, deviation_limit):
            rejections.append(f"FLOW{attempts}:DEVIATION")
            continue
        if quality["quads"] != baseline_quality["quads"] or quality["tris"] != baseline_quality["tris"]:
            rejections.append(f"FLOW{attempts}:TOPOLOGY")
            continue
        if quality["bad_quads"] >= baseline_quality["bad_quads"]:
            rejections.append(f"FLOW{attempts}:NO_BAD_GAIN")
            continue
        if quality["warning_quad_ratio"] > baseline_quality["warning_quad_ratio"] + 0.02:
            rejections.append(f"FLOW{attempts}:WARNINGS")
            continue
        if quality["score"] <= baseline_quality["score"] + 0.10:
            rejections.append(f"FLOW{attempts}:NO_SCORE_GAIN")
            continue

        candidate_score = (
            quality["score"]
            - quality["bad_quad_ratio"] * 35.0
            - quality["warning_quad_ratio"] * 5.0
        )
        if best is None or candidate_score > best["candidate_score"]:
            if best is not None and best["mesh"].users == 0:
                bpy.data.meshes.remove(best["mesh"])
            best = {
                "mesh": obj.data.copy(),
                "candidate_score": candidate_score,
                "quality": quality,
                "deviation": deviation,
                "factor": factor,
                "moved_vertices": target_count,
            }

    if best is not None:
        _replace_object_mesh(obj, best["mesh"].copy())
        if best["mesh"].users == 0:
            bpy.data.meshes.remove(best["mesh"])
        if baseline_mesh.users == 0:
            bpy.data.meshes.remove(baseline_mesh)
        return {
            "applied": True,
            "attempts": attempts,
            "moved_vertices": best["moved_vertices"],
            "factor": best["factor"],
            "quality_before": baseline_quality,
            "quality_after": best["quality"],
            "deviation": best["deviation"],
            "rejections": rejections,
        }

    _replace_object_mesh(obj, baseline_mesh.copy())
    if baseline_mesh.users == 0:
        bpy.data.meshes.remove(baseline_mesh)
    return {
        "applied": False,
        "attempts": attempts,
        "moved_vertices": 0,
        "quality_before": baseline_quality,
        "quality_after": baseline_quality,
        "rejections": rejections,
    }


def _vehicle_quad_completion_pass(
    obj,
    source_obj,
    deviation_limit,
    preserve_uv_seams=True,
    preserve_material_boundaries=True,
):
    """Improve residual vehicle triangles after safe quad recovery.

    The first recovery pass already restores the obvious export diagonals.
    Residual triangle islands often need a better local triangulation before
    Blender can identify additional high-quality pairs. Beautify Fill rotates
    only eligible triangle edges; Join Triangles then performs a second
    pairing pass. Vertices are never moved. Every candidate is compared with
    the accepted recovery baseline and rejected if boundary topology,
    deviation, or quad shape quality becomes worse.
    """
    baseline_mesh = obj.data.copy()
    baseline_faces = len(obj.data.polygons)
    baseline_boundaries = _boundary_component_count(obj.data)
    baseline_tris = sum(1 for p in obj.data.polygons if len(p.vertices) == 3)
    baseline_quality = _quad_quality_metrics(obj.data)
    baseline_quads = baseline_quality["quads"]
    baseline_quad_ratio = baseline_quads / float(max(1, baseline_faces))

    if baseline_tris < 2:
        if baseline_mesh.users == 0:
            bpy.data.meshes.remove(baseline_mesh)
        return {
            "applied": False,
            "attempts": 0,
            "quads_before": baseline_quads,
            "quads_after": baseline_quads,
            "tris_before": baseline_tris,
            "tris_after": baseline_tris,
            "joined": 0,
            "quad_ratio_before": baseline_quad_ratio,
            "quad_ratio_after": baseline_quad_ratio,
            "bad_quad_ratio": baseline_quality["bad_quad_ratio"],
            "rejections": [],
        }

    best = None
    attempts = 0
    rejections = []

    # The edge-rotation gate stays far below a real hard feature angle. The
    # join thresholds can be wider because surface deviation and quad-shape
    # validation still have final authority.
    configs = (
        ("ANGLE", 12.0, 48.0, 55.0, 1.75),
        ("AREA", 18.0, 58.0, 62.0, 2.00),
        ("ANGLE", 24.0, 68.0, 70.0, 2.25),
    )

    for method, rotate_deg, face_deg, shape_deg, topo in configs:
        _replace_object_mesh(obj, baseline_mesh.copy())
        attempts += 1

        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            manual_layer = _manual_preserve_layer(bm)
            temporary_seams = []
            if manual_layer is not None:
                for edge in bm.edges:
                    try:
                        if int(edge[manual_layer]) != 0 and not edge.seam:
                            edge.seam = True
                            temporary_seams.append(edge)
                    except Exception:
                        continue

            residual = [face for face in bm.faces if len(face.verts) == 3]
            eligible_edges = []
            rotate_limit = math.radians(rotate_deg)
            residual_set = set(residual)
            for edge in bm.edges:
                if len(edge.link_faces) != 2:
                    continue
                f1, f2 = edge.link_faces
                if f1 not in residual_set or f2 not in residual_set:
                    continue
                if preserve_uv_seams and edge.seam:
                    continue
                if preserve_material_boundaries and f1.material_index != f2.material_index:
                    continue
                try:
                    if edge.calc_face_angle(0.0) > rotate_limit:
                        continue
                except Exception:
                    continue
                eligible_edges.append(edge)

            if eligible_edges and residual:
                try:
                    bmesh.ops.beautify_fill(
                        bm,
                        faces=residual,
                        edges=eligible_edges,
                        use_restrict_tag=False,
                        method=method,
                    )
                except (TypeError, RuntimeError, ValueError):
                    # Beautification is an enhancement, not a requirement.
                    pass

            bm.faces.ensure_lookup_table()
            residual = [face for face in bm.faces if len(face.verts) == 3]
            before_join = len(bm.faces)
            if residual:
                try:
                    bmesh.ops.join_triangles(
                        bm,
                        faces=residual,
                        cmp_seam=bool(preserve_uv_seams or temporary_seams),
                        cmp_sharp=False,
                        cmp_uvs=False,
                        cmp_vcols=False,
                        cmp_materials=bool(preserve_material_boundaries),
                        angle_face_threshold=math.radians(face_deg),
                        angle_shape_threshold=math.radians(shape_deg),
                        topology_influence=topo,
                        deselect_joined=False,
                    )
                except TypeError:
                    bmesh.ops.join_triangles(
                        bm,
                        faces=residual,
                        cmp_seam=bool(preserve_uv_seams or temporary_seams),
                        cmp_sharp=False,
                        cmp_uvs=False,
                        cmp_vcols=False,
                        cmp_materials=bool(preserve_material_boundaries),
                        angle_face_threshold=math.radians(face_deg),
                        angle_shape_threshold=math.radians(shape_deg),
                    )

            for edge in temporary_seams:
                if edge.is_valid:
                    edge.seam = False

            bm.to_mesh(obj.data)
            obj.data.update()
            joined_this_pass = max(0, before_join - len(obj.data.polygons))
        finally:
            bm.free()

        faces_after = len(obj.data.polygons)
        quads_after = sum(1 for p in obj.data.polygons if len(p.vertices) == 4)
        tris_after = sum(1 for p in obj.data.polygons if len(p.vertices) == 3)
        quad_ratio = quads_after / float(max(1, faces_after))
        quality = _quad_quality_metrics(obj.data)
        boundaries = _boundary_component_count(obj.data)
        deviation = _measure_surface_deviation(source_obj, obj)

        if boundaries != baseline_boundaries:
            rejections.append(f"COMPLETE{attempts}:BOUNDARY")
            continue
        if not _curved_deviation_acceptable(deviation, deviation_limit):
            rejections.append(f"COMPLETE{attempts}:DEVIATION")
            continue

        # Completion may introduce a handful of naturally elongated quads at
        # panel terminations, but it must not materially worsen shape quality.
        allowed_bad = max(
            baseline_quality["bad_quad_ratio"] + 0.025,
            0.04,
        )
        if quality["bad_quad_ratio"] > allowed_bad:
            rejections.append(f"COMPLETE{attempts}:QUAD_QUALITY")
            continue
        if quad_ratio <= baseline_quad_ratio + 0.005 or tris_after >= baseline_tris:
            rejections.append(f"COMPLETE{attempts}:NO_GAIN")
            continue

        candidate_score = (
            quad_ratio
            - quality["bad_quad_ratio"] * 0.75
            - (tris_after / float(max(1, faces_after))) * 0.10
        )
        if best is None or candidate_score > best["score"]:
            if best is not None and best["mesh"].users == 0:
                bpy.data.meshes.remove(best["mesh"])
            best = {
                "mesh": obj.data.copy(),
                "score": candidate_score,
                "faces_after": faces_after,
                "quads_after": quads_after,
                "tris_after": tris_after,
                "quad_ratio": quad_ratio,
                "quality": quality,
                "deviation": deviation,
                "joined_this_pass": joined_this_pass,
                "method": method,
                "rotate_degrees": rotate_deg,
                "face_degrees": face_deg,
            }

    if best is not None:
        _replace_object_mesh(obj, best["mesh"].copy())
        if best["mesh"].users == 0:
            bpy.data.meshes.remove(best["mesh"])
        if baseline_mesh.users == 0:
            bpy.data.meshes.remove(baseline_mesh)
        return {
            "applied": True,
            "attempts": attempts,
            "quads_before": baseline_quads,
            "quads_after": best["quads_after"],
            "tris_before": baseline_tris,
            "tris_after": best["tris_after"],
            "joined": max(0, baseline_faces - best["faces_after"]),
            "quad_ratio_before": baseline_quad_ratio,
            "quad_ratio_after": best["quad_ratio"],
            "bad_quad_ratio": best["quality"]["bad_quad_ratio"],
            "method": best["method"],
            "rotate_degrees": best["rotate_degrees"],
            "face_degrees": best["face_degrees"],
            "deviation": best["deviation"],
            "rejections": rejections,
        }

    _replace_object_mesh(obj, baseline_mesh.copy())
    if baseline_mesh.users == 0:
        bpy.data.meshes.remove(baseline_mesh)
    return {
        "applied": False,
        "attempts": attempts,
        "quads_before": baseline_quads,
        "quads_after": baseline_quads,
        "tris_before": baseline_tris,
        "tris_after": baseline_tris,
        "joined": 0,
        "quad_ratio_before": baseline_quad_ratio,
        "quad_ratio_after": baseline_quad_ratio,
        "bad_quad_ratio": baseline_quality["bad_quad_ratio"],
        "rejections": rejections,
    }

def _adaptive_curved_pass(
    obj,
    context,
    source_obj,
    deviation_limit,
    detail_factor,
    min_ratio,
    use_symmetry,
    quad_join_angle,
    preserve_uv_seams,
    preserve_material_boundaries,
    feature_angle=math.radians(30.0),
    max_input_faces=150000,
    seed=0,
):
    """Retopologize smooth hard-surface panels with quad-first backends.

    Instant Meshes is preferred for coherent field-aligned flow. Blender's
    QuadriFlow is a second independent quad backend. A vehicle panel is never
    accepted merely because a triangle decimator managed to reduce it.
    """
    source_faces = len(source_obj.data.polygons)
    source_boundaries = _boundary_component_count(source_obj.data)
    target_edge = resolve_target_edge_length(source_obj, detail_factor)
    surface_area = _world_surface_area(source_obj)

    if surface_area > 0.0 and target_edge > 0.0 and source_faces > 0:
        estimated_faces = max(64, int(round(surface_area / (target_edge * target_edge))))
        estimated_ratio = estimated_faces / float(source_faces)
    else:
        estimated_ratio = min_ratio

    primary = max(min_ratio, min(estimated_ratio, 0.65))
    candidate_ratios = []
    for ratio in (
        primary,
        min(0.76, primary + (1.0 - primary) * 0.28),
        min(0.86, primary + (1.0 - primary) * 0.52),
        0.93,
    ):
        ratio = max(0.20, min(float(ratio), 0.96))
        if not any(abs(ratio - existing) <= 1e-4 for existing in candidate_ratios):
            candidate_ratios.append(ratio)

    attempts = 0
    last_error = None
    rejections = []

    # First recover quads that were likely triangulated only for export. This
    # keeps all source vertices fixed and is the safest path for car doors,
    # windshields, body panels, and other tessellated production assets.
    recovery = _vehicle_quad_recovery_pass(
        obj,
        source_obj,
        deviation_limit,
        preserve_uv_seams=preserve_uv_seams,
        preserve_material_boundaries=preserve_material_boundaries,
        feature_angle=feature_angle,
    )
    attempts += recovery.get("attempts", 0)
    rejections.extend(recovery.get("rejections", []))
    if recovery.get("success"):
        completion = _vehicle_quad_completion_pass(
            obj,
            source_obj,
            deviation_limit,
            preserve_uv_seams=preserve_uv_seams,
            preserve_material_boundaries=preserve_material_boundaries,
        )
        attempts += completion.get("attempts", 0)
        rejections.extend(completion.get("rejections", []))
        recovery["attempts"] = attempts
        recovery["rejections"] = rejections
        recovery["quad_completion"] = completion
        recovery["completion_joined"] = completion.get("joined", 0)
        recovery["quads_joined"] = recovery.get("quads_joined", 0) + completion.get("joined", 0)
        if completion.get("applied") and completion.get("deviation"):
            recovery["deviation"] = completion["deviation"]

        local_refinement = _vehicle_local_triangle_refinement_pass(
            obj,
            source_obj,
            deviation_limit,
            preserve_uv_seams=preserve_uv_seams,
            preserve_material_boundaries=preserve_material_boundaries,
        )
        attempts += local_refinement.get("attempts", 0)
        rejections.extend(local_refinement.get("rejections", []))
        recovery["attempts"] = attempts
        recovery["rejections"] = rejections
        recovery["local_refinement"] = local_refinement
        recovery["quads_joined"] += local_refinement.get("joined", 0)
        if local_refinement.get("applied") and local_refinement.get("deviation"):
            recovery["deviation"] = local_refinement["deviation"]

        flow_optimization = _vehicle_quad_flow_optimization_pass(
            obj,
            context,
            source_obj,
            deviation_limit,
            preserve_uv_seams=preserve_uv_seams,
            preserve_material_boundaries=preserve_material_boundaries,
        )
        attempts += flow_optimization.get("attempts", 0)
        rejections.extend(flow_optimization.get("rejections", []))
        recovery["attempts"] = attempts
        recovery["rejections"] = rejections
        recovery["flow_optimization"] = flow_optimization
        if flow_optimization.get("applied") and flow_optimization.get("deviation"):
            recovery["deviation"] = flow_optimization["deviation"]

        recovery["faces_after"] = len(obj.data.polygons)
        recovery["quads"] = sum(1 for p in obj.data.polygons if len(p.vertices) == 4)
        recovery["tris_remaining"] = sum(1 for p in obj.data.polygons if len(p.vertices) == 3)
        recovery["quad_ratio"] = recovery["quads"] / float(max(1, recovery["faces_after"]))
        recovery["topology_quality"] = _topology_quality_metrics(obj.data)
        return recovery

    try:
        from . import core_instantmeshes

        for ratio in candidate_ratios:
            _restore_from_snapshot(obj, source_obj)
            attempts += 1
            target_faces = max(64, int(round(source_faces * ratio)))
            try:
                im_result = core_instantmeshes.run_instant_meshes(
                    obj,
                    context,
                    target_faces,
                    deterministic=True,
                    crease_angle_degrees=max(12.0, min(55.0, math.degrees(feature_angle))),
                    max_input_faces=max_input_faces,
                    align_boundaries=source_boundaries > 0,
                    transfer_surface_data=False,
                    clamp_to_target=False,
                )
            except (FileNotFoundError, RuntimeError, subprocess.SubprocessError) as exc:
                last_error = str(exc)
                rejections.append("IM:SOLVER")
                break

            _shrinkwrap_onto(obj, context, source_obj)
            safe, reason, deviation, boundaries = _curved_candidate_status(
                source_obj, obj, deviation_limit, source_boundaries
            )
            if not safe:
                max_dev = deviation.get("max_distance", 0.0) if deviation else 0.0
                p99 = deviation.get("source_to_result_p99", 0.0) if deviation else 0.0
                rejections.append(
                    f"IM{target_faces}:{reason}(p99={p99:.4g},max={max_dev:.4g},b={boundaries})"
                )
                continue

            tris_remaining = sum(1 for poly in obj.data.polygons if len(poly.vertices) == 3)
            quads = sum(1 for poly in obj.data.polygons if len(poly.vertices) == 4)
            return {
                "success": True,
                "method": "INSTANT_MESHES",
                "ratio": ratio,
                "target_faces": target_faces,
                "attempts": attempts,
                "faces_before": source_faces,
                "faces_after": len(obj.data.polygons),
                "quads_joined": 0,
                "quads": quads,
                "tris_remaining": tris_remaining,
                "deviation": deviation,
                "boundary_components": boundaries,
                "instant_meshes": im_result,
                "rejections": rejections,
                "error": None,
            }
    except Exception as exc:
        last_error = str(exc)
        rejections.append("IM:EXCEPTION")

    # If Instant Meshes cannot produce a valid panel, try Blender's native
    # quad solver before considering any triangle-based fallback.
    qf = _adaptive_quadriflow_curved_pass(
        obj,
        context,
        source_obj,
        deviation_limit,
        candidate_ratios,
        use_symmetry,
        seed=seed,
    )
    qf["attempts"] = attempts + qf.get("attempts", 0)
    qf["rejections"] = rejections + qf.get("rejections", [])
    if qf.get("success"):
        if last_error and not qf.get("error"):
            qf["error"] = last_error
        return qf

    # For VEHICLE-style topology, a stretched-triangle collapse is not a
    # successful remesh. Return failure so the untouched source is restored.
    _restore_from_snapshot(obj, source_obj)
    return {
        "success": False,
        "method": "QUAD_BACKENDS_FAILED",
        "ratio": 1.0,
        "target_faces": source_faces,
        "attempts": qf.get("attempts", attempts),
        "faces_before": source_faces,
        "faces_after": source_faces,
        "quads_joined": 0,
        "deviation": None,
        "boundary_components": source_boundaries,
        "rejections": qf.get("rejections", rejections),
        "error": qf.get("error") or last_error,
    }

def safe_post_cleanup(obj):
    """Remove only numerically degenerate geometry after a successful solve.

    This deliberately avoids broad merge-by-distance or dissolve operations.
    The tolerances are several orders below the remesh deviation budget, so
    this pass removes only zero-length/degenerate and loose artifacts without
    becoming another topology simplifier.
    """
    if obj is None or obj.type != 'MESH':
        return {"changed": False, "verts_removed": 0, "edges_removed": 0, "faces_removed": 0}

    mesh = obj.data
    before = (len(mesh.vertices), len(mesh.edges), len(mesh.polygons))
    dims = obj.dimensions
    diag = math.sqrt(dims.x * dims.x + dims.y * dims.y + dims.z * dims.z)
    degenerate_dist = max(diag * 1.0e-12, 1.0e-14)

    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        # Do not run global Merge by Distance here. Coincident vertices can
        # be intentional across separate shells, mirrors, or layered panels.
        if bm.edges:
            bmesh.ops.dissolve_degenerate(bm, edges=list(bm.edges), dist=degenerate_dist)
        loose_verts = [vert for vert in bm.verts if not vert.link_edges]
        if loose_verts:
            bmesh.ops.delete(bm, geom=loose_verts, context='VERTS')
        bm.normal_update()
        bm.to_mesh(mesh)
    finally:
        bm.free()
    mesh.validate(verbose=False, clean_customdata=False)
    mesh.update()

    after = (len(mesh.vertices), len(mesh.edges), len(mesh.polygons))
    return {
        "changed": before != after,
        "verts_removed": max(0, before[0] - after[0]),
        "edges_removed": max(0, before[1] - after[1]),
        "faces_removed": max(0, before[2] - after[2]),
    }


def run_hardsurface(
    obj,
    context,
    detail_factor,
    feature_angle=0.4363,
    max_input_faces=100000,
    seed=0,
    min_edge_length=0.0,
    use_symmetry=False,
    planar_angle=0.0174533,
    preserve_uv_seams=True,
    preserve_material_boundaries=True,
    profile='MECHANICAL',
    transfer_surface_data=True,
):
    """Adaptive hard-surface cleanup with quad-first curved retopology.

    Planar-heavy assets use Blender's native Planar Decimate. Smooth vehicle
    panels use Instant Meshes first and Blender QuadriFlow second. Curved
    candidates are shrinkwrapped and validated with robust bidirectional
    surface statistics so a single boundary outlier cannot discard a good
    result.
    """
    mesh_before = obj.data
    verts_before = len(mesh_before.vertices)
    faces_before = len(mesh_before.polygons)
    edges_before = len(mesh_before.edges)
    requested_profile = (profile or 'AUTO').upper()
    auto_metrics = None
    if requested_profile == 'AUTO':
        detected_profile, auto_metrics = _auto_hardsurface_profile(obj)
    else:
        detected_profile = requested_profile
        auto_metrics = _hard_surface_curvature_metrics(obj.data)
    config = _hard_surface_profile(detected_profile, detail_factor, planar_angle)
    effective_detail_factor = config.get("detail_factor", detail_factor)
    target_feature_size = resolve_target_edge_length(obj, effective_detail_factor)

    dims = obj.dimensions
    bbox_diagonal = (dims.x ** 2 + dims.y ** 2 + dims.z ** 2) ** 0.5
    if bbox_diagonal <= 0.0:
        bbox_diagonal = 1.0

    deviation_limit = max(target_feature_size * 0.02, bbox_diagonal * 1e-7, 1e-8)
    curved_deviation_limit = max(
        target_feature_size * 0.05,
        bbox_diagonal * 3.0e-4,
        1e-8,
    )

    view_layer = context.view_layer
    prev_active = view_layer.objects.active
    view_layer.objects.active = obj

    snapshot_obj = _make_original_snapshot(obj, context)
    circles = _detect_circular_boundary_loops(snapshot_obj.data)
    large_input = faces_before > max_input_faces
    planar_result = None
    curved_result = None
    transfer_result = None
    cleanup_result = {"changed": False, "verts_removed": 0, "edges_removed": 0, "faces_removed": 0}
    validation_fallback = False
    uv_discontinuity_ratio = 0.0
    protect_uv_boundaries = True

    try:
        uv_discontinuity_ratio = _uv_discontinuity_ratio(snapshot_obj.data) if preserve_uv_seams else 0.0
        # If more than roughly a quarter of internal edges are separate UV
        # borders, the asset is almost certainly carrying imported per-face UV
        # fragmentation. Protect explicit seams, but let our working surface
        # transfer rebuild the UVs rather than freezing the triangulation.
        protect_uv_boundaries = uv_discontinuity_ratio < 0.25

        # Curved panels must never go through Planar Decimate first. Doing so
        # destroys the continuous curvature field before retopology even sees
        # it. Mechanical/greeble assets still get the native planar pass.
        if config["curved"]:
            planar_result = {
                "success": False,
                "angle_degrees": 0.0,
                "attempts": 0,
                "faces_before": faces_before,
                "faces_after": faces_before,
                "deviation": None,
                "boundary_components": _boundary_component_count(snapshot_obj.data),
            }
            _restore_from_snapshot(obj, snapshot_obj)
            curved_result = _adaptive_curved_pass(
                obj,
                context,
                snapshot_obj,
                curved_deviation_limit,
                effective_detail_factor,
                config["min_collapse_ratio"],
                use_symmetry,
                config["quad_join_angle"],
                preserve_uv_seams,
                preserve_material_boundaries,
                feature_angle=feature_angle,
                max_input_faces=max_input_faces,
                seed=seed,
            )
        else:
            planar_result = _adaptive_planar_pass(
                obj,
                context,
                snapshot_obj,
                deviation_limit,
                config["planar_angles"],
                preserve_uv_seams,
                preserve_material_boundaries,
                protect_uv_boundaries,
            )

            planar_faces = len(obj.data.polygons)
            planar_reduction = 0.0
            if faces_before > 0:
                planar_reduction = max(0.0, (faces_before - planar_faces) / faces_before)

            # Only dense mechanical meshes that received virtually no planar
            # cleanup get a curved fallback. Small props remain purely planar.
            if faces_before >= 3000 and planar_reduction < 0.04:
                planar_backup = obj.data.copy()
                curved_result = _adaptive_curved_pass(
                    obj,
                    context,
                    snapshot_obj,
                    max(deviation_limit, curved_deviation_limit),
                    effective_detail_factor,
                    max(0.70, config["min_collapse_ratio"]),
                    use_symmetry,
                    config["quad_join_angle"],
                    preserve_uv_seams,
                    preserve_material_boundaries,
                    feature_angle=feature_angle,
                    max_input_faces=max_input_faces,
                    seed=seed,
                )
                if not curved_result.get("success"):
                    _replace_object_mesh(obj, planar_backup.copy())
                if planar_backup.users == 0:
                    bpy.data.meshes.remove(planar_backup)

        cleanup_result = safe_post_cleanup(obj)
        final_deviation = _measure_surface_deviation(snapshot_obj, obj)
        boundary_safe = (
            _boundary_component_count(obj.data)
            == _boundary_component_count(snapshot_obj.data)
        )
        curved_candidate_active = bool(curved_result and curved_result.get("success"))
        if curved_candidate_active:
            geometry_safe = _curved_deviation_acceptable(
                final_deviation, curved_deviation_limit
            )
        else:
            final_distance = final_deviation.get("max_distance") if final_deviation else None
            geometry_safe = final_distance is not None and final_distance <= deviation_limit
        if not geometry_safe or not boundary_safe:
            _restore_from_snapshot(obj, snapshot_obj)
            validation_fallback = True
            final_deviation = {"max_distance": 0.0, "samples": 0}

        if transfer_surface_data:
            transfer_result = transfer_uv_and_materials(obj, context)
        else:
            # Live Preview only needs the final geometry. Skipping the
            # production data-transfer stage keeps preview rebuilds fast and
            # avoids creating/looking up permanent backup data for the
            # temporary preview object. The real Apply/Remesh operation still
            # runs the full preservation pipeline.
            transfer_result = {
                "success": True,
                "preview_only": True,
                "uv_layers": 0,
                "vertex_groups": 0,
                "weighted_vertices": 0,
                "armature_bound": False,
            }
    finally:
        _cleanup_snapshot(snapshot_obj)
        view_layer.objects.active = prev_active

    new_mesh = obj.data
    tris_remaining = sum(1 for poly in new_mesh.polygons if len(poly.vertices) == 3)
    quad_count = sum(1 for poly in new_mesh.polygons if len(poly.vertices) == 4)
    ngons = sum(1 for poly in new_mesh.polygons if len(poly.vertices) > 4)
    reduction_percent = 0.0
    if faces_before > 0:
        reduction_percent = max(
            0.0,
            (faces_before - len(new_mesh.polygons)) / faces_before * 100.0,
        )

    curved_success = bool(
        curved_result and curved_result.get("success") and not validation_fallback
    )
    planar_success = bool(
        planar_result and planar_result.get("success") and not validation_fallback
    )
    if curved_success:
        curved_method = (curved_result or {}).get("method", "CURVED")
        engine = "CURVED_QUAD" if curved_method in {"QUAD_RECOVERY", "INSTANT_MESHES", "QUADRIFLOW"} else "ADAPTIVE_CURVED"
    elif planar_success:
        engine = "ADAPTIVE_PLANAR"
    else:
        engine = "SAFE_FALLBACK"

    # The snapshot has already been cleaned up; the accepted pass stored its
    # own measured deviation. Prefer curved data when present, otherwise the
    # planar measurement.
    if curved_success:
        deviation = curved_result.get("deviation")
    else:
        deviation = planar_result.get("deviation") if planar_result else None
    if validation_fallback:
        deviation = {"max_distance": 0.0, "samples": 0}

    return {
        "engine": engine,
        "profile": config["name"],
        "requested_profile": requested_profile,
        "auto_metrics": auto_metrics or {},
        "curved_method": (curved_result or {}).get("method"),
        "curved_error": (curved_result or {}).get("error"),
        "curved_rejections": (curved_result or {}).get("rejections", []),
        "verts_before": verts_before,
        "verts_after": len(new_mesh.vertices),
        "edges_before": edges_before,
        "edges_after": len(new_mesh.edges),
        "faces_before": faces_before,
        "faces_after": len(new_mesh.polygons),
        "tris_remaining": tris_remaining,
        "quads": quad_count,
        "ngons": ngons,
        "predecimated": False,
        "large_input": large_input,
        "circles_found": len(circles),
        "target_feature_size_world": target_feature_size,
        "deviation_limit": curved_deviation_limit if config["curved"] else deviation_limit,
        "curved_deviation_limit": curved_deviation_limit,
        "validation_retries": max(0, (planar_result or {}).get("attempts", 1) - 1)
        + max(0, (curved_result or {}).get("attempts", 1) - 1),
        "validation_fallback": validation_fallback,
        "planar_angle_used_degrees": (planar_result or {}).get("angle_degrees", 0.0),
        "planar_faces_after": (planar_result or {}).get("faces_after", faces_before),
        "collapse_ratio_used": (curved_result or {}).get("ratio"),
        "quads_joined": (curved_result or {}).get("quads_joined", 0),
        "feature_edges_protected": (curved_result or {}).get("feature_edges_protected", 0),
        "cleanup": cleanup_result,
        "source_tri_ratio": (curved_result or {}).get("tri_ratio"),
        "recovery_face_angle": (curved_result or {}).get("recovery_face_angle"),
        "quad_completion": (curved_result or {}).get("quad_completion") or {},
        "local_refinement": (curved_result or {}).get("local_refinement") or {},
        "flow_optimization": (curved_result or {}).get("flow_optimization") or {},
        "topology_quality": (curved_result or {}).get("topology_quality") or _topology_quality_metrics(new_mesh),
        "quad_ratio": (quad_count / float(max(1, len(new_mesh.polygons)))),
        "uv_discontinuity_ratio": uv_discontinuity_ratio,
        "uv_boundary_relaxed": bool(preserve_uv_seams and not protect_uv_boundaries),
        "reduction_percent": reduction_percent,
        "max_deviation": deviation.get("max_distance") if deviation else None,
        "p99_deviation": deviation.get("source_to_result_p99") if deviation else None,
        "p95_deviation": deviation.get("source_to_result_p95") if deviation else None,
        "deviation_samples": deviation.get("samples", 0) if deviation else 0,
        "surface_transfer": transfer_result,
    }

def _world_surface_area(obj):
    """Return the mesh surface area in world-space units.

    QuadriFlow's face-count mode is much more predictable for density than
    EDGE mode. Computing the area in world space also makes the result stable
    when object scale is unapplied or non-uniform.
    """
    mesh = obj.data
    mesh.calc_loop_triangles()
    matrix_world = obj.matrix_world
    area = 0.0

    for tri in mesh.loop_triangles:
        a = matrix_world @ mesh.vertices[tri.vertices[0]].co
        b = matrix_world @ mesh.vertices[tri.vertices[1]].co
        c = matrix_world @ mesh.vertices[tri.vertices[2]].co
        area += (b - a).cross(c - a).length * 0.5

    return area


def _organic_target_faces(obj, detail_factor, min_faces=20, max_faces=2000000):
    """Convert the user-facing Detail value into a concrete quad budget.

    Detail is defined as target edge length / bounding-box diagonal. For an
    approximately regular quad field, one quad covers about edge_length^2 of
    surface area, so area / edge_length^2 is a useful direct face target.
    """
    target_edge_length = resolve_target_edge_length(obj, detail_factor)
    surface_area = _world_surface_area(obj)

    if surface_area <= 0.0 or target_edge_length <= 0.0:
        return min_faces, target_edge_length, surface_area

    target_faces = int(round(surface_area / (target_edge_length ** 2)))
    target_faces = max(min_faces, min(target_faces, max_faces))
    return target_faces, target_edge_length, surface_area



def _apply_voxel_remesh_modifier(obj, context, voxel_size_world):
    """Robust density-controlled fallback for Organic remeshing.

    Blender's QuadriFlow can fail on self-intersections, non-manifold input,
    awkward boundaries, or difficult target budgets. Voxel remesh is much
    more tolerant of those cases. The requested world-space detail remains
    authoritative by converting it into local mesh units before evaluation.
    """
    voxel_size_local = max(_local_target_edge_length(obj, voxel_size_world), 1e-6)

    largest_local_dim = max((v.co.length for v in obj.data.vertices), default=0.0)
    if largest_local_dim > 0.0:
        # Prevent pathological grid sizes while still allowing substantially
        # finer Organic presets than the previous fixed fragmented-mesh floor.
        voxel_size_local = max(voxel_size_local, largest_local_dim / 800.0)

    mod = obj.modifiers.new(name="FastRemesher_OrganicVoxelFallback", type='REMESH')
    mod.mode = 'VOXEL'
    mod.voxel_size = voxel_size_local
    mod.adaptivity = 0.0
    mod.use_remove_disconnected = False

    depsgraph = context.evaluated_depsgraph_get()
    obj_eval = obj.evaluated_get(depsgraph)
    fallback_mesh = bpy.data.meshes.new_from_object(obj_eval)

    obj.modifiers.remove(mod)
    old_mesh = obj.data
    obj.data = fallback_mesh
    if old_mesh.users == 0:
        bpy.data.meshes.remove(old_mesh)

    return voxel_size_local


def _quadriflow_faces_with_fallback(obj, context, target_faces, target_edge_length, seed, use_symmetry):
    """Run QuadriFlow defensively and fall back to Voxel Remesh.

    Returns (method, effective_target_faces, fallback_voxel_size_local).
    """
    current_faces = max(len(obj.data.polygons), 1)
    requested = max(int(target_faces), 20)

    attempts = [
        {
            "target_faces": requested,
            "use_mesh_symmetry": use_symmetry,
            "use_preserve_sharp": True,
            "use_preserve_boundary": True,
        },
        {
            "target_faces": requested,
            "use_mesh_symmetry": False,
            "use_preserve_sharp": False,
            "use_preserve_boundary": False,
        },
    ]

    # Very large up-resolution requests are a common source of solver failure.
    # Give QuadriFlow one conservative pass before abandoning it entirely.
    conservative_target = max(20, min(requested, current_faces * 2))
    if conservative_target != requested:
        attempts.append({
            "target_faces": conservative_target,
            "use_mesh_symmetry": False,
            "use_preserve_sharp": False,
            "use_preserve_boundary": False,
        })

    for attempt in attempts:
        try:
            bpy.ops.object.quadriflow_remesh(
                target_faces=attempt["target_faces"],
                use_mesh_symmetry=attempt["use_mesh_symmetry"],
                use_preserve_sharp=attempt["use_preserve_sharp"],
                use_preserve_boundary=attempt["use_preserve_boundary"],
                smooth_normals=False,
                mode='FACES',
                seed=seed,
            )
            return "QUADRIFLOW", attempt["target_faces"], None
        except RuntimeError:
            pass

    voxel_size_local = _apply_voxel_remesh_modifier(
        obj, context, target_edge_length
    )
    return "VOXEL_FALLBACK", requested, voxel_size_local

def run_organic(obj, context, detail_factor, seed=0, max_input_faces=100000, use_symmetry=False):
    target_faces, target_edge_length, surface_area_world = _organic_target_faces(
        obj, detail_factor
    )
    mesh_before = obj.data
    verts_before = len(mesh_before.vertices)
    faces_before = len(mesh_before.polygons)

    circles = _detect_circular_boundary_loops(mesh_before)

    view_layer = context.view_layer
    prev_active = view_layer.objects.active
    view_layer.objects.active = obj

    snapshot_obj = _make_original_snapshot(obj, context)

    predecimated = False
    if faces_before > max_input_faces:
        decimate_mod = obj.modifiers.new(name="FastRemesher_PreDecimate", type='DECIMATE')
        decimate_mod.ratio = max_input_faces / faces_before
        depsgraph = context.evaluated_depsgraph_get()
        obj_eval = obj.evaluated_get(depsgraph)
        decimated_mesh = bpy.data.meshes.new_from_object(obj_eval)
        obj.modifiers.remove(decimate_mod)
        old_mesh = obj.data
        obj.data = decimated_mesh
        if old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)
        predecimated = True

    islands = _count_islands(obj)
    fragmented = islands > 1
    proxy_voxel_size = None

    if fragmented:
        # Keep the requested density authoritative for organic meshes. The old
        # 6%-of-bounds merge floor was the main reason BODY/FACE/CUSTOM could
        # all end up with effectively the same topology density.
        proxy_result = _coarse_voxel_proxy(
            obj,
            context,
            target_faces,
            force_merge_floor=False,
        )
        if proxy_result is not None:
            proxy_voxel_size = proxy_result[0]

    # Prefer explicit face-count QuadriFlow, but do not let its native solver
    # failure abort the addon. Difficult organic input falls back to a robust
    # voxel remesh driven by the exact same user Detail value.
    remesh_method, effective_target_faces, fallback_voxel_size_local = (
        _quadriflow_faces_with_fallback(
            obj, context, target_faces, target_edge_length, seed, use_symmetry
        )
    )

    if fragmented:
        _shrinkwrap_onto(obj, context, snapshot_obj)
    _cleanup_snapshot(snapshot_obj)

    _snap_boundary_loops_to_circles(obj, context, circles)
    cleanup_result = safe_post_cleanup(obj)
    surface_transfer_result = transfer_uv_and_materials(obj, context)

    view_layer.objects.active = prev_active

    new_mesh = obj.data
    tris_remaining = sum(1 for p in new_mesh.polygons if len(p.vertices) == 3)

    return {
        "verts_before": verts_before,
        "verts_after": len(new_mesh.vertices),
        "faces_before": faces_before,
        "faces_after": len(new_mesh.polygons),
        "tris_remaining": tris_remaining,
        "predecimated": predecimated,
        "circles_found": len(circles),
        "islands": islands,
        "fragmented": fragmented,
        "target_faces": target_faces,
        "effective_target_faces": effective_target_faces,
        "target_edge_length_world": target_edge_length,
        "surface_area_world": surface_area_world,
        "proxy_voxel_size": proxy_voxel_size,
        "remesh_method": remesh_method,
        "fallback_voxel_size_local": fallback_voxel_size_local,
        "cleanup": cleanup_result,
        "surface_transfer": surface_transfer_result,
    }