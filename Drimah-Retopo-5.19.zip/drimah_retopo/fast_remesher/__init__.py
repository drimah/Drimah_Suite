bl_info = {
    "name": "Fast Remesher",
    "author": "Anvil Interactive Solutions",
    "version": (1, 0, 0),
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > Fast Remesher",
    "category": "Mesh",
}

import bpy
import bmesh
from bpy.props import FloatProperty, BoolProperty
from bpy.types import Operator, Panel, PropertyGroup

from . import core
from . import core_instantmeshes
from . import preview
from . import diagnostics
from . import surface_transfer

FIXED_SEED = 0


def _run_preflight(operator, obj, settings):
    report = diagnostics.analyze_object(obj)
    settings.preflight_summary = diagnostics.short_summary(report)
    settings.preflight_warnings = " | ".join(report.get("warnings", []))
    settings.preflight_object_name = obj.name if obj is not None else ""
    if not report.get("valid"):
        operator.report({'ERROR'}, (report.get("errors") or ["Preflight failed"])[0])
        return None
    if report.get("shape_keys", 0) and not settings.allow_shape_key_loss:
        operator.report(
            {'ERROR'},
            "Shape keys detected. Retopology changes vertex correspondence and cannot preserve shape keys. "
            "Enable 'Allow Shape Key Loss' under Safety only if this is intentional.",
        )
        return None
    for warning in report.get("warnings", [])[:2]:
        operator.report({'WARNING'}, warning)
    return report


def _store_last_result(settings, text):
    settings.last_result_summary = str(text)[:1024]


def _restore_after_failure(obj):
    """Best-effort rollback to the persistent original after an unexpected error."""
    backup = core.get_original_backup(obj)
    if backup is None:
        return False
    try:
        old_mesh = obj.data
        obj.data = backup.data.copy()
        if old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)
        surface_transfer.transfer_surface_data(obj, backup)
        obj.data.update()
        return True
    except Exception:
        return False


def detect_mesh_category(obj):
    """Fast, polygon-only detection of which of our presets best fits this
    object's geometry using topology ratios and normal-distribution signals.
    Returns ('hardsurface'|'organic', preset_key)."""
    if obj is None or obj.type != 'MESH':
        return ('hardsurface', 'MECHANICAL')

    mesh = obj.data
    num_verts = len(mesh.vertices)
    num_faces = len(mesh.polygons)
    if num_faces == 0:
        return ('hardsurface', 'MECHANICAL')

    tri_count = sum(1 for f in mesh.polygons if len(f.vertices) == 3)
    ngon_count = sum(1 for f in mesh.polygons if len(f.vertices) > 4)
    tri_ratio = tri_count / num_faces
    ngon_ratio = ngon_count / num_faces

    if num_faces >= 50:
        step = max(1, num_faces // 400)
        sample = [mesh.polygons[i].normal for i in range(0, num_faces, step)]

        nx = [n.x for n in sample]
        ny = [n.y for n in sample]
        nz = [n.z for n in sample]
        global_spread = ((max(nx) - min(nx)) + (max(ny) - min(ny)) + (max(nz) - min(nz))) / 3.0

        mean_nx = sum(nx) / len(nx)
        mean_ny = sum(ny) / len(ny)
        mean_nz = sum(nz) / len(nz)
        variance = sum(
            (x - mean_nx) ** 2 + (y - mean_ny) ** 2 + (z - mean_nz) ** 2
            for x, y, z in zip(nx, ny, nz)
        ) / len(nx)
        std_dev = variance ** 0.5
    else:
        global_spread = 0.0
        std_dev = 1.0 if tri_ratio > 0.5 else 0.0

    # Hard surface vs organic decision from topology and normal-distribution signals
    if ngon_ratio > 0.25:
        mode = 'hardsurface'
    elif global_spread > 0.4 and std_dev < 0.35:
        mode = 'hardsurface'  # vehicle-like: curved globally, consistent locally
    elif global_spread < 0.3 and std_dev < 0.20:
        mode = 'hardsurface'
    elif std_dev > 0.45 and tri_ratio > 0.4:
        mode = 'organic'
    elif 0.4 < tri_ratio < 0.95 and num_verts > 500:
        mode = 'organic'
    else:
        mode = 'organic' if tri_ratio > 0.5 else 'hardsurface'

    if mode == 'hardsurface':
        # Sub-pick within hardsurface using density-per-bbox as a proxy for
        # panel size vs greeble detail; this split improves practical Auto behavior.
        dims = obj.dimensions
        bbox_diagonal = (dims.x ** 2 + dims.y ** 2 + dims.z ** 2) ** 0.5
        faces_per_unit = num_faces / bbox_diagonal if bbox_diagonal > 0 else num_faces
        if global_spread > 0.4 and std_dev < 0.35:
            preset = 'VEHICLE'
        elif faces_per_unit > 5000:
            preset = 'GREEBLE'
        else:
            preset = 'MECHANICAL'
        return ('hardsurface', preset)
    else:
        preset = 'FACE' if num_faces < 3000 else 'BODY'
        return ('organic', preset)


def _apply_hs_preset(self, context):
    values = {
        # detail factor, protected feature angle, planar dissolve tolerance
        'VEHICLE': (0.025, 0.5236, 0.02618),
        'MECHANICAL': (0.012, 0.3491, 0.0174533),
        'GREEBLE': (0.004, 0.2094, 0.00872665),
        'GAME_LOD': (0.04, 0.6109, 0.0523599),
    }
    if self.hs_preset in values:
        detail, feature_angle, planar_angle = values[self.hs_preset]
        self.hs_detail_factor = detail
        self.hs_feature_angle = feature_angle
        self.hs_planar_angle = planar_angle
    preview.request_live_refresh(context)


def _refresh_hs_preview(self, context):
    preview.request_live_refresh(context)


def _apply_organic_preset(self, context):
    values = {
        'BODY': 0.012,
        'FACE': 0.003,
        'BACKGROUND': 0.04,
        'SCULPT': 0.008,
    }
    if self.organic_preset in values:
        self.organic_detail_factor = values[self.organic_preset]


class FASTREMESHER_Settings(PropertyGroup):
    hs_preset: bpy.props.EnumProperty(
        name="Preset",
        items=[
            ('AUTO', "Auto (Recommended)",
             "Analyze the mesh and automatically choose planar or curved hard-surface cleanup"),
            ('VEHICLE', "Vehicle / Large Panels",
             "Car bodies, armor plates, hull panels — big gentle curves, no fine detail to protect. Detail 0.025, Feature Angle 30°"),
            ('MECHANICAL', "Mechanical Parts",
             "Weapons, machinery, general hardsurface props — balanced detail level. Detail 0.012, Feature Angle 20°"),
            ('GREEBLE', "Fine Detail / Greebles",
             "Vents, small bevels, panel lines, sci-fi detailing — tight angle needed to actually preserve these edges. Detail 0.004, Feature Angle 12°"),
            ('GAME_LOD', "Game-Ready LOD",
             "Aggressive simplification for real-time engine budgets — expect visible detail loss, that's the point. Detail 0.04, Feature Angle 35°"),
            ('CUSTOM', "Custom", "Manually tuned Detail and Feature Angle below"),
        ],
        default='AUTO',
        update=lambda self, context: _apply_hs_preset(self, context),
    )
    hs_detail_factor: bpy.props.FloatProperty(
        name="Detail",
        default=0.012,
        min=0.0005,
        max=0.5,
        description="Hard-surface quality budget as a fraction of the object size; smaller values enforce tighter surface-deviation limits during cleanup",
        update=_refresh_hs_preview,
    )
    hs_feature_angle: FloatProperty(
        name="Feature Angle",
        default=0.3491,
        min=0.0,
        max=1.5708,
        subtype='ANGLE',
        description="Edges sharper than this are treated as real design edges and kept crisp",
        update=_refresh_hs_preview,
    )
    hs_planar_angle: FloatProperty(
        name="Planar Tolerance",
        default=0.0174533,
        min=0.0,
        max=0.174533,
        subtype='ANGLE',
        description="Faces within this angle are treated as the same flat panel and their internal edges can be dissolved into clean n-gons",
        update=_refresh_hs_preview,
    )
    hs_preserve_uv_seams: bpy.props.BoolProperty(
        name="Preserve UV Seams",
        default=True,
        description="Never dissolve an edge marked as a UV seam",
        update=_refresh_hs_preview,
    )
    hs_preserve_material_boundaries: bpy.props.BoolProperty(
        name="Preserve Material Boundaries",
        default=True,
        description="Never dissolve an edge separating two material assignments",
        update=_refresh_hs_preview,
    )
    hs_max_input_faces: bpy.props.IntProperty(
        name="Max Solve Faces",
        default=150000,
        min=5000,
        max=1000000,
        description="Input meshes denser than this are pre-decimated before remeshing to keep solve time reasonable",
        update=_refresh_hs_preview,
    )
    hs_min_edge_length: bpy.props.FloatProperty(
        name="Min Length",
        default=0.0,
        min=0.0,
        max=1.0,
        description="Edges shorter than this are never treated as feature edges, even if their angle is sharp — filters out noise like tiny bevels or scan artifacts",
        update=_refresh_hs_preview,
    )
    hs_use_symmetry: bpy.props.BoolProperty(
        name="Preserve X Symmetry",
        default=False,
        description="Protect the local X=0 symmetry centerline during hard-surface cleanup",
        update=_refresh_hs_preview,
    )
    hs_show_advanced: bpy.props.BoolProperty(
        name="Advanced",
        default=False,
        description="Show manual hard-surface thresholds. Presets normally do not require these controls",
    )
    show_manual_preservation: bpy.props.BoolProperty(
        name="Manual Feature Protection",
        default=False,
        description="Show Edit Mode controls for explicitly protected edges",
    )
    show_safety: bpy.props.BoolProperty(
        name="Safety & Preservation",
        default=False,
        description="Show preflight, recovery, and unsupported-data controls",
    )
    allow_shape_key_loss: bpy.props.BoolProperty(
        name="Allow Shape Key Loss",
        default=False,
        description="Allow retopology on meshes with shape keys. Shape keys cannot be preserved when vertex correspondence changes",
    )
    preflight_summary: bpy.props.StringProperty(default="")
    preflight_warnings: bpy.props.StringProperty(default="")
    preflight_object_name: bpy.props.StringProperty(default="")
    last_result_summary: bpy.props.StringProperty(default="")
    organic_preset: bpy.props.EnumProperty(
        name="Preset",
        items=[
            ('BODY', "Full Character Body",
             "Balanced density across a whole character or creature. Detail 0.012"),
            ('FACE', "Face / Head Detail",
             "Close-up facial topology — eyes, mouth, wrinkles need much finer quads than a full body. Detail 0.003"),
            ('BACKGROUND', "Background Prop",
             "Distant or low-importance organic props — fast, coarse, doesn't need to hold up in close-up. Detail 0.04"),
            ('SCULPT', "Sculpt Cleanup",
             "Dense ZBrush/sculpt exports — reduces noise while preserving major forms. Detail 0.008"),
            ('CUSTOM', "Custom", "Manually tuned Detail below"),
        ],
        default='BODY',
        update=lambda self, context: _apply_organic_preset(self, context),
    )
    organic_detail_factor: bpy.props.FloatProperty(
        name="Detail",
        default=0.012,
        min=0.0005,
        max=0.5,
        description="Quad size as a fraction of THIS object's own bounding box diagonal — automatically scales correctly whether the object is tiny or huge, no need to know its physical size",
    )
    organic_max_input_faces: bpy.props.IntProperty(
        name="Max Solve Faces",
        default=150000,
        min=5000,
        max=1000000,
        description="Input meshes denser than this are pre-decimated before remeshing to keep solve time reasonable",
    )
    organic_use_symmetry: bpy.props.BoolProperty(
        name="Preserve X Symmetry",
        default=False,
        description="Use Blender QuadriFlow X symmetry when the organic mesh is actually symmetric across local X=0",
    )
    organic_show_advanced: bpy.props.BoolProperty(
        name="Advanced",
        default=False,
        description="Show Organic detail and solve-limit controls",
    )
    garment_show_advanced: bpy.props.BoolProperty(
        name="Advanced",
        default=False,
        description="Show Garment solve-limit controls",
    )
    garment_reduction_ratio: bpy.props.FloatProperty(
        name="Density",
        default=1.0,
        min=0.2,
        max=2.0,
        description="Target face count as a fraction of the input mesh's face count (garments are often already low-poly, so 1.0 = same detail, just cleaner topology)",
    )
    garment_max_input_faces: bpy.props.IntProperty(
        name="Max Solve Faces",
        default=150000,
        min=5000,
        max=1000000,
        description="Input meshes denser than this are pre-decimated before remeshing to keep solve time reasonable",
    )


class FASTREMESHER_OT_preflight(Operator):
    bl_idname = "fastremesher.preflight"
    bl_label = "Run Preflight"
    bl_description = "Inspect topology, UV/UDIM data, rigging, shape keys, loose geometry, and scale before remeshing"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        settings = context.scene.fast_remesher_settings
        report = diagnostics.analyze_object(context.active_object)
        settings.preflight_summary = diagnostics.short_summary(report)
        settings.preflight_warnings = " | ".join(report.get("warnings", []))
        settings.preflight_object_name = context.active_object.name
        if report.get("valid"):
            self.report({'INFO'}, settings.preflight_summary)
            return {'FINISHED'}
        self.report({'ERROR'}, (report.get("errors") or ["Preflight failed"])[0])
        return {'CANCELLED'}


class FASTREMESHER_OT_restore_original(Operator):
    bl_idname = "fastremesher.restore_original"
    bl_label = "Restore Original"
    bl_description = "Restore this object from Fast Remesher's untouched original backup"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return bool(
            obj is not None
            and obj.type == 'MESH'
            and core.get_original_backup(obj) is not None
        )

    def execute(self, context):
        obj = context.active_object
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        backup = core.get_original_backup(obj)
        if backup is None:
            self.report({'ERROR'}, "No Fast Remesher original backup found")
            return {'CANCELLED'}
        old_mesh = obj.data
        obj.data = backup.data.copy()
        if old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)
        transfer = surface_transfer.transfer_surface_data(obj, backup)
        obj.data.update()
        if transfer.get("success"):
            self.report({'INFO'}, "Original geometry and preserved surface data restored")
        else:
            self.report({'WARNING'}, f"Geometry restored; data restore warning: {transfer.get('error', 'unknown')}")
        return {'FINISHED'}


class FASTREMESHER_OT_hardsurface(Operator):
    bl_idname = "fastremesher.hardsurface"
    bl_label = "Remesh Hardsurface"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (
            context.active_object is not None
            and context.active_object.type == 'MESH'
            and not context.active_object.get(preview.PREVIEW_SOURCE_PROP)
        )

    def execute(self, context):
        settings = context.scene.fast_remesher_settings
        obj = context.active_object

        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        if _run_preflight(self, obj, settings) is None:
            return {'CANCELLED'}

        # This operator is specifically the Instant Meshes open-surface workflow.
        # Closed meshes should use Hard Surface or Organic instead; do not let
        # an unsuitable mode replace the user's source with a fragmented result.
        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            boundary_edges = sum(1 for edge in bm.edges if edge.is_boundary)
            non_manifold_edges = sum(1 for edge in bm.edges if not edge.is_manifold)
        finally:
            bm.free()
        if boundary_edges == 0:
            self.report(
                {'ERROR'},
                "Gerar Malha é para superfícies abertas. Este objeto parece fechado; use Hard Surface ou Orgânico. Original preservado."
            )
            return {'CANCELLED'}
        if non_manifold_edges > max(8, int(len(obj.data.edges) * 0.35)):
            self.report(
                {'ERROR'},
                "Malha de entrada tem muitas arestas não manifold. Corrija/separe a geometria antes de gerar. Original preservado."
            )
            return {'CANCELLED'}

        core.ensure_fresh_original(context, obj)

        context.window.cursor_set('WAIT')
        context.workspace.status_text_set("Fast Remesher: running Hardsurface remesh…")
        for area in context.screen.areas:
            area.tag_redraw()
        bpy.context.view_layer.update()

        import time
        start = time.time()
        try:
            # Keep AUTO intact. core.run_hardsurface classifies local adjacent-face curvature.
            hard_surface_profile = settings.hs_preset
            result = core.run_hardsurface(
                obj, context, settings.hs_detail_factor, settings.hs_feature_angle,
                settings.hs_max_input_faces, FIXED_SEED,
                settings.hs_min_edge_length, settings.hs_use_symmetry,
                settings.hs_planar_angle,
                settings.hs_preserve_uv_seams,
                settings.hs_preserve_material_boundaries,
                hard_surface_profile,
            )
        except Exception as exc:
            rolled_back = _restore_after_failure(obj)
            suffix = " Original restored." if rolled_back else ""
            self.report({'ERROR'}, f"Fast Remesher Hard Surface failed: {exc}.{suffix}")
            return {'CANCELLED'}
        finally:
            context.window.cursor_set('DEFAULT')
            context.workspace.status_text_set(None)

        elapsed = time.time() - start
        circles_note = f", round_holes={result['circles_found']}" if result.get("circles_found") else ""
        deviation = result.get("max_deviation")
        deviation_note = f", max_dev={deviation:.6g}/{result.get('deviation_limit', 0.0):.6g}" if deviation is not None else ", max_dev=n/a"
        p99 = result.get("p99_deviation")
        p99_note = f", p99={p99:.6g}" if p99 is not None else ""
        rejections = result.get("curved_rejections") or []
        reject_note = f", last_reject={rejections[-1]}" if rejections else ""
        large_note = ", large_input" if result.get("large_input") else ""
        retry_note = f", retries={result.get('validation_retries', 0)}" if result.get("validation_retries") else ""
        safe_note = ", SAFE_FALLBACK" if result.get("validation_fallback") else ""
        transfer = result.get("surface_transfer") or {}
        if transfer.get("success"):
            rig_note = " rig=preserved" if transfer.get("armature_bound") else ""
            udim_layers = sum(1 for tiles in (transfer.get('udim_tiles') or {}).values() if len(tiles) > 1 or any(tile != 1001 for tile in tiles))
            udim_note = f" UDIM={udim_layers}" if udim_layers else ""
            color_note = f" colors={transfer.get('color_attributes', 0)}" if transfer.get('color_attributes') else ""
            normal_note = " normals=preserved" if transfer.get('custom_normals_transferred') else ""
            transfer_note = (
                f", UVs={transfer.get('uv_layers', 0)}{udim_note}{color_note}{normal_note}"
                f" groups={transfer.get('vertex_groups', 0)}"
                f" weighted_verts={transfer.get('weighted_vertices', 0)}"
                f"{rig_note}"
            )
        elif transfer.get("partial"):
            transfer_note = f", surface transfer partial ({transfer.get('error', 'unknown error')})"
        else:
            transfer_note = f", surface transfer skipped ({transfer.get('error', 'unknown error')})"

        engine_note = result.get('engine', 'ADAPTIVE')
        profile_note = result.get('profile', settings.hs_preset)
        planar_note = f", planar={result.get('planar_angle_used_degrees', 0.0):.2f}deg"
        collapse_ratio = result.get('collapse_ratio_used')
        curved_note = f", collapse={collapse_ratio:.2f}" if collapse_ratio is not None else ""
        topology_note = (
            f", quads={result.get('quads', 0)} tris={result.get('tris_remaining', 0)}"
            f" ngons={result.get('ngons', 0)}"
        )
        auto_metrics = result.get('auto_metrics') or {}
        curvature_note = ""
        if result.get('requested_profile') == 'AUTO' and auto_metrics:
            curvature_note = (
                f", curvature(flat={auto_metrics.get('flat_ratio', 0.0):.2f}"
                f" gentle={auto_metrics.get('gentle_ratio', 0.0):.2f}"
                f" p75={auto_metrics.get('p75_angle_degrees', 0.0):.2f}deg)"
            )
        method_note = f", method={result.get('curved_method')}" if result.get('curved_method') else ""
        recovery_note = ""
        if result.get('curved_method') == 'QUAD_RECOVERY':
            completion = result.get('quad_completion') or {}
            quad_percent = result.get('quad_ratio', 0.0) * 100.0
            completion_note = ""
            if completion.get('applied'):
                completion_note = (
                    f" completion=+{completion.get('joined', 0)}"
                    f" ({completion.get('quad_ratio_before', 0.0) * 100.0:.0f}%->"
                    f"{completion.get('quad_ratio_after', 0.0) * 100.0:.0f}%)"
                )
            local = result.get('local_refinement') or {}
            local_note = ""
            if local.get('applied'):
                before_q = local.get('quality_before') or {}
                after_q = local.get('quality_after') or {}
                local_note = (
                    f" local=+{local.get('joined', 0)}"
                    f" clusters={before_q.get('large_clusters', 0)}->{after_q.get('large_clusters', 0)}"
                )
            flow = result.get('flow_optimization') or {}
            flow_note = ""
            if flow.get('applied'):
                before_flow = flow.get('quality_before') or {}
                after_flow = flow.get('quality_after') or {}
                flow_note = (
                    f" flow={flow.get('moved_vertices', 0)}v@{flow.get('factor', 0.0):.2f}"
                    f" bad={before_flow.get('bad_quads', 0)}->{after_flow.get('bad_quads', 0)}"
                )
            quality = result.get('topology_quality') or {}
            quality_note = ""
            if quality:
                quality_note = (
                    f" quality={quality.get('grade', 'N/A')}:{quality.get('score', 0.0):.0f}"
                    f" tri_clusters={quality.get('cluster_count', 0)}"
                    f" largest={quality.get('largest_cluster', 0)}"
                    f" bad_quads={quality.get('bad_quad_ratio', 0.0) * 100.0:.1f}%"
                    f" warn_quads={quality.get('warning_quad_ratio', 0.0) * 100.0:.1f}%"
                    f" aligned_long={quality.get('flow_aligned_elongated_ratio', 0.0) * 100.0:.1f}%"
                )
            recovery_note = (
                f", recovered_quads={result.get('quads_joined', 0)}"
                f" angle={result.get('recovery_face_angle', 0.0):.0f}deg"
                f" quad_pct={quad_percent:.1f}%{completion_note}{local_note}{flow_note}{quality_note}"
            )
        feature_note = f", features={result.get('feature_edges_protected', 0)}" if result.get('feature_edges_protected') else ""
        cleanup = result.get('cleanup') or {}
        cleanup_count = cleanup.get('verts_removed', 0) + cleanup.get('edges_removed', 0) + cleanup.get('faces_removed', 0)
        cleanup_note = f", cleanup={cleanup_count}" if cleanup_count else ""
        _store_last_result(
            settings,
            f"Hard Surface: {result['faces_before']} -> {result['faces_after']} faces | "
            f"{result.get('quad_ratio', 0.0) * 100.0:.1f}% quads | {engine_note}/{profile_note}"
        )

        self.report(
            {'INFO'},
            f"Hardsurface [{engine_note}/{profile_note}]: {result['faces_before']} -> {result['faces_after']} faces "
            f"({result.get('reduction_percent', 0.0):.1f}% reduction)"
            f"{planar_note}{curved_note}{topology_note}{curvature_note}{method_note}"
            f"{circles_note}{feature_note}{cleanup_note}{deviation_note}{p99_note}{retry_note}{reject_note}{safe_note}{large_note}{recovery_note}{transfer_note}, {elapsed:.1f}s",
        )
        return {'FINISHED'}


class FASTREMESHER_OT_organic(Operator):
    bl_idname = "fastremesher.organic"
    bl_label = "Remesh Organic"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (
            context.active_object is not None
            and context.active_object.type == 'MESH'
            and not context.active_object.get(preview.PREVIEW_SOURCE_PROP)
        )

    def execute(self, context):
        settings = context.scene.fast_remesher_settings
        obj = context.active_object

        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        if _run_preflight(self, obj, settings) is None:
            return {'CANCELLED'}

        core.ensure_fresh_original(context, obj)

        context.window.cursor_set('WAIT')
        context.workspace.status_text_set("Fast Remesher: running Organic remesh, this can take a while on dense meshes…")
        for area in context.screen.areas:
            area.tag_redraw()
        bpy.context.view_layer.update()

        import time
        start = time.time()
        try:
            result = core.run_organic(
                obj, context, settings.organic_detail_factor, FIXED_SEED,
                settings.organic_max_input_faces, settings.organic_use_symmetry,
            )
        except Exception as exc:
            rolled_back = _restore_after_failure(obj)
            suffix = " Original restored." if rolled_back else ""
            self.report({'ERROR'}, f"Fast Remesher Organic failed: {exc}.{suffix}")
            return {'CANCELLED'}
        finally:
            context.window.cursor_set('DEFAULT')
            context.workspace.status_text_set(None)

        elapsed = time.time() - start
        predecimate_note = " (pre-decimated for speed)" if result["predecimated"] else ""
        circles_note = f", {result['circles_found']} round holes preserved" if result.get("circles_found") else ""
        frag_note = (
            f", method={result.get('remesh_method', '?')}"
            f" islands={result.get('islands', '?')} fragmented={result.get('fragmented', '?')}"
            f" target_faces={result.get('target_faces', '?')}"
            f" effective_target={result.get('effective_target_faces', '?')}"
            f" target_edge={result.get('target_edge_length_world', 0):.5f}"
        )
        transfer = result.get("surface_transfer") or {}
        if transfer.get("success"):
            rig_note = " rig=preserved" if transfer.get("armature_bound") else ""
            udim_layers = sum(1 for tiles in (transfer.get('udim_tiles') or {}).values() if len(tiles) > 1 or any(tile != 1001 for tile in tiles))
            udim_note = f" UDIM={udim_layers}" if udim_layers else ""
            color_note = f" colors={transfer.get('color_attributes', 0)}" if transfer.get('color_attributes') else ""
            normal_note = " normals=preserved" if transfer.get('custom_normals_transferred') else ""
            transfer_note = (
                f", UVs={transfer.get('uv_layers', 0)}{udim_note}{color_note}{normal_note}"
                f" groups={transfer.get('vertex_groups', 0)}"
                f" weighted_verts={transfer.get('weighted_vertices', 0)}"
                f"{rig_note}"
            )
        elif transfer.get("partial"):
            transfer_note = f", surface transfer partial ({transfer.get('error', 'unknown error')})"
        else:
            transfer_note = f", surface transfer skipped ({transfer.get('error', 'unknown error')})"
        _store_last_result(
            settings,
            f"Organic: {result['faces_before']} -> {result['faces_after']} faces | {result.get('remesh_method', '?')}"
        )
        self.report(
            {'INFO'},
            f"Organic: {result['faces_before']} -> {result['faces_after']} faces{predecimate_note}{circles_note}{frag_note}, "
            f"{result['tris_remaining']} tris remaining{transfer_note}, {elapsed:.1f}s",
        )
        return {'FINISHED'}


class FASTREMESHER_OT_garment(Operator):
    bl_idname = "fastremesher.garment"
    bl_label = "Gerar Malha"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (
            context.active_object is not None
            and context.active_object.type == 'MESH'
            and not context.active_object.get(preview.PREVIEW_SOURCE_PROP)
        )

    def execute(self, context):
        settings = context.scene.fast_remesher_settings
        obj = context.active_object

        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        if _run_preflight(self, obj, settings) is None:
            return {'CANCELLED'}

        core.ensure_fresh_original(context, obj)

        context.window.cursor_set('WAIT')
        context.workspace.status_text_set("Aguarde... Processando... Preparando a malha")
        for area in context.screen.areas:
            area.tag_redraw()
        bpy.context.view_layer.update()

        import time
        start = time.time()
        try:
            input_faces = len(obj.data.polygons)
            target_faces = max(int(input_faces * settings.garment_reduction_ratio), 20)
            context.workspace.status_text_set("Aguarde... Processando... Executando o remesh")
            for area in context.screen.areas:
                area.tag_redraw()
            bpy.context.view_layer.update()
            result = core_instantmeshes.run_instant_meshes(
                obj, context, target_faces,
                deterministic=True,
                crease_angle_degrees=None,
                max_input_faces=settings.garment_max_input_faces,
                align_boundaries=True,
                # Do not apply Decimate as a target-count clamp in open-mesh mode.
                # Decimate can turn the quad-dominant result into a dense triangle soup.
                clamp_to_target=False,
            )
        except Exception as e:
            rolled_back = _restore_after_failure(obj)
            suffix = " Original restored." if rolled_back else ""
            self.report({'ERROR'}, f"Fast Remesher Malha falhou: {e}.{suffix}")
            return {'CANCELLED'}
        finally:
            context.window.cursor_set('DEFAULT')
            context.workspace.status_text_set(None)

        elapsed = time.time() - start
        context.workspace.status_text_set("Aguarde... Processando... Validando resultado")
        for area in context.screen.areas:
            area.tag_redraw()
        bpy.context.view_layer.update()
        clamp_note = " (clamped to target — some triangulation possible)" if result["clamped"] else ""
        transfer = result.get("surface_transfer") or {}
        if transfer.get("success"):
            rig_note = " rig=preserved" if transfer.get("armature_bound") else ""
            udim_layers = sum(1 for tiles in (transfer.get('udim_tiles') or {}).values() if len(tiles) > 1 or any(tile != 1001 for tile in tiles))
            udim_note = f" UDIM={udim_layers}" if udim_layers else ""
            color_note = f" colors={transfer.get('color_attributes', 0)}" if transfer.get('color_attributes') else ""
            normal_note = " normals=preserved" if transfer.get('custom_normals_transferred') else ""
            transfer_note = (
                f", UVs={transfer.get('uv_layers', 0)}{udim_note}{color_note}{normal_note}"
                f" groups={transfer.get('vertex_groups', 0)}"
                f" weighted_verts={transfer.get('weighted_vertices', 0)}"
                f"{rig_note}"
            )
        elif transfer.get("partial"):
            transfer_note = f", surface transfer partial ({transfer.get('error', 'unknown error')})"
        else:
            transfer_note = f", surface transfer skipped ({transfer.get('error', 'unknown error')})"
        _store_last_result(
            settings,
            f"Garment: {result['faces_before']} -> {result['faces_after']} faces | Instant Meshes"
        )
        self.report(
            {'INFO'},
            f"Malha concluída: {result['faces_before']} -> {result['faces_after']} faces{clamp_note}, "
            f"{result['tris_remaining']} tris remaining{transfer_note}, {elapsed:.1f}s",
        )
        return {'FINISHED'}


class FASTREMESHER_OT_auto_detect_preset(Operator):
    bl_idname = "fastremesher.auto_detect_preset"
    bl_label = "Auto-Detect Preset"
    bl_description = "Analyze the selected object's geometry and pick the best-fitting Hardsurface or Organic preset"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        settings = context.scene.fast_remesher_settings

        mode, preset = detect_mesh_category(obj)

        if mode == 'hardsurface':
            settings.hs_preset = preset
            self.report({'INFO'}, f"Detected: Hardsurface / {preset.title()}")
        else:
            settings.organic_preset = preset
            self.report({'INFO'}, f"Detected: Organic / {preset.title()}")

        return {'FINISHED'}


class FASTREMESHER_OT_mark_sharp(Operator):
    bl_idname = "fastremesher.mark_sharp"
    bl_label = "Mark Selected Edges as Preserved"
    bl_description = "Mark selected edges as explicit Fast Remesher preservation boundaries"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT'

    def execute(self, context):
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        layer = bm.edges.layers.int.get(core.FASTREMESHER_PRESERVE_LAYER)
        if layer is None:
            layer = bm.edges.layers.int.new(core.FASTREMESHER_PRESERVE_LAYER)
        count = 0
        for edge in bm.edges:
            if edge.select:
                edge[layer] = 1
                count += 1
        bmesh.update_edit_mesh(obj.data)
        self.report({'INFO'}, f"Marked {count} edges as preserved")
        return {'FINISHED'}


class FASTREMESHER_OT_clear_sharp(Operator):
    bl_idname = "fastremesher.clear_sharp"
    bl_label = "Clear Preserved Mark on Selected Edges"
    bl_description = "Remove the manual preserved-edge mark from the selected edges — they'll go back to automatic detection only"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT'

    def execute(self, context):
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        layer = bm.edges.layers.int.get(core.FASTREMESHER_PRESERVE_LAYER)
        count = 0
        if layer is not None:
            for edge in bm.edges:
                if edge.select:
                    edge[layer] = 0
                    count += 1
        bmesh.update_edit_mesh(obj.data)
        self.report({'INFO'}, f"Cleared preserved mark on {count} edges")
        return {'FINISHED'}


class FASTREMESHER_OT_toggle_wireframe(Operator):
    bl_idname = "fastremesher.toggle_wireframe"
    bl_label = "Toggle Wireframe"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        obj.show_wire = not obj.show_wire
        obj.show_all_edges = obj.show_wire
        return {'FINISHED'}


class FASTREMESHER_OT_reset_backup(Operator):
    bl_idname = "fastremesher.reset_backup"
    bl_label = "Reset Original Backup"
    bl_description = "Delete the stored 'true original' for this object and treat its CURRENT state as the new original — use this after fixing something (like Apply Scale) that happened after the first remesh attempt"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            return False
        return core.get_original_backup(obj) is not None

    def execute(self, context):
        obj = context.active_object
        backup_obj = core.get_original_backup(obj)
        if backup_obj is not None:
            backup_mesh = backup_obj.data
            bpy.data.objects.remove(backup_obj, do_unlink=True)
            if backup_mesh.users == 0:
                bpy.data.meshes.remove(backup_mesh)
        core.clear_original_backup_reference(obj)
        self.report({'INFO'}, "Current mesh will be treated as the new original on the next remesh")
        return {'FINISHED'}


class FASTREMESHER_OT_apply_scale(Operator):
    bl_idname = "fastremesher.apply_scale"
    bl_label = "Apply Scale"
    bl_description = "Apply the object's scale so local mesh units match world units — required for Quad Size to behave predictably"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        prev_active = context.view_layer.objects.active
        prev_selected = context.view_layer.objects.selected[:]
        for o in prev_selected:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        for o in prev_selected:
            o.select_set(True)
        context.view_layer.objects.active = prev_active

        # Clear any stale backup — it would still hold the pre-scale-apply
        # geometry and silently undo this fix on the next remesh run.
        backup_obj = core.get_original_backup(obj)
        if backup_obj is not None:
            backup_mesh = backup_obj.data
            bpy.data.objects.remove(backup_obj, do_unlink=True)
            if backup_mesh.users == 0:
                bpy.data.meshes.remove(backup_mesh)
        core.clear_original_backup_reference(obj)

        self.report({'INFO'}, "Scale applied, original reference reset")
        return {'FINISHED'}


class FASTREMESHER_PT_panel(Panel):
    bl_idname = "FASTREMESHER_PT_panel"
    bl_label = "Fast Remesher"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Fast Remesher"
    bl_order = 10

    def draw(self, context):
        layout = self.layout
        settings = context.scene.fast_remesher_settings

        active = context.active_object
        if active is not None and active.get(preview.PREVIEW_SOURCE_PROP):
            layout.label(text="Live Preview is active", icon='INFO')
            layout.label(text="Use the Live Preview panel for settings or final remesh")
            return
        if active is None or active.type != 'MESH':
            layout.label(text="Select a mesh object", icon='INFO')
            return

        row = layout.row()
        row.operator("fastremesher.toggle_wireframe", text="Toggle Wireframe View")

        layout.label(text="Non-destructive recovery backup is created on first run", icon='INFO')

        row = layout.row(align=True)
        row.operator("fastremesher.auto_detect_preset", text="Auto Detect", icon='VIEWZOOM')
        row.operator("fastremesher.preflight", text="Preflight", icon='CHECKMARK')

        safety = layout.box()
        safety.prop(settings, "show_safety", toggle=True)
        if settings.show_safety:
            if settings.preflight_object_name == active.name and settings.preflight_summary:
                safety.label(text=settings.preflight_summary, icon='INFO')
                if settings.preflight_warnings:
                    for warning in settings.preflight_warnings.split(" | ")[:3]:
                        safety.label(text=warning[:90], icon='ERROR')
            else:
                safety.label(text="Run Preflight for this object before release-critical work", icon='INFO')
            row = safety.row(align=True)
            row.operator("fastremesher.restore_original", text="Restore Original")
            row.operator("fastremesher.reset_backup", text="Set Current as Original", icon='FILE_REFRESH')
            safety.prop(settings, "allow_shape_key_loss")
            im = diagnostics.instant_meshes_status()
            if im.get('available'):
                safety.label(text="Instant Meshes backend: Ready", icon='CHECKMARK')
            else:
                safety.label(text="Instant Meshes backend: Unavailable", icon='ERROR')

        if settings.last_result_summary:
            result_box = layout.box()
            result_box.label(text="Last Result", icon='CHECKMARK')
            result_box.label(text=settings.last_result_summary[:100])

        box = layout.box()
        box.prop(settings, "show_manual_preservation", toggle=True)
        if settings.show_manual_preservation:
            box.label(text="Select edges in Edit Mode, then protect them from cleanup", icon='INFO')
            row = box.row(align=True)
            row.operator("fastremesher.mark_sharp", text="Mark Preserved")
            row.operator("fastremesher.clear_sharp", text="Clear")

        box = layout.box()
        box.label(text="Hard Surface — Adaptive")
        box.label(text="Auto planar cleanup + quad retopology for smooth curved panels", icon='INFO')
        box.prop(settings, "hs_preset")
        box.prop(settings, "hs_use_symmetry")
        box.prop(settings, "hs_show_advanced", toggle=True)
        if settings.hs_show_advanced:
            box.prop(settings, "hs_detail_factor")
            box.prop(settings, "hs_feature_angle")
            box.prop(settings, "hs_planar_angle")
            box.prop(settings, "hs_min_edge_length")
            box.prop(settings, "hs_max_input_faces")
            row = box.row(align=True)
            row.prop(settings, "hs_preserve_uv_seams")
            row.prop(settings, "hs_preserve_material_boundaries")
        box.operator("fastremesher.hardsurface", text="Remesh Hard Surface")

        box = layout.box()
        box.label(text="Organic")
        box.prop(settings, "organic_preset")
        box.prop(settings, "organic_use_symmetry")
        box.prop(settings, "organic_show_advanced", toggle=True)
        if settings.organic_show_advanced or settings.organic_preset == 'CUSTOM':
            box.prop(settings, "organic_detail_factor")
            box.prop(settings, "organic_max_input_faces")
        box.operator("fastremesher.organic")

        box = layout.box()
        box.label(text="Garment / Open Mesh (Instant Meshes)")
        box.label(text="For thin, open-boundary shells: pants, cloth, capes")
        if not diagnostics.instant_meshes_status().get('available'):
            box.label(text="Instant Meshes backend unavailable on this build", icon='ERROR')
        box.prop(settings, "garment_reduction_ratio")
        box.prop(settings, "garment_show_advanced", toggle=True)
        if settings.garment_show_advanced:
            box.prop(settings, "garment_max_input_faces")
        box.operator("fastremesher.garment")


classes = (
    FASTREMESHER_Settings,
    FASTREMESHER_OT_preflight,
    FASTREMESHER_OT_restore_original,
    FASTREMESHER_OT_hardsurface,
    FASTREMESHER_OT_organic,
    FASTREMESHER_OT_garment,
    FASTREMESHER_OT_auto_detect_preset,
    FASTREMESHER_OT_reset_backup,
    FASTREMESHER_OT_apply_scale,
    FASTREMESHER_OT_mark_sharp,
    FASTREMESHER_OT_clear_sharp,
    FASTREMESHER_OT_toggle_wireframe,
    FASTREMESHER_PT_panel,
) + preview.classes


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fast_remesher_settings = bpy.props.PointerProperty(type=FASTREMESHER_Settings)
    bpy.types.Scene.fast_remesher_preview_settings = bpy.props.PointerProperty(type=preview.FASTREMESHER_Preview_Settings)


def unregister():
    preview.cleanup_all_previews()
    if hasattr(bpy.types.Scene, "fast_remesher_settings"):
        del bpy.types.Scene.fast_remesher_settings
    if hasattr(bpy.types.Scene, "fast_remesher_preview_settings"):
        del bpy.types.Scene.fast_remesher_preview_settings
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()