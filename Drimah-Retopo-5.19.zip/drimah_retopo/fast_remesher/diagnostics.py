import math
import os
import platform

import bpy
import bmesh


def _bbox_diagonal(obj):
    dims = obj.dimensions
    return math.sqrt(dims.x * dims.x + dims.y * dims.y + dims.z * dims.z)


def _uv_tile_ids(mesh):
    result = {}
    for layer in mesh.uv_layers:
        tiles = set()
        for item in layer.data:
            u = float(item.uv.x)
            v = float(item.uv.y)
            tu = math.floor(u)
            tv = math.floor(v)
            if tu < 0 or tv < 0:
                continue
            tiles.add(1001 + int(tu) + int(tv) * 10)
        result[layer.name] = sorted(tiles)
    return result


def instant_meshes_status():
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    if platform.system() == 'Windows':
        path = os.path.join(addon_dir, 'bin', 'Windows', 'Instant Meshes.exe')
    else:
        path = None
    return {
        'supported_platform': path is not None,
        'available': bool(path and os.path.isfile(path)),
        'path': path or '',
    }


def analyze_object(obj):
    if obj is None or obj.type != 'MESH':
        return {
            'valid': False,
            'errors': ['Select a mesh object'],
            'warnings': [],
            'info': [],
        }

    mesh = obj.data
    report = {
        'valid': True,
        'errors': [],
        'warnings': [],
        'info': [],
        'object_name': obj.name,
        'vertices': len(mesh.vertices),
        'edges': len(mesh.edges),
        'faces': len(mesh.polygons),
        'triangles': 0,
        'quads': 0,
        'ngons': 0,
        'boundary_edges': 0,
        'non_manifold_edges': 0,
        'loose_edges': 0,
        'loose_vertices': 0,
        'degenerate_faces': 0,
        'uv_layers': len(mesh.uv_layers),
        'uv_tiles': _uv_tile_ids(mesh),
        'materials': len(mesh.materials),
        'color_attributes': len(getattr(mesh, 'color_attributes', [])),
        'vertex_groups': len(obj.vertex_groups),
        'armature_modifiers': sum(1 for mod in obj.modifiers if mod.type == 'ARMATURE'),
        'shape_keys': 0,
        'modifier_types': [mod.type for mod in obj.modifiers],
        'bbox_diagonal': _bbox_diagonal(obj),
        'scale_applied': all(abs(float(v) - 1.0) <= 1.0e-4 for v in obj.scale),
    }

    for poly in mesh.polygons:
        count = len(poly.vertices)
        if count == 3:
            report['triangles'] += 1
        elif count == 4:
            report['quads'] += 1
        elif count > 4:
            report['ngons'] += 1

    if mesh.shape_keys is not None:
        report['shape_keys'] = max(0, len(mesh.shape_keys.key_blocks) - 1)

    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        eps_area = max(report['bbox_diagonal'] ** 2 * 1.0e-14, 1.0e-18)
        for edge in bm.edges:
            linked_faces = len(edge.link_faces)
            if linked_faces == 1:
                report['boundary_edges'] += 1
            elif linked_faces == 0 or linked_faces > 2:
                report['non_manifold_edges'] += 1
            if linked_faces == 0:
                report['loose_edges'] += 1
        for vert in bm.verts:
            if not vert.link_edges:
                report['loose_vertices'] += 1
        for face in bm.faces:
            if face.calc_area() <= eps_area:
                report['degenerate_faces'] += 1
    finally:
        bm.free()

    if report['faces'] == 0:
        report['errors'].append('Mesh has no faces')
        report['valid'] = False
    if report['shape_keys']:
        report['warnings'].append(
            f"{report['shape_keys']} shape key(s) detected; retopology cannot preserve shape keys"
        )
    if not report['scale_applied']:
        report['warnings'].append('Object scale is not applied; density and symmetry can be less predictable')
    if report['non_manifold_edges']:
        report['warnings'].append(
            f"{report['non_manifold_edges']} true non-manifold edge(s) detected"
        )
    if report['boundary_edges']:
        report['info'].append(f"{report['boundary_edges']} open boundary edge(s) detected")
    if report['degenerate_faces']:
        report['warnings'].append(f"{report['degenerate_faces']} degenerate face(s) detected")
    if report['loose_vertices'] or report['loose_edges']:
        report['warnings'].append(
            f"Loose geometry detected ({report['loose_vertices']} verts, {report['loose_edges']} edges)"
        )

    udim_layers = {
        name: tiles for name, tiles in report['uv_tiles'].items()
        if len(tiles) > 1 or any(tile != 1001 for tile in tiles)
    }
    report['udim_layers'] = udim_layers
    if udim_layers:
        tile_count = sum(len(tiles) for tiles in udim_layers.values())
        report['info'].append(f"UDIM UVs detected ({tile_count} tile references)")
    if report['color_attributes']:
        report['info'].append(
            f"{report['color_attributes']} color attribute layer(s) will be transferred"
        )
    if report['vertex_groups']:
        report['info'].append(f"{report['vertex_groups']} vertex group(s) will be transferred")
    if report['armature_modifiers'] or (obj.parent is not None and obj.parent.type == 'ARMATURE'):
        report['info'].append('Armature relationship detected and will be validated after remesh')

    report['valid'] = not report['errors']
    return report


def short_summary(report):
    if not report.get('valid'):
        errors = report.get('errors') or ['Preflight failed']
        return errors[0]
    faces = report.get('faces', 0)
    quads = report.get('quads', 0)
    tris = report.get('triangles', 0)
    uvs = report.get('uv_layers', 0)
    tags = []
    if report.get('udim_layers'):
        tags.append('UDIM')
    if report.get('armature_modifiers'):
        tags.append('Rig')
    if report.get('shape_keys'):
        tags.append(f"ShapeKeys:{report.get('shape_keys')}")
    suffix = " | " + ", ".join(tags) if tags else ""
    return f"{faces} faces | {quads} quads | {tris} tris | {uvs} UV map(s){suffix}"
