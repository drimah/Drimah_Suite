Fast Remesher 1.0.0

Fast Remesher is a production-focused Blender remeshing add-on for hard-surface assets, organic meshes, and open garment shells. It is built around deterministic recovery and validation rather than a single remesh algorithm.

Supported release target

Blender 5.2 LTS or newer

Windows x64

Instant Meshes is bundled for the Windows x64 release

The package is intentionally platform-scoped for v1.0 so the shipped binary backend matches the tested build. macOS and Linux packages should be released only after bundling and testing native Instant Meshes binaries for those platforms.

Hard Surface

Hard Surface Auto analyzes local curvature and chooses the safer path automatically.

Vehicle / curved panels: restores interchange-triangulated authored topology back into quads first

Quad completion: locally pairs residual compatible triangles

Local refinement: works only on problematic triangle clusters

Panel-aware flow scoring: does not punish legitimate directional car-panel quads simply for being elongated

Mechanical / planar assets: uses conservative planar simplification

Real geometric crease protection for panel seams, bevel boundaries, wheel-arch transitions, and sharp mechanical features

Open boundaries, explicit Fast Remesher preserved edges, UV seams, and material boundaries are protected

Bidirectional source-surface deviation validation rejects unsafe results

Unsafe results restore the untouched source instead of accepting damaged geometry

Organic

Density-controlled QuadriFlow using explicit target face counts

Requested density is derived from world-space surface area

Robust voxel fallback when QuadriFlow fails on difficult input

Multi-island cleanup without the old fixed voxel floor that flattened density differences

UV/material/weight/rig preservation after retopology

Garment / Open Mesh

Bundled Instant Meshes backend

Boundary-aligned retopology for clothing and thin open shells

UV/material/weight/rig preservation after retopology

Preservation

Fast Remesher currently preserves and validates:

UV maps

UDIM tile coverage

material slots and per-face assignments

vertex groups

skin weights

color attributes (point and face-corner color layers)

custom normals and smooth/flat face state where present

armature parent/modifier relationship

object transforms and existing modifier stack

Shape keys are deliberately blocked by default. Retopology changes vertex correspondence, so silently claiming to preserve shape keys would be incorrect. If a user explicitly accepts losing shape keys, Allow Shape Key Loss can be enabled under Safety & Preservation.

Safety workflow

Every final remesh automatically runs Preflight. The first run stores an untouched original backup. Repeated runs start from that original rather than from a previously remeshed result.

Use:

Preflight to inspect topology, UV/UDIM data, rigging, shape keys, loose geometry, and unapplied scale

Restore Original to return to the stored untouched source

Set Current as Original only after intentionally changing the source and wanting future remeshes to use that new state

A tiny post-cleanup pass removes only numerical degenerate and loose artifacts. It is not an additional decimator.

Live Preview

Hard Surface Live Preview runs the same geometry decision path as the final Hard Surface operation on a temporary duplicate. The original stays untouched. Final Remesh discards the preview and reruns the production operation from the true source so UV/material/weight/rig transfer occurs normally.

Organic preview remains intentionally approximate because continuously running QuadriFlow while dragging controls would not be responsive.

Recommended workflow

Select one mesh object.

Run Preflight if the asset is production-critical.

Use Hard Surface Auto (Recommended) unless you know the asset class.

Use Live Preview for hard-surface topology inspection.

Run the final remesh.

Inspect the result summary and material preview.

Use Restore Original if the result is not suitable.

Known v1.0 limitations

Shape keys cannot be preserved across arbitrary retopology.

Generic custom attributes beyond UVs, color attributes, vertex groups, and custom normals are not guaranteed to survive arbitrary retopology.

Organic Live Preview is approximate.

This Windows release bundles only the Windows x64 Instant Meshes backend.

Fast Remesher does not promise 100% quads when an intentional triangle is safer than a distorted quad.

Extremely aggressive topology reduction can make exact existing-UV preservation mathematically impossible; use a baking workflow for those cases.

Third-party software

The Windows package bundles Instant Meshes. See THIRD_PARTY_NOTICES.md and INSTANT_MESHES_LICENSE.txt.

License

Fast Remesher is GPL-3.0-or-later. See LICENSE.