import time

import bpy
import bmesh
from bpy.types import Operator, Panel, PropertyGroup

from . import core

FIXED_SEED = 0
MAX_VOXEL_GRID_RESOLUTION = 400

PREVIEW_SOURCE_PROP = "fastremesher_preview_source"
PREVIEW_OBJECT_PROP = "fastremesher_preview_object"
PREVIEW_SOURCE_HIDDEN_PROP = "fastremesher_preview_source_was_hidden"
PREVIEW_PREFIX = "FastRemesher_LivePreview_"

PREVIEW_REMESH_NAME = "FastRemesher_Preview_Remesh"
PREVIEW_DECIMATE_NAME = "FastRemesher_Preview_Decimate"
PREVIEW_WELD_NAME = "FastRemesher_Preview_Weld"

_REFRESH_TOKEN = 0
_REFRESH_RUNNING = False


def _source_for_object(obj):
    if obj is None:
        return None
    source_name = obj.get(PREVIEW_SOURCE_PROP)
    if source_name:
        source = bpy.data.objects.get(source_name)
        if source is not None:
            return source
    return obj


def _preview_for_source(source):
    if source is None:
        return None
    preview_name = source.get(PREVIEW_OBJECT_PROP)
    if preview_name:
        preview_obj = bpy.data.objects.get(preview_name)
        if preview_obj is not None and preview_obj.get(PREVIEW_SOURCE_PROP) == source.name:
            return preview_obj
    for candidate in bpy.data.objects:
        if candidate.get(PREVIEW_SOURCE_PROP) == source.name:
            return candidate
    return None


def _has_preview(obj):
    source = _source_for_object(obj)
    return _preview_for_source(source) is not None


def _safe_remove_object(obj):
    if obj is None:
        return
    mesh = obj.data if obj.type == 'MESH' else None
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
    except Exception:
        return
    if mesh is not None and mesh.users == 0:
        try:
            bpy.data.meshes.remove(mesh)
        except Exception:
            pass


def _remove_preview_modifiers(obj):
    if obj is None:
        return
    for name in (PREVIEW_REMESH_NAME, PREVIEW_DECIMATE_NAME, PREVIEW_WELD_NAME):
        mod = obj.modifiers.get(name)
        if mod is not None:
            obj.modifiers.remove(mod)


def _safe_voxel_size(obj, requested_size):
    dims = obj.dimensions
    largest_dim = max(dims.x, dims.y, dims.z)
    if largest_dim <= 0:
        return requested_size
    min_safe_size = largest_dim / MAX_VOXEL_GRID_RESOLUTION
    return max(requested_size, min_safe_size, 0.0005)


def _auto_voxel_size(obj, target_faces_hint=1500):
    dims = obj.dimensions
    bbox_diagonal = (dims.x ** 2 + dims.y ** 2 + dims.z ** 2) ** 0.5
    if bbox_diagonal <= 0:
        return 0.05
    voxel_size = bbox_diagonal / (target_faces_hint ** 0.5) / 3.0
    return max(voxel_size, 0.0005)


def _clear_preview_result(preview_obj):
    if preview_obj is None:
        return
    for key in list(preview_obj.keys()):
        if key.startswith("fastremesher_result_"):
            try:
                del preview_obj[key]
            except Exception:
                pass


def _store_preview_result(preview_obj, result, elapsed):
    _clear_preview_result(preview_obj)
    if preview_obj is None or not result:
        return
    quality = result.get("topology_quality") or {}
    values = {
        "engine": result.get("engine", ""),
        "profile": result.get("profile", ""),
        "method": result.get("curved_method") or "",
        "faces_before": int(result.get("faces_before", 0)),
        "faces_after": int(result.get("faces_after", 0)),
        "quads": int(result.get("quads", 0)),
        "tris": int(result.get("tris_remaining", 0)),
        "quad_pct": float(result.get("quad_ratio", 0.0) * 100.0),
        "quality_grade": quality.get("grade", ""),
        "quality_score": float(quality.get("score", 0.0)),
        "bad_quad_pct": float(quality.get("bad_quad_ratio", 0.0) * 100.0),
        "warn_quad_pct": float(quality.get("warning_quad_ratio", 0.0) * 100.0),
        "max_deviation": float(result.get("max_deviation") or 0.0),
        "deviation_limit": float(result.get("deviation_limit") or 0.0),
        "elapsed": float(elapsed),
    }
    for key, value in values.items():
        preview_obj[f"fastremesher_result_{key}"] = value


def _reset_preview_mesh(preview_obj, source):
    _remove_preview_modifiers(preview_obj)
    old_mesh = preview_obj.data
    preview_obj.data = source.data.copy()
    if old_mesh is not None and old_mesh.users == 0:
        bpy.data.meshes.remove(old_mesh)


def _create_preview_object(context, source):
    preview_obj = source.copy()
    preview_obj.data = source.data.copy()
    preview_obj.name = PREVIEW_PREFIX + source.name
    preview_obj[PREVIEW_SOURCE_PROP] = source.name
    preview_obj.hide_render = True

    target_collection = None
    if source.users_collection:
        target_collection = source.users_collection[0]
    if target_collection is None:
        target_collection = context.collection
    target_collection.objects.link(preview_obj)

    source[PREVIEW_OBJECT_PROP] = preview_obj.name
    source[PREVIEW_SOURCE_HIDDEN_PROP] = bool(source.hide_get())
    source.hide_set(True)

    for selected in list(context.selected_objects):
        selected.select_set(False)
    preview_obj.hide_set(False)
    preview_obj.select_set(True)
    context.view_layer.objects.active = preview_obj

    preview_obj.show_wire = True
    preview_obj.show_all_edges = True
    return preview_obj


def _restore_source_visibility(context, source, preview_obj=None):
    if source is None:
        return
    was_hidden = bool(source.get(PREVIEW_SOURCE_HIDDEN_PROP, False))
    source.hide_set(was_hidden)
    for key in (PREVIEW_OBJECT_PROP, PREVIEW_SOURCE_HIDDEN_PROP):
        if key in source:
            del source[key]

    if preview_obj is not None:
        _safe_remove_object(preview_obj)

    if source.name in context.view_layer.objects:
        for selected in list(context.selected_objects):
            selected.select_set(False)
        source.select_set(True)
        context.view_layer.objects.active = source


def cleanup_all_previews():
    previews = [obj for obj in bpy.data.objects if obj.get(PREVIEW_SOURCE_PROP)]
    for preview_obj in previews:
        source = bpy.data.objects.get(preview_obj.get(PREVIEW_SOURCE_PROP, ""))
        if source is not None:
            try:
                source.hide_set(bool(source.get(PREVIEW_SOURCE_HIDDEN_PROP, False)))
            except Exception:
                pass
            for key in (PREVIEW_OBJECT_PROP, PREVIEW_SOURCE_HIDDEN_PROP):
                if key in source:
                    try:
                        del source[key]
                    except Exception:
                        pass
        _safe_remove_object(preview_obj)


def _build_organic_modifier_preview(preview_obj, settings):
    _remove_preview_modifiers(preview_obj)

    remesh_mod = preview_obj.modifiers.new(name=PREVIEW_REMESH_NAME, type='REMESH')
    remesh_mod.mode = 'VOXEL'
    remesh_mod.voxel_size = _safe_voxel_size(preview_obj, settings.voxel_size)
    remesh_mod.adaptivity = 0.0
    remesh_mod.use_remove_disconnected = False

    decimate_mod = preview_obj.modifiers.new(name=PREVIEW_DECIMATE_NAME, type='DECIMATE')
    decimate_mod.decimate_type = 'COLLAPSE'
    decimate_mod.ratio = settings.decimate_ratio

    weld_mod = preview_obj.modifiers.new(name=PREVIEW_WELD_NAME, type='WELD')
    weld_mod.merge_threshold = 0.0001


def _rebuild_hardsurface_preview(context, source, preview_obj):
    scene = context.scene
    main = scene.fast_remesher_settings
    _reset_preview_mesh(preview_obj, source)

    previous_active = context.view_layer.objects.active
    previous_selection = list(context.selected_objects)
    for selected in previous_selection:
        selected.select_set(False)
    preview_obj.select_set(True)
    context.view_layer.objects.active = preview_obj

    start = time.time()
    try:
        result = core.run_hardsurface(
            preview_obj,
            context,
            main.hs_detail_factor,
            main.hs_feature_angle,
            main.hs_max_input_faces,
            FIXED_SEED,
            main.hs_min_edge_length,
            main.hs_use_symmetry,
            main.hs_planar_angle,
            main.hs_preserve_uv_seams,
            main.hs_preserve_material_boundaries,
            main.hs_preset,
            transfer_surface_data=False,
        )
    finally:
        for selected in list(context.selected_objects):
            selected.select_set(False)
        if preview_obj.name in context.view_layer.objects:
            preview_obj.select_set(True)
            context.view_layer.objects.active = preview_obj
        elif previous_active is not None and previous_active.name in context.view_layer.objects:
            previous_active.select_set(True)
            context.view_layer.objects.active = previous_active

    elapsed = time.time() - start
    _store_preview_result(preview_obj, result, elapsed)
    return result


def _rebuild_preview(context):
    global _REFRESH_RUNNING
    if _REFRESH_RUNNING:
        return

    active = context.active_object
    source = _source_for_object(active)
    preview_obj = _preview_for_source(source)
    if source is None or preview_obj is None:
        return

    settings = context.scene.fast_remesher_preview_settings
    _REFRESH_RUNNING = True
    try:
        if settings.preview_mode == 'HARDSURFACE':
            context.workspace.status_text_set("Fast Remesher: rebuilding exact Hard Surface preview...")
            for area in context.screen.areas:
                area.tag_redraw()
            _rebuild_hardsurface_preview(context, source, preview_obj)
        else:
            _reset_preview_mesh(preview_obj, source)
            _build_organic_modifier_preview(preview_obj, settings)
            _clear_preview_result(preview_obj)
    finally:
        context.workspace.status_text_set(None)
        _REFRESH_RUNNING = False
        for area in context.screen.areas:
            area.tag_redraw()


def request_live_refresh(context=None, delay=0.30):
    """Debounce preview rebuilds so slider drags do not launch one solve per event."""
    global _REFRESH_TOKEN
    context = context or bpy.context
    scene = getattr(context, "scene", None)
    if scene is None or not hasattr(scene, "fast_remesher_preview_settings"):
        return
    settings = scene.fast_remesher_preview_settings
    if not settings.auto_refresh:
        return

    active = getattr(context, "active_object", None)
    source = _source_for_object(active)
    if source is None or _preview_for_source(source) is None:
        return

    _REFRESH_TOKEN += 1
    token = _REFRESH_TOKEN

    def _timer():
        if token != _REFRESH_TOKEN:
            return None
        try:
            _rebuild_preview(bpy.context)
        except Exception as exc:
            print(f"Fast Remesher live preview refresh failed: {exc}")
        return None

    try:
        bpy.app.timers.register(_timer, first_interval=max(0.05, float(delay)))
    except Exception:
        pass


def _on_preview_setting_update(self, context):
    request_live_refresh(context)


class FASTREMESHER_Preview_Settings(PropertyGroup):
    preview_mode: bpy.props.EnumProperty(
        name="Preview",
        items=[
            ('HARDSURFACE', "Hard Surface", "Run the same adaptive hard-surface engine used by the final remesh on a temporary duplicate"),
            ('ORGANIC', "Organic", "Fast approximate voxel preview; final Organic topology can differ"),
        ],
        default='HARDSURFACE',
        update=_on_preview_setting_update,
    )
    auto_refresh: bpy.props.BoolProperty(
        name="Auto Refresh",
        default=True,
        description="Rebuild the preview shortly after a setting changes instead of on every mouse event",
    )
    voxel_size: bpy.props.FloatProperty(
        name="Voxel Size",
        default=0.05,
        min=0.0005,
        max=2.0,
        description="Organic preview only. Smaller preserves more detail",
        update=_on_preview_setting_update,
    )
    decimate_ratio: bpy.props.FloatProperty(
        name="Decimate Amount",
        default=1.0,
        min=0.01,
        max=1.0,
        subtype='FACTOR',
        description="Organic preview only. 1.0 keeps the voxel result; lower values reduce it further",
        update=_on_preview_setting_update,
    )


class FASTREMESHER_OT_preview_start(Operator):
    bl_idname = "fastremesher.preview_start"
    bl_label = "Start Live Preview"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and not _has_preview(obj)

    def execute(self, context):
        source = context.active_object
        if source.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        main_settings = context.scene.fast_remesher_settings
        if (
            source.data.shape_keys is not None
            and len(source.data.shape_keys.key_blocks) > 1
            and not main_settings.allow_shape_key_loss
        ):
            self.report({'ERROR'}, "Shape keys detected. Enable Allow Shape Key Loss under Safety before previewing retopology")
            return {'CANCELLED'}

        # Preview and final remesh must both start from the persistent true
        # original, otherwise users would preview a previously remeshed result.
        core.ensure_fresh_original(context, source)

        settings = context.scene.fast_remesher_preview_settings
        settings.voxel_size = _auto_voxel_size(source)
        preview_obj = _create_preview_object(context, source)

        context.window.cursor_set('WAIT')
        try:
            _rebuild_preview(context)
        except Exception as exc:
            _restore_source_visibility(context, source, preview_obj)
            self.report({'ERROR'}, f"Could not start Live Preview: {exc}")
            return {'CANCELLED'}
        finally:
            context.window.cursor_set('DEFAULT')

        if settings.preview_mode == 'HARDSURFACE':
            self.report({'INFO'}, "Exact Hard Surface preview active on a temporary duplicate")
        else:
            self.report({'INFO'}, "Organic preview active (approximate)")
        return {'FINISHED'}


class FASTREMESHER_OT_preview_update(Operator):
    bl_idname = "fastremesher.preview_update"
    bl_label = "Refresh Preview"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _has_preview(context.active_object)

    def execute(self, context):
        context.window.cursor_set('WAIT')
        try:
            _rebuild_preview(context)
        except Exception as exc:
            self.report({'ERROR'}, f"Preview refresh failed: {exc}")
            return {'CANCELLED'}
        finally:
            context.window.cursor_set('DEFAULT')
        return {'FINISHED'}


class FASTREMESHER_OT_preview_cancel(Operator):
    bl_idname = "fastremesher.preview_cancel"
    bl_label = "Cancel Preview"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _has_preview(context.active_object)

    def execute(self, context):
        source = _source_for_object(context.active_object)
        preview_obj = _preview_for_source(source)
        _restore_source_visibility(context, source, preview_obj)
        self.report({'INFO'}, "Preview cancelled; original mesh is untouched")
        return {'FINISHED'}


def _organic_detail_from_preview(context, preview_obj, source):
    depsgraph = context.evaluated_depsgraph_get()
    obj_eval = preview_obj.evaluated_get(depsgraph)
    bm_sample = bmesh.new()
    try:
        bm_sample.from_mesh(obj_eval.data)
        bm_sample.edges.ensure_lookup_table()
        edge_sample = bm_sample.edges[:2000]
        if edge_sample:
            avg_edge_length = sum(e.calc_length() for e in edge_sample) / len(edge_sample)
        else:
            avg_edge_length = 0.05
    finally:
        bm_sample.free()

    scale = source.scale
    avg_scale = (abs(scale.x) + abs(scale.y) + abs(scale.z)) / 3.0
    if avg_scale <= 1e-8:
        avg_scale = 1.0
    world_edge_length = max(avg_edge_length, 0.0001) * avg_scale

    dims = source.dimensions
    bbox_diagonal = (dims.x ** 2 + dims.y ** 2 + dims.z ** 2) ** 0.5
    if bbox_diagonal <= 0:
        bbox_diagonal = 1.0
    return max(world_edge_length / bbox_diagonal, 0.0005)


class FASTREMESHER_OT_preview_send_to_final(Operator):
    bl_idname = "fastremesher.preview_send_to_final"
    bl_label = "Run Final Remesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _has_preview(context.active_object)

    def execute(self, context):
        scene = context.scene
        preview_settings = scene.fast_remesher_preview_settings
        main = scene.fast_remesher_settings
        source = _source_for_object(context.active_object)
        preview_obj = _preview_for_source(source)

        if source is None or preview_obj is None:
            self.report({'ERROR'}, "Live Preview source is no longer available")
            return {'CANCELLED'}

        if preview_settings.preview_mode == 'ORGANIC':
            try:
                main.organic_detail_factor = _organic_detail_from_preview(context, preview_obj, source)
            except Exception:
                pass

        _restore_source_visibility(context, source, preview_obj)

        if preview_settings.preview_mode == 'HARDSURFACE':
            return bpy.ops.fastremesher.hardsurface('EXEC_DEFAULT')
        return bpy.ops.fastremesher.organic('EXEC_DEFAULT')


# Backward-compatible operator IDs from older builds. They now route to the
# production-safe final operation rather than applying approximate preview
# modifiers directly to the user's source mesh.
class FASTREMESHER_OT_preview_apply(Operator):
    bl_idname = "fastremesher.preview_apply"
    bl_label = "Run Final Remesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _has_preview(context.active_object)

    def execute(self, context):
        return bpy.ops.fastremesher.preview_send_to_final('EXEC_DEFAULT')


class FASTREMESHER_OT_preview_send_to_quadriflow(Operator):
    bl_idname = "fastremesher.preview_send_to_quadriflow"
    bl_label = "Run Final Remesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _has_preview(context.active_object)

    def execute(self, context):
        return bpy.ops.fastremesher.preview_send_to_final('EXEC_DEFAULT')


class FASTREMESHER_PT_preview_panel(Panel):
    bl_idname = "FASTREMESHER_PT_preview_panel"
    bl_label = "Fast Remesher - Live Preview"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Fast Remesher"
    bl_order = 20

    def draw(self, context):
        layout = self.layout
        active = context.active_object
        source = _source_for_object(active)
        if source is None or source.type != 'MESH':
            layout.label(text="Select a mesh object")
            return

        settings = context.scene.fast_remesher_preview_settings
        main = context.scene.fast_remesher_settings
        preview_obj = _preview_for_source(source)

        if preview_obj is None:
            layout.prop(settings, "preview_mode", text="Mode")
            if settings.preview_mode == 'HARDSURFACE':
                layout.label(text="Uses the same engine as the final Hard Surface run", icon='INFO')
            else:
                layout.label(text="Organic preview is approximate", icon='INFO')
            layout.operator("fastremesher.preview_start", icon='PLAY')
            return

        box = layout.box()
        box.label(text="Live Preview Active", icon='HIDE_OFF')
        box.prop(settings, "preview_mode", text="Mode")
        box.prop(settings, "auto_refresh")

        if settings.preview_mode == 'HARDSURFACE':
            box.label(text="Exact adaptive Hard Surface geometry", icon='MOD_REMESH')
            box.prop(main, "hs_preset", text="Preset")
            box.prop(main, "hs_use_symmetry")
            if main.hs_show_advanced or main.hs_preset == 'CUSTOM':
                col = box.column(align=True)
                col.prop(main, "hs_detail_factor")
                col.prop(main, "hs_feature_angle")
                col.prop(main, "hs_planar_angle")
                row = col.row(align=True)
                row.prop(main, "hs_preserve_uv_seams")
                row.prop(main, "hs_preserve_material_boundaries")

            engine = preview_obj.get("fastremesher_result_engine", "")
            if engine:
                profile = preview_obj.get("fastremesher_result_profile", "")
                method = preview_obj.get("fastremesher_result_method", "")
                faces_before = int(preview_obj.get("fastremesher_result_faces_before", 0))
                faces_after = int(preview_obj.get("fastremesher_result_faces_after", 0))
                quads = int(preview_obj.get("fastremesher_result_quads", 0))
                tris = int(preview_obj.get("fastremesher_result_tris", 0))
                quad_pct = float(preview_obj.get("fastremesher_result_quad_pct", 0.0))
                grade = preview_obj.get("fastremesher_result_quality_grade", "")
                score = float(preview_obj.get("fastremesher_result_quality_score", 0.0))
                elapsed = float(preview_obj.get("fastremesher_result_elapsed", 0.0))

                stats = layout.box()
                stats.label(text=f"{engine} / {profile}")
                if method:
                    stats.label(text=f"Method: {method}")
                stats.label(text=f"Faces: {faces_before} -> {faces_after}")
                stats.label(text=f"Quads: {quads} ({quad_pct:.1f}%)   Tris: {tris}")
                if grade:
                    stats.label(text=f"Quality: {grade} ({score:.0f})")
                stats.label(text=f"Preview solve: {elapsed:.1f}s")
        else:
            box.label(text="Fast approximate Organic preview", icon='INFO')
            box.prop(settings, "voxel_size")
            safe_size = _safe_voxel_size(preview_obj, settings.voxel_size)
            if abs(safe_size - settings.voxel_size) > 1e-6:
                box.label(text=f"Voxel clamped to {safe_size:.4f} for stability", icon='ERROR')
            box.prop(settings, "decimate_ratio")
            depsgraph = context.evaluated_depsgraph_get()
            try:
                eval_faces = len(preview_obj.evaluated_get(depsgraph).data.polygons)
            except Exception:
                eval_faces = len(preview_obj.data.polygons)
            layout.label(text=f"Approximate preview: {eval_faces} faces")

        if not settings.auto_refresh:
            layout.operator("fastremesher.preview_update", text="Refresh Preview", icon='FILE_REFRESH')
        else:
            layout.label(text="Changes refresh after a short debounce", icon='TIME')

        row = layout.row(align=True)
        row.operator("fastremesher.preview_cancel", text="Cancel", icon='X')
        row.operator("fastremesher.preview_send_to_final", text="Run Final Remesh", icon='CHECKMARK')

        layout.label(text="Preview is temporary; final run performs UV/rig transfer", icon='LOCKED')


classes = (
    FASTREMESHER_Preview_Settings,
    FASTREMESHER_OT_preview_start,
    FASTREMESHER_OT_preview_update,
    FASTREMESHER_OT_preview_cancel,
    FASTREMESHER_OT_preview_send_to_final,
    FASTREMESHER_OT_preview_apply,
    FASTREMESHER_OT_preview_send_to_quadriflow,
    FASTREMESHER_PT_preview_panel,
)