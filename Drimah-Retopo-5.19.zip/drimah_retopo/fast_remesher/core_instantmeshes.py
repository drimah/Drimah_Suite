import bpy
import bmesh
import os
import platform
import subprocess
import tempfile

from . import core


def _binary_path():
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    system = platform.system()
    if system == 'Windows':
        name = 'Instant Meshes.exe'
    elif system == 'Darwin':
        name = 'Instant Meshes.app/Contents/MacOS/Instant Meshes'
    else:
        name = 'Instant Meshes'
    path = os.path.join(addon_dir, 'bin', system, name)
    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"Instant Meshes binary not found at {path}. "
            f"Bundle a build for {system} under bin/{system}/ before using this mode."
        )
    return path


def run_instant_meshes(obj, context, target_faces, deterministic=True, crease_angle_degrees=None,
                        max_input_faces=150000, align_boundaries=True,
                        transfer_surface_data=True, clamp_to_target=True):
    mesh = obj.data
    verts_before = len(mesh.vertices)
    faces_before = len(mesh.polygons)

    orig_location = obj.location.copy()
    orig_rotation_mode = obj.rotation_mode
    orig_rotation_euler = obj.rotation_euler.copy()
    orig_rotation_quat = obj.rotation_quaternion.copy()
    orig_rotation_axis_angle = obj.rotation_axis_angle[:]
    orig_scale = obj.scale.copy()

    if faces_before > max_input_faces:
        decimate_mod = obj.modifiers.new(name="FastRemesher_IM_PreDecimate", type='DECIMATE')
        decimate_mod.ratio = max_input_faces / faces_before
        depsgraph = context.evaluated_depsgraph_get()
        obj_eval = obj.evaluated_get(depsgraph)
        decimated_mesh = bpy.data.meshes.new_from_object(obj_eval)
        obj.modifiers.remove(decimate_mod)
        old_mesh = obj.data
        obj.data = decimated_mesh
        if old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)

    islands = core._count_islands(obj)
    fragmented = islands > 1 and not align_boundaries

    snapshot_obj = None
    if fragmented:
        snapshot_obj = core._make_original_snapshot(obj, context)
        core._coarse_voxel_proxy(obj, context, target_faces)

    mesh = obj.data

    binary = _binary_path()

    with tempfile.TemporaryDirectory() as tmpdir:
        in_path = os.path.join(tmpdir, "input.obj")
        out_path = os.path.join(tmpdir, "output.obj")

        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.triangulate(bm, faces=bm.faces)
        tmp_mesh = bpy.data.meshes.new("FastRemesher_IM_tmp")
        bm.to_mesh(tmp_mesh)
        bm.free()

        tmp_obj = bpy.data.objects.new("FastRemesher_IM_tmp", tmp_mesh)
        context.collection.objects.link(tmp_obj)
        prev_selection = context.view_layer.objects.selected[:]
        for o in prev_selection:
            o.select_set(False)
        tmp_obj.select_set(True)
        context.view_layer.objects.active = tmp_obj

        bpy.ops.wm.obj_export(
            filepath=in_path,
            export_selected_objects=True,
            export_materials=False,
            export_uv=False,
            forward_axis='NEGATIVE_Z',
            up_axis='Y',
        )

        bpy.data.objects.remove(tmp_obj, do_unlink=True)
        bpy.data.meshes.remove(tmp_mesh)

        # Instant Meshes' batch parser is most reliable when options precede
        # the input filename (the same ordering used by its reference Blender
        # bridges). Keep the input path last rather than mixing positional and
        # optional arguments.
        cmd = [
            binary,
            "-o", out_path,
            "-f", str(target_faces),
            "-r", "4",
            "-p", "4",
            "-S", "2",
        ]
        if deterministic:
            cmd += ["-d"]
        if crease_angle_degrees is not None:
            cmd += ["-c", str(crease_angle_degrees)]
        if align_boundaries:
            cmd += ["-b"]
        cmd += [in_path]

        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=600,
            cwd=os.path.dirname(binary),
        )
        if proc.returncode != 0 or not os.path.isfile(out_path):
            raise RuntimeError(
                f"Instant Meshes failed (exit {proc.returncode}).\n"
                f"stdout: {proc.stdout}\nstderr: {proc.stderr}"
            )

        bpy.ops.wm.obj_import(
            filepath=out_path,
            forward_axis='NEGATIVE_Z',
            up_axis='Y',
        )
        new_obj = context.view_layer.objects.active

        context.view_layer.objects.active = new_obj
        for o in context.view_layer.objects.selected[:]:
            o.select_set(False)
        new_obj.select_set(True)
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

        new_mesh = new_obj.data

        # Validate imported remesh before touching the user's source mesh.
        # Reject empty or severely degenerate output; caller's rollback handler
        # can then restore the saved original instead of leaving a broken mesh.
        if len(new_mesh.vertices) < 4 or len(new_mesh.polygons) < 1:
            bpy.data.objects.remove(new_obj, do_unlink=True)
            raise RuntimeError("Instant Meshes returned an empty mesh; original geometry was not replaced")
        new_mesh.update()
        zero_area = sum(1 for poly in new_mesh.polygons if poly.area <= 1e-12)
        if zero_area > max(2, int(len(new_mesh.polygons) * 0.02)):
            bpy.data.objects.remove(new_obj, do_unlink=True)
            raise RuntimeError("Instant Meshes returned a degenerate mesh; original geometry was not replaced")

        # Quality guard: Instant Meshes is expected to produce quad-dominant
        # output for this workflow. Reject triangle-soup output before replacing
        # the user's mesh. This is a conservative safety check, not a guarantee
        # of artistic quality.
        triangle_faces = sum(1 for poly in new_mesh.polygons if len(poly.vertices) == 3)
        triangle_ratio = triangle_faces / max(1, len(new_mesh.polygons))
        if len(new_mesh.polygons) >= 20 and triangle_ratio > 0.75:
            bpy.data.objects.remove(new_obj, do_unlink=True)
            raise RuntimeError(
                f"Resultado rejeitado: {triangle_ratio:.0%} triângulos. Original preservado; tente Hard Surface/Orgânico ou revise a malha de entrada."
            )

        old_mesh = obj.data
        obj.data = new_mesh
        bpy.data.objects.remove(new_obj, do_unlink=True)
        if old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)

    obj.location = orig_location
    obj.rotation_mode = orig_rotation_mode
    obj.rotation_euler = orig_rotation_euler
    obj.rotation_quaternion = orig_rotation_quat
    obj.rotation_axis_angle = orig_rotation_axis_angle
    obj.scale = orig_scale

    if fragmented:
        core._shrinkwrap_onto(obj, context, snapshot_obj)
        core._cleanup_snapshot(snapshot_obj)

    clamped = False
    current_faces = len(obj.data.polygons)
    if clamp_to_target and current_faces > target_faces * 1.15:
        clamp_mod = obj.modifiers.new(name="FastRemesher_TargetClamp", type='DECIMATE')
        clamp_mod.ratio = target_faces / current_faces
        depsgraph = context.evaluated_depsgraph_get()
        obj_eval = obj.evaluated_get(depsgraph)
        clamped_mesh = bpy.data.meshes.new_from_object(obj_eval)
        obj.modifiers.remove(clamp_mod)
        old_mesh = obj.data
        obj.data = clamped_mesh
        if old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)
        clamped = True

    cleanup_result = core.safe_post_cleanup(obj)

    surface_transfer_result = None
    if transfer_surface_data:
        surface_transfer_result = core.transfer_uv_and_materials(obj, context)

    tris_remaining = sum(1 for p in obj.data.polygons if len(p.vertices) == 3)

    return {
        "verts_before": verts_before,
        "verts_after": len(obj.data.vertices),
        "faces_before": faces_before,
        "faces_after": len(obj.data.polygons),
        "tris_remaining": tris_remaining,
        "fragmented": fragmented,
        "clamped": clamped,
        "surface_transfer": surface_transfer_result,
        "cleanup": cleanup_result,
        "target_faces": target_faces,
        "stdout": proc.stdout[-4000:] if proc.stdout else "",
        "stderr": proc.stderr[-4000:] if proc.stderr else "",
    }