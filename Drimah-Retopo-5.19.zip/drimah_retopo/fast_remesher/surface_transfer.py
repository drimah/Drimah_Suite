import bpy
import math
from mathutils.bvhtree import BVHTree


class SurfaceTransferMap:
    """World-space nearest-surface map used for face-level data such as materials."""

    def __init__(self, source_obj):
        self.source_obj = source_obj
        self.source_mesh = source_obj.data
        self.matrix_world = source_obj.matrix_world.copy()
        self.triangles = []
        self.bvh = None

    def build(self):
        mesh = self.source_mesh
        mesh.calc_loop_triangles()

        world_vertices = [self.matrix_world @ vertex.co for vertex in mesh.vertices]
        polygons = []
        triangles = []

        for tri in mesh.loop_triangles:
            vertices = tuple(tri.vertices)
            polygons.append(vertices)
            triangles.append({
                "vertices": vertices,
                "polygon_index": tri.polygon_index,
            })

        if not polygons:
            return False

        self.triangles = triangles
        self.bvh = BVHTree.FromPolygons(world_vertices, polygons, all_triangles=True)
        return self.bvh is not None

    def nearest(self, world_point):
        if self.bvh is None:
            return None

        location, normal, tri_index, distance = self.bvh.find_nearest(world_point)
        if location is None or tri_index is None:
            return None
        if tri_index < 0 or tri_index >= len(self.triangles):
            return None

        return location, normal, tri_index, distance


def _copy_material_slots(source_obj, target_obj):
    target_obj.data.materials.clear()
    for material in source_obj.data.materials:
        target_obj.data.materials.append(material)


def _transfer_material_indices(transfer_map, target_obj):
    source_mesh = transfer_map.source_mesh
    target_mesh = target_obj.data
    target_world = target_obj.matrix_world
    transferred = 0

    for poly in target_mesh.polygons:
        world_center = target_world @ poly.center
        hit = transfer_map.nearest(world_center)
        if hit is None:
            continue

        tri = transfer_map.triangles[hit[2]]
        source_poly_index = tri["polygon_index"]
        if 0 <= source_poly_index < len(source_mesh.polygons):
            source_poly = source_mesh.polygons[source_poly_index]
            poly.material_index = source_poly.material_index
            poly.use_smooth = source_poly.use_smooth
            transferred += 1

    return transferred


def _capture_uv_state(mesh):
    active_name = mesh.uv_layers.active.name if mesh.uv_layers.active is not None else None
    render_name = None
    for layer in mesh.uv_layers:
        if getattr(layer, "active_render", False):
            render_name = layer.name
            break
    return active_name, render_name


def _prepare_uv_layers(source_mesh, target_mesh):
    """Create destination UV layers because Data Transfer does not create them."""
    active_name, render_name = _capture_uv_state(source_mesh)

    for layer in reversed(list(target_mesh.uv_layers)):
        target_mesh.uv_layers.remove(layer)
    for source_layer in source_mesh.uv_layers:
        target_mesh.uv_layers.new(name=source_layer.name)

    if active_name:
        active_index = target_mesh.uv_layers.find(active_name)
        if active_index >= 0:
            target_mesh.uv_layers.active_index = active_index

    if render_name:
        render_layer = target_mesh.uv_layers.get(render_name)
        if render_layer is not None and hasattr(render_layer, "active_render"):
            render_layer.active_render = True

    target_mesh.update()
    return active_name, render_name


def _source_has_custom_normals(mesh):
    try:
        if bool(getattr(mesh, "has_custom_normals", False)):
            return True
    except Exception:
        pass
    attributes = getattr(mesh, "attributes", None)
    return bool(attributes is not None and attributes.get("custom_normal") is not None)


def _prepare_color_attributes(source_mesh, target_mesh):
    source_colors = getattr(source_mesh, "color_attributes", None)
    target_colors = getattr(target_mesh, "color_attributes", None)
    if source_colors is None or target_colors is None:
        return {"count": 0, "corner": 0, "point": 0, "active": "", "default": ""}

    active_name = getattr(source_colors, "active_color_name", "")
    default_name = getattr(source_colors, "default_color_name", "")

    for attr in reversed(list(target_colors)):
        target_colors.remove(attr)

    corner = 0
    point = 0
    for attr in source_colors:
        if attr.domain not in {'POINT', 'CORNER'}:
            continue
        if attr.data_type not in {'FLOAT_COLOR', 'BYTE_COLOR'}:
            continue
        target_colors.new(name=attr.name, type=attr.data_type, domain=attr.domain)
        if attr.domain == 'CORNER':
            corner += 1
        else:
            point += 1

    try:
        if active_name and target_colors.get(active_name) is not None:
            target_colors.active_color_name = active_name
        if default_name and target_colors.get(default_name) is not None:
            target_colors.default_color_name = default_name
    except Exception:
        pass

    target_mesh.update()
    return {
        "count": corner + point,
        "corner": corner,
        "point": point,
        "active": active_name,
        "default": default_name,
    }


def _apply_shading_transfer_modifier(target_obj, source_obj, color_state, transfer_normals):
    loop_types = set()
    vert_types = set()
    if color_state.get("corner"):
        loop_types.add('COLOR_CORNER')
    if color_state.get("point"):
        vert_types.add('COLOR_VERTEX')
    if transfer_normals:
        loop_types.add('CUSTOM_NORMAL')

    if not loop_types and not vert_types:
        return

    if transfer_normals:
        attributes = getattr(target_obj.data, "attributes", None)
        if attributes is not None and attributes.get("custom_normal") is None:
            try:
                attributes.new(name="custom_normal", type='FLOAT_VECTOR', domain='CORNER')
            except Exception:
                pass

    source_states = _capture_modifier_states(source_obj)
    target_states = _capture_modifier_states(target_obj)
    modifier_name = "FastRemesher_ShadingTransfer"
    try:
        _disable_modifier_states(source_obj, source_states)
        _disable_modifier_states(target_obj, target_states)
        modifier = target_obj.modifiers.new(name=modifier_name, type='DATA_TRANSFER')
        modifier.object = source_obj
        modifier.use_object_transform = True
        modifier.mix_mode = 'REPLACE'
        modifier.mix_factor = 1.0
        modifier.use_max_distance = False

        if loop_types:
            modifier.use_loop_data = True
            modifier.data_types_loops = loop_types
            modifier.loop_mapping = 'POLYINTERP_NEAREST'
            if color_state.get("corner"):
                modifier.layers_vcol_loop_select_src = 'ALL'
                modifier.layers_vcol_loop_select_dst = 'NAME'

        if vert_types:
            modifier.use_vert_data = True
            modifier.data_types_verts = vert_types
            modifier.vert_mapping = 'POLYINTERP_NEAREST'
            modifier.layers_vcol_vert_select_src = 'ALL'
            modifier.layers_vcol_vert_select_dst = 'NAME'

        _apply_modifier_safely(target_obj, modifier_name)
    finally:
        remaining = target_obj.modifiers.get(modifier_name)
        if remaining is not None:
            target_obj.modifiers.remove(remaining)
        _restore_modifier_states(source_obj, source_states)
        _restore_modifier_states(target_obj, target_states)


def _validate_color_attributes(source_mesh, target_mesh):
    source = {
        attr.name: (attr.domain, attr.data_type)
        for attr in getattr(source_mesh, "color_attributes", [])
        if attr.domain in {'POINT', 'CORNER'} and attr.data_type in {'FLOAT_COLOR', 'BYTE_COLOR'}
    }
    target = {
        attr.name: (attr.domain, attr.data_type)
        for attr in getattr(target_mesh, "color_attributes", [])
        if attr.domain in {'POINT', 'CORNER'} and attr.data_type in {'FLOAT_COLOR', 'BYTE_COLOR'}
    }
    return source == target


def _transfer_shading_attributes(source_obj, target_obj):
    color_state = _prepare_color_attributes(source_obj.data, target_obj.data)
    custom_normals = _source_has_custom_normals(source_obj.data)
    _apply_shading_transfer_modifier(target_obj, source_obj, color_state, custom_normals)
    colors_valid = _validate_color_attributes(source_obj.data, target_obj.data)
    normals_valid = (not custom_normals) or _source_has_custom_normals(target_obj.data)
    return {
        "color_attributes": color_state.get("count", 0),
        "color_attributes_preserved": colors_valid,
        "custom_normals": custom_normals,
        "custom_normals_transferred": normals_valid if custom_normals else False,
        "shading_preserved": colors_valid and normals_valid,
    }


def _capture_modifier_states(obj):
    states = []
    for modifier in obj.modifiers:
        states.append((modifier.name, modifier.show_viewport))
    return states


def _disable_modifier_states(obj, states, except_name=None):
    for name, _show_viewport in states:
        modifier = obj.modifiers.get(name)
        if modifier is not None and modifier.name != except_name:
            modifier.show_viewport = False


def _restore_modifier_states(obj, states):
    for name, show_viewport in states:
        modifier = obj.modifiers.get(name)
        if modifier is not None:
            modifier.show_viewport = show_viewport


def _apply_modifier_safely(target_obj, modifier_name):
    view_layer = bpy.context.view_layer
    previous_active = view_layer.objects.active
    previous_selected = list(bpy.context.selected_objects)
    previous_mode = target_obj.mode

    try:
        if previous_mode != 'OBJECT':
            view_layer.objects.active = target_obj
            target_obj.select_set(True)
            bpy.ops.object.mode_set(mode='OBJECT')

        for obj in previous_selected:
            if obj and obj.name in bpy.data.objects:
                obj.select_set(False)
        target_obj.select_set(True)
        view_layer.objects.active = target_obj

        bpy.ops.object.modifier_apply(modifier=modifier_name)
    finally:
        target_obj.select_set(False)
        for obj in previous_selected:
            if obj and obj.name in bpy.data.objects:
                obj.select_set(True)
        if previous_active and previous_active.name in bpy.data.objects:
            view_layer.objects.active = previous_active
        elif target_obj.name in bpy.data.objects:
            view_layer.objects.active = target_obj


def _apply_data_transfer_modifier(target_obj, source_obj, islands_precision):
    """Transfer all UV maps with Blender's seam/island-aware interpolated mapping."""
    source_states = _capture_modifier_states(source_obj)
    target_states = _capture_modifier_states(target_obj)
    modifier = None
    modifier_name = "FastRemesher_UVTransfer"

    try:
        # Map raw remeshed geometry to raw original geometry. This is critical
        # for rigged characters in a non-rest pose: the source still has valid
        # weights while the remeshed target does not yet, so evaluating an
        # Armature modifier on only one side would map two different shapes.
        _disable_modifier_states(source_obj, source_states)
        _disable_modifier_states(target_obj, target_states)

        modifier = target_obj.modifiers.new(
            name=modifier_name,
            type='DATA_TRANSFER',
        )
        modifier.object = source_obj
        modifier.use_object_transform = True
        modifier.use_loop_data = True
        modifier.data_types_loops = {'UV'}
        modifier.loop_mapping = 'POLYINTERP_NEAREST'
        modifier.layers_uv_select_src = 'ALL'
        modifier.layers_uv_select_dst = 'NAME'
        modifier.mix_mode = 'REPLACE'
        modifier.mix_factor = 1.0
        modifier.use_max_distance = False
        modifier.islands_precision = islands_precision

        _apply_modifier_safely(target_obj, modifier_name)
    finally:
        remaining = target_obj.modifiers.get(modifier_name)
        if remaining is not None:
            target_obj.modifiers.remove(remaining)
        _restore_modifier_states(source_obj, source_states)
        _restore_modifier_states(target_obj, target_states)


def _uv_bounds(layer):
    if not layer.data:
        return None

    min_u = math.inf
    min_v = math.inf
    max_u = -math.inf
    max_v = -math.inf

    for item in layer.data:
        uv = item.uv
        if not (math.isfinite(uv.x) and math.isfinite(uv.y)):
            return None
        min_u = min(min_u, uv.x)
        min_v = min(min_v, uv.y)
        max_u = max(max_u, uv.x)
        max_v = max(max_v, uv.y)

    return min_u, min_v, max_u, max_v


def _validate_uv_transfer(source_mesh, target_mesh):
    """Catch the common silent failure where UV layers exist but contain no useful mapping."""
    if not source_mesh.uv_layers:
        return True, None

    if len(target_mesh.uv_layers) != len(source_mesh.uv_layers):
        return False, "UV layer count mismatch after transfer"

    for source_layer in source_mesh.uv_layers:
        target_layer = target_mesh.uv_layers.get(source_layer.name)
        if target_layer is None:
            return False, f"missing UV layer '{source_layer.name}' after transfer"

        source_bounds = _uv_bounds(source_layer)
        target_bounds = _uv_bounds(target_layer)
        if source_bounds is None or target_bounds is None:
            return False, f"invalid UV values in layer '{source_layer.name}'"

        src_span = max(
            source_bounds[2] - source_bounds[0],
            source_bounds[3] - source_bounds[1],
        )
        dst_span = max(
            target_bounds[2] - target_bounds[0],
            target_bounds[3] - target_bounds[1],
        )

        if src_span > 1.0e-6 and dst_span <= 1.0e-8:
            return False, f"UV layer '{source_layer.name}' collapsed during transfer"

    return True, None


def _transfer_uv_layers(source_obj, target_obj, islands_precision=0.1):
    source_mesh = source_obj.data
    target_mesh = target_obj.data

    if not source_mesh.uv_layers:
        return 0, 0, None

    active_name, render_name = _prepare_uv_layers(source_mesh, target_mesh)
    _apply_data_transfer_modifier(target_obj, source_obj, islands_precision)

    if active_name:
        active_index = target_mesh.uv_layers.find(active_name)
        if active_index >= 0:
            target_mesh.uv_layers.active_index = active_index
    if render_name:
        render_layer = target_mesh.uv_layers.get(render_name)
        if render_layer is not None and hasattr(render_layer, "active_render"):
            render_layer.active_render = True

    target_mesh.update()

    valid, validation_error = _validate_uv_transfer(source_mesh, target_mesh)
    if not valid:
        raise RuntimeError(validation_error)

    return len(target_mesh.loops), 0, None


def _capture_vertex_group_state(source_obj):
    groups = []
    for group in source_obj.vertex_groups:
        groups.append({
            "name": group.name,
            "lock_weight": bool(getattr(group, "lock_weight", False)),
        })

    active_name = None
    active_index = getattr(source_obj.vertex_groups, "active_index", -1)
    if 0 <= active_index < len(source_obj.vertex_groups):
        active_name = source_obj.vertex_groups[active_index].name

    return groups, active_name


def _prepare_vertex_groups(source_obj, target_obj):
    groups, active_name = _capture_vertex_group_state(source_obj)

    for group in reversed(list(target_obj.vertex_groups)):
        target_obj.vertex_groups.remove(group)

    for source_group in groups:
        target_group = target_obj.vertex_groups.new(name=source_group["name"])
        if hasattr(target_group, "lock_weight"):
            target_group.lock_weight = source_group["lock_weight"]

    if active_name:
        active_group = target_obj.vertex_groups.get(active_name)
        if active_group is not None:
            target_obj.vertex_groups.active_index = active_group.index

    return groups, active_name


def _apply_vertex_group_transfer_modifier(target_obj, source_obj):
    """Transfer all vertex groups using nearest-face barycentric interpolation."""
    source_states = _capture_modifier_states(source_obj)
    target_states = _capture_modifier_states(target_obj)
    modifier = None
    modifier_name = "FastRemesher_WeightTransfer"

    try:
        _disable_modifier_states(source_obj, source_states)
        _disable_modifier_states(target_obj, target_states)

        modifier = target_obj.modifiers.new(
            name=modifier_name,
            type='DATA_TRANSFER',
        )
        modifier.object = source_obj
        modifier.use_object_transform = True
        modifier.use_vert_data = True
        modifier.data_types_verts = {'VGROUP_WEIGHTS'}
        modifier.vert_mapping = 'POLYINTERP_NEAREST'
        modifier.layers_vgroup_select_src = 'ALL'
        modifier.layers_vgroup_select_dst = 'NAME'
        modifier.mix_mode = 'REPLACE'
        modifier.mix_factor = 1.0
        modifier.use_max_distance = False

        _apply_modifier_safely(target_obj, modifier_name)
    finally:
        remaining = target_obj.modifiers.get(modifier_name)
        if remaining is not None:
            target_obj.modifiers.remove(remaining)
        _restore_modifier_states(source_obj, source_states)
        _restore_modifier_states(target_obj, target_states)


def _weight_stats(obj):
    group_names = {group.index: group.name for group in obj.vertex_groups}
    weighted_groups = set()
    weighted_vertices = 0
    assignments = 0

    for vertex in obj.data.vertices:
        has_weight = False
        for element in vertex.groups:
            if element.group not in group_names:
                continue
            if element.weight <= 1.0e-8:
                continue
            weighted_groups.add(group_names[element.group])
            assignments += 1
            has_weight = True
        if has_weight:
            weighted_vertices += 1

    return {
        "weighted_groups": weighted_groups,
        "weighted_vertices": weighted_vertices,
        "assignments": assignments,
    }


def _armature_deform_group_names(obj):
    names = set()
    armatures = []

    if obj.parent is not None and obj.parent.type == 'ARMATURE':
        armatures.append(obj.parent)

    for modifier in obj.modifiers:
        if modifier.type == 'ARMATURE' and modifier.object is not None:
            armatures.append(modifier.object)

    seen = set()
    for armature_obj in armatures:
        if armature_obj.name in seen or armature_obj.type != 'ARMATURE':
            continue
        seen.add(armature_obj.name)
        for bone in armature_obj.data.bones:
            if bone.use_deform:
                names.add(bone.name)

    return names


def _validate_vertex_group_transfer(source_obj, target_obj):
    source_names = [group.name for group in source_obj.vertex_groups]
    target_names = [group.name for group in target_obj.vertex_groups]

    if source_names != target_names:
        return False, "vertex group names/order mismatch after transfer", None

    source_stats = _weight_stats(source_obj)
    target_stats = _weight_stats(target_obj)

    if source_stats["assignments"] > 0 and target_stats["assignments"] == 0:
        return False, "vertex groups exist but transferred weights are empty", target_stats

    deform_names = _armature_deform_group_names(source_obj)
    source_deform_weighted = source_stats["weighted_groups"].intersection(deform_names)
    target_deform_weighted = target_stats["weighted_groups"].intersection(deform_names)

    if source_deform_weighted and not target_deform_weighted:
        return False, "armature deform weights were not transferred", target_stats

    return True, None, target_stats


def _transfer_vertex_groups(source_obj, target_obj):
    if not source_obj.vertex_groups:
        return {
            "groups": 0,
            "weighted_groups": 0,
            "weighted_vertices": 0,
            "assignments": 0,
        }

    _prepare_vertex_groups(source_obj, target_obj)
    _apply_vertex_group_transfer_modifier(target_obj, source_obj)

    valid, validation_error, stats = _validate_vertex_group_transfer(source_obj, target_obj)
    if not valid:
        raise RuntimeError(validation_error)

    return {
        "groups": len(target_obj.vertex_groups),
        "weighted_groups": len(stats["weighted_groups"]),
        "weighted_vertices": stats["weighted_vertices"],
        "assignments": stats["assignments"],
    }


def _armature_state(obj):
    parent_name = obj.parent.name if obj.parent is not None and obj.parent.type == 'ARMATURE' else None
    modifiers = []
    for modifier in obj.modifiers:
        if modifier.type != 'ARMATURE':
            continue
        modifiers.append({
            "name": modifier.name,
            "object": modifier.object.name if modifier.object is not None else None,
        })
    return parent_name, modifiers


def _validate_armature_relationship(source_obj, target_obj):
    source_parent, source_modifiers = _armature_state(source_obj)
    target_parent, target_modifiers = _armature_state(target_obj)

    source_bound = source_parent is not None or bool(source_modifiers)
    if not source_bound:
        return True, False, 0, None

    if source_parent != target_parent:
        return False, True, len(target_modifiers), "armature parent relationship changed"

    source_bindings = {(item["name"], item["object"]) for item in source_modifiers}
    target_bindings = {(item["name"], item["object"]) for item in target_modifiers}
    if source_bindings != target_bindings:
        return False, True, len(target_modifiers), "Armature modifier binding changed"

    return True, True, len(target_modifiers), None




def _uv_tile_ids(mesh):
    """Return UDIM tile IDs used by each UV layer.

    Tile 1001 is the normal 0-1 tile. Negative UV tiles are intentionally
    ignored because they are not addressable UDIM tiles.
    """
    tiles_by_layer = {}
    for layer in mesh.uv_layers:
        tiles = set()
        for item in layer.data:
            u = float(item.uv.x)
            v = float(item.uv.y)
            tile_u = math.floor(u)
            tile_v = math.floor(v)
            if tile_u < 0 or tile_v < 0:
                continue
            tiles.add(1001 + int(tile_u) + int(tile_v) * 10)
        tiles_by_layer[layer.name] = sorted(tiles)
    return tiles_by_layer


def _validate_udim_tiles(source_mesh, target_mesh):
    source_tiles = _uv_tile_ids(source_mesh)
    target_tiles = _uv_tile_ids(target_mesh)
    preserved = True
    for name, tiles in source_tiles.items():
        if target_tiles.get(name, []) != tiles:
            preserved = False
            break
    return preserved, source_tiles, target_tiles


def transfer_surface_data(target_obj, source_obj, islands_precision=0.1):
    """Transfer production-critical surface and rig data after retopology.

    UVs use Blender's island-aware face-corner interpolation. Vertex groups,
    including armature skin weights, use nearest-face interpolated transfer in
    undeformed mesh space so posed rigs do not corrupt the correspondence.
    """
    result = {
        "success": False,
        "partial": False,
        "uv_layers": 0,
        "uv_loops_mapped": 0,
        "uv_misses": 0,
        "material_faces_mapped": 0,
        "vertex_groups": 0,
        "weighted_groups": 0,
        "weighted_vertices": 0,
        "weight_assignments": 0,
        "armature_bound": False,
        "armature_modifiers": 0,
        "armature_preserved": True,
        "color_attributes": 0,
        "color_attributes_preserved": True,
        "custom_normals": False,
        "custom_normals_transferred": False,
        "udim_preserved": True,
        "udim_tiles": {},
        "udim_target_tiles": {},
        "uv_method": "DATA_TRANSFER_POLYINTERP_NEAREST",
        "weight_method": "DATA_TRANSFER_POLYINTERP_NEAREST",
        "islands_precision": islands_precision,
        "errors": [],
        "error": None,
    }

    if target_obj is None or source_obj is None:
        result["error"] = "missing source or target"
        result["errors"].append(result["error"])
        return result
    if target_obj.type != 'MESH' or source_obj.type != 'MESH':
        result["error"] = "source and target must be meshes"
        result["errors"].append(result["error"])
        return result

    transfer_map = SurfaceTransferMap(source_obj)
    if not transfer_map.build():
        result["error"] = "source mesh has no transferable triangles"
        result["errors"].append(result["error"])
        return result

    completed_stages = 0
    requested_stages = 2
    if source_obj.data.uv_layers:
        requested_stages += 1
    if source_obj.vertex_groups:
        requested_stages += 1
    source_color_count = len(getattr(source_obj.data, "color_attributes", []))
    source_has_normals = _source_has_custom_normals(source_obj.data)
    if source_color_count or source_has_normals:
        requested_stages += 1

    try:
        _copy_material_slots(source_obj, target_obj)
        result["material_faces_mapped"] = _transfer_material_indices(transfer_map, target_obj)
        completed_stages += 1
    except Exception as exc:
        result["errors"].append(f"materials: {exc}")

    if source_obj.data.uv_layers:
        try:
            mapped, misses, _ = _transfer_uv_layers(
                source_obj,
                target_obj,
                islands_precision=islands_precision,
            )
            result["uv_layers"] = len(source_obj.data.uv_layers)
            result["uv_loops_mapped"] = mapped
            result["uv_misses"] = misses
            udim_preserved, source_tiles, target_tiles = _validate_udim_tiles(
                source_obj.data, target_obj.data
            )
            result["udim_preserved"] = udim_preserved
            result["udim_tiles"] = source_tiles
            result["udim_target_tiles"] = target_tiles
            if not udim_preserved:
                result["errors"].append("UDIM tile coverage changed during UV transfer")
            else:
                completed_stages += 1
        except Exception as exc:
            result["errors"].append(f"UVs: {exc}")

    if source_color_count or source_has_normals:
        try:
            shading_result = _transfer_shading_attributes(source_obj, target_obj)
            result.update(shading_result)
            if shading_result.get("shading_preserved", True):
                completed_stages += 1
            else:
                if not shading_result.get("color_attributes_preserved", True):
                    result["errors"].append("color attribute layers changed during transfer")
                if shading_result.get("custom_normals") and not shading_result.get("custom_normals_transferred"):
                    result["errors"].append("custom normals were not preserved")
        except Exception as exc:
            result["errors"].append(f"shading data: {exc}")

    if source_obj.vertex_groups:
        try:
            weight_result = _transfer_vertex_groups(source_obj, target_obj)
            result["vertex_groups"] = weight_result["groups"]
            result["weighted_groups"] = weight_result["weighted_groups"]
            result["weighted_vertices"] = weight_result["weighted_vertices"]
            result["weight_assignments"] = weight_result["assignments"]
            completed_stages += 1
        except Exception as exc:
            result["errors"].append(f"weights: {exc}")

    armature_valid, armature_bound, armature_modifiers, armature_error = (
        _validate_armature_relationship(source_obj, target_obj)
    )
    result["armature_bound"] = armature_bound
    result["armature_modifiers"] = armature_modifiers
    result["armature_preserved"] = armature_valid
    if armature_valid:
        completed_stages += 1
    else:
        result["errors"].append(f"rig: {armature_error}")

    target_obj.data.update()

    result["success"] = completed_stages == requested_stages
    result["partial"] = 0 < completed_stages < requested_stages
    if result["errors"]:
        result["error"] = "; ".join(result["errors"])

    return result