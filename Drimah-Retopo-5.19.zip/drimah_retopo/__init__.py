bl_info = {
    "name": "Drimah Retopo", "author": "Drimah", "version": (5, 19, 0),
    "blender": (5, 2, 0), "location": "View3D > Sidebar > Drimah Retopo",
    "description": "Conversao em quads e reconstrucao hibrida com validacao de bordas",
    "category": "Mesh"
}

import bpy
import math
import os
import platform
import shutil
import subprocess
import tempfile
import traceback
import datetime
from pathlib import Path
from bpy.props import BoolProperty, IntProperty, EnumProperty, PointerProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils.bvhtree import BVHTree
import bmesh

# Fast Remesher bundled as an optional integrated section; original DRIMAH tools preserved.
from . import fast_remesher as _fast_remesher

PRESET_DIVISORS = {'SUPER':1.25, 'HIGH':2.0, 'MEDHIGH':4.0, 'MEDIUM':8.0, 'MEDLOW':16.0, 'LOW':32.0}

class DRIMAHRETOPO_Properties(PropertyGroup):
    progress_percent: IntProperty(name='Progresso', default=0, min=0, max=100, options={'SKIP_SAVE'})
    progress_stage: IntProperty(name='Etapa', default=0, min=0, max=6, options={'SKIP_SAVE'})
    progress_status: bpy.props.StringProperty(name='Processamento', default='', options={'SKIP_SAVE'})
    progress_active: BoolProperty(name='Em andamento', default=False, options={'SKIP_SAVE'})
    quality: EnumProperty(name='Qualidade', items=[
        ('SUPER','Super','Maxima preservacao de forma'),
        ('HIGH','Alta','Mais detalhes'),
        ('MEDHIGH','Media Alta','Detalhada e mais leve'),
        ('MEDIUM','Media','Equilibrio'),
        ('MEDLOW','Media Baixa','Malha otimizada'),
        ('LOW','Baixa','Malha leve'),
        ('CUSTOM','Personalizada','Definir quantidade de quads')], default='MEDIUM')
    custom_faces: IntProperty(name='Faces desejadas', default=30000, min=500, soft_max=1000000)
    preserve_mesh_quads: BoolProperty(name='Preservar malha - 100% quads', description='Nao reduz nem reconstrói a forma: subdivide as faces originais em quads sem mover os vertices originais', default=False)
    preserve_original: BoolProperty(name='Preservar original', default=True)
    hard_edge_angle: IntProperty(name='Angulo hard edge', description='Angulo minimo entre faces para marcar aresta dura', default=35, min=1, max=179)
    hard_edge_subdivide: BoolProperty(name='Adicionar edges em planos grandes', description='Desativado nesta versao segura; nao adicionamos poligonos na Etapa 2', default=False)
    hard_edge_face_factor: IntProperty(name='Limite de tamanho (%)', description='Faces maiores que esta proporcao da aresta mediana serao candidatas', default=300, min=150, max=1000)
    hard_edge_keep_previous: BoolProperty(name='Manter Sharp existente', description='Preservar arestas Sharp que ja estao marcadas', default=True)
    normals_recalculate: BoolProperty(name='Corrigir normais de volumes fechados', description='Reorienta apenas componentes fechados; superficies abertas sao preservadas', default=True)
    normals_smooth: BoolProperty(name='Suavizar faces entre Hard Edges', description='Ativa Smooth nas faces; arestas Sharp preservam cantos definidos', default=True)
    quadriflow_faces: IntProperty(name='Meta de quads', description='Numero aproximado de quads desejados no QuadriFlow', default=4000, min=100, max=2000000)
    quadriflow_preserve_sharp: BoolProperty(name='Preservar arestas rigidas', default=False)
    quadriflow_preserve_boundary: BoolProperty(name='Preservar contornos', default=False)
    optimize_reduction: IntProperty(name='Reducao experimental (%)', default=50, min=5, max=95, description='Reducao alvo com Decimate; pode gerar triangulos')
    quad_join_angle: IntProperty(name='Angulo maximo entre triangulos', default=25, min=1, max=85, description='Limite para unir dois triangulos em um quad sem atravessar cantos duros')
    show_dependencies: BoolProperty(name='Dependencias e Motores', default=False, description='Expandir ou recolher diagnostico de dependencias')
    optimize_protect_sharp: BoolProperty(name='Proteger hard edges e contornos', default=True)
    optimize_keep_previous: BoolProperty(name='Manter malha anterior', default=True)
    pure_quads: BoolProperty(name='Somente quads', description='Reparar faces irregulares; se necessario, reconstruir quads de forma segura', default=True)
    primitive_guides: BoolProperty(name='Guias planas (experimental)', description='Usar regioes planas da malha original como primitivas de referencia; nao altera a topologia', default=False)
    reconstruction_engine: EnumProperty(name='Metodo', items=[('POINTS','Pontos e contornos','Reconstrucao conservadora do Drimah'),('QUADWILD','Digitalizacao de pontos + QuadWild','Analisa pontos e superficie e gera nova malha quadrangular')], default='POINTS')
    point_density: IntProperty(name='Densidade dos pontos (%)', default=45, min=10, max=100, description='Controla densidade da malha reconstruida a partir da analise geometrica')
    contour_relax: BoolProperty(name='Organizar fluxo perto de contornos', default=True, description='Redistribui pontos internos proximo de curvas e detalhes sem alterar conexoes')
    contour_strength: IntProperty(name='Intensidade (%)', default=18, min=0, max=35)
    preserve_geometry: BoolProperty(name='Preservar geometria (experimental)', description='Projetar vertices para o original com limites locais e registrar desvios de superficie', default=True)

def target_for(p, obj=None):
    if p.quality == 'CUSTOM':
        return p.custom_faces
    faces = 240000
    if obj and obj.type == 'MESH':
        # Conta a geometria avaliada, incluindo Mirror e outros modificadores.
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh()
        try:
            faces = len(mesh.polygons)
        finally:
            evaluated.to_mesh_clear()
    return max(500, int(round(faces / PRESET_DIVISORS[p.quality])))

def activate_only(context, obj):
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj

def qstats(obj):
    total = len(obj.data.polygons)
    quads = sum(1 for p in obj.data.polygons if len(p.vertices) == 4)
    tris = sum(1 for p in obj.data.polygons if len(p.vertices) == 3)
    return total, quads, tris, (quads / total if total else 0.0)

def repair_local_quads(obj):
    """Une pares de triangulos e triangula n-gons somente nas regioes afetadas.

    Preserva todos os quads existentes; se sobraram triangulos isolados,
    o conversor global seguro pode ser acionado pelo chamador.
    """
    mesh = obj.data
    if all(len(f.vertices) == 4 for f in mesh.polygons):
        return 0
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bm.faces.ensure_lookup_table()
        ngons = [f for f in bm.faces if len(f.verts) > 4]
        if ngons:
            bmesh.ops.triangulate(bm, faces=ngons, quad_method='BEAUTY', ngon_method='BEAUTY')
        triangles = [f for f in bm.faces if len(f.verts) == 3]
        if triangles:
            bmesh.ops.join_triangles(
                bm, faces=triangles, angle_face_threshold=math.radians(35),
                angle_shape_threshold=math.pi, cmp_seam=True, cmp_sharp=True,
                cmp_materials=True, cmp_uvs=False,
            )
        remaining = sum(len(f.verts) != 4 for f in bm.faces)
        if remaining == 0:
            bm.to_mesh(mesh)
            mesh.update()
        return remaining
    finally:
        bm.free()


def enforce_pure_quads(obj):
    """Topology-safe all-quad conversion using a face-edge-vertex dual split.

    Every original face corner becomes one quad. Shared edge midpoints are
    reused, so there are no T-junctions or disconnected seams. Original
    vertices remain unchanged. This is deliberately a conservative fallback
    used only when the remesher leaves non-quad faces.
    """
    mesh = obj.data
    bad = sum(len(face.vertices) != 4 for face in mesh.polygons)
    if not bad:
        return 0
    from mathutils import Vector
    original_vertices = [v.co.copy() for v in mesh.vertices]
    points = list(original_vertices)
    edge_midpoints = {}
    face_centers = []
    for face in mesh.polygons:
        corners = list(face.vertices)
        center = sum((original_vertices[i] for i in corners), Vector((0, 0, 0))) / len(corners)
        face_centers.append(len(points))
        points.append(center)
    quads = []
    for fi, face in enumerate(mesh.polygons):
        corners = list(face.vertices)
        n = len(corners)
        if n < 3:
            raise RuntimeError('Face degenerada durante conversao para quads')
        mids = []
        for i in range(n):
            a, b = corners[i], corners[(i + 1) % n]
            edge = (min(a, b), max(a, b))
            if edge not in edge_midpoints:
                edge_midpoints[edge] = len(points)
                points.append((original_vertices[a] + original_vertices[b]) * 0.5)
            mids.append(edge_midpoints[edge])
        for i in range(n):
            quads.append((corners[i], mids[i], face_centers[fi], mids[i - 1]))
    new_mesh = bpy.data.meshes.new(mesh.name + '_quads')
    new_mesh.from_pydata(points, [], quads)
    new_mesh.update(calc_edges=True)
    if len(new_mesh.polygons) != len(quads) or any(len(f.vertices) != 4 for f in new_mesh.polygons):
        bpy.data.meshes.remove(new_mesh)
        raise RuntimeError('Conversao para quads nao passou na validacao')
    obj.data = new_mesh
    if mesh.users == 0:
        bpy.data.meshes.remove(mesh)
    return bad


def engine_command():
    root = Path(__file__).resolve().parent
    system = platform.system().lower()
    if system == 'linux':
        exe = root / 'bin' / 'linux' / 'autoremesher-1.2.0.AppImage'
        if not exe.exists():
            raise RuntimeError('Motor Linux integrado nao encontrado')
        try:
            exe.chmod(exe.stat().st_mode | 0o111)
        except Exception:
            pass
        return exe
    if system == 'windows':
        exe = root / 'bin' / 'windows' / 'autoremesher.exe'
        if not exe.exists():
            raise RuntimeError('Motor Windows integrado nao encontrado')
        return exe
    raise RuntimeError('Drimah Retopo suporta Windows e Linux')

def export_obj(filepath, obj, context):
    activate_only(context, obj)
    # Blender 4/5 OBJ exporter. Exporta apenas a copia de trabalho.
    result = bpy.ops.wm.obj_export(
        filepath=str(filepath),
        export_selected_objects=True,
        apply_modifiers=True,
        export_materials=False,
        export_uv=False,
        export_normals=True,
        export_triangulated_mesh=False,
        forward_axis='Y',
        up_axis='Z',
    )
    if 'FINISHED' not in result:
        raise RuntimeError('Exportacao temporaria OBJ nao concluiu')

def import_obj(filepath, context):
    before = set(bpy.data.objects)
    result = bpy.ops.wm.obj_import(
        filepath=str(filepath),
        forward_axis='Y',
        up_axis='Z',
    )
    if 'FINISHED' not in result:
        raise RuntimeError('Importacao do resultado OBJ nao concluiu')
    created = [o for o in bpy.data.objects if o not in before and o.type == 'MESH']
    if not created:
        raise RuntimeError('Motor nao retornou uma malha OBJ valida')
    # Normalmente ha um objeto. Se houver varios, une automaticamente.
    if len(created) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for o in created: o.select_set(True)
        context.view_layer.objects.active = created[0]
        bpy.ops.object.join()
        return context.active_object
    return created[0]

def run_autoremesher(input_obj, output_obj, report_file, engine_target):
    exe = engine_command()
    cmd = [
        str(exe),
        '--input', str(input_obj),
        '--output', str(output_obj),
        '--report', str(report_file),
        '--target-quads', str(int(engine_target)),
        '--edge-scaling', '1.0',
        '--sharp-edge', '45.0',
        '--smooth-normal', '0.0',
        '--adaptivity', '1.0',
        '--anisotropy', '1.0',
    ]
    env = os.environ.copy()
    # Permite AppImage em distribuicoes sem libfuse2. Em desktop, DISPLAY e herdado do Blender.
    if platform.system().lower() == 'linux':
        env['APPIMAGE_EXTRACT_AND_RUN'] = '1'
    if platform.system().lower() == 'windows':
        env.setdefault('QT_OPENGL', 'software')
        env.setdefault('QT_QPA_PLATFORM', 'offscreen')
    proc = subprocess.run(
        cmd,
        cwd=str(exe.parent),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        errors='replace',
        timeout=60*60,
        creationflags=(subprocess.CREATE_NO_WINDOW if platform.system().lower() == 'windows' else 0),
    )
    if proc.returncode != 0:
        tail = (proc.stdout or '')[-1200:].replace('\n', ' ')
        raise RuntimeError('AutoRemesher falhou: ' + tail[:900])
    if not output_obj.exists() or output_obj.stat().st_size < 100:
        raise RuntimeError('AutoRemesher nao gerou o OBJ de saida')
    return proc.stdout or ''

def refine_on_original(result_obj, source, context):
    """Conservative projection to evaluated source, without mesh relaxation.

    The source BVH is built in source-local coordinates. Source sharp edges are
    sampled independently, and projection distance is bounded by both overall
    scale and local edge length to reduce jumps between nearby components.
    """
    from mathutils.kdtree import KDTree
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = source.evaluated_get(depsgraph)
    src = evaluated.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
    try:
        if src is None or not src.polygons or not result_obj.data.vertices:
            return 0
        src_verts = [v.co.copy() for v in src.vertices]
        tree = BVHTree.FromPolygons(src_verts,
                                    [tuple(p.vertices) for p in src.polygons],
                                    all_triangles=False)
        mesh = result_obj.data
        transform = source.matrix_world.inverted_safe() @ result_obj.matrix_world
        inverse = transform.inverted_safe()
        bounds_min = [min(v[i] for v in src_verts) for i in range(3)]
        bounds_max = [max(v[i] for v in src_verts) for i in range(3)]
        diagonal = sum((bounds_max[i]-bounds_min[i])**2 for i in range(3))**0.5
        if diagonal <= 1e-10:
            return 0
        edge_faces = [[] for _ in mesh.edges]
        neighbors = [set() for _ in mesh.vertices]
        for p in mesh.polygons:
            for li in p.loop_indices:
                edge_faces[mesh.loops[li].edge_index].append(p.index)
        protected = set()
        for e in mesh.edges:
            a,b=e.vertices
            neighbors[a].add(b);neighbors[b].add(a)
            faces=edge_faces[e.index]
            if len(faces)!=2 or getattr(e,'use_edge_sharp',False):
                protected.update((a,b))
            elif mesh.polygons[faces[0]].normal.angle(mesh.polygons[faces[1]].normal,0.0) >= math.radians(30):
                protected.update((a,b))
        src_edge_faces=[[] for _ in src.edges]
        for p in src.polygons:
            for li in p.loop_indices:
                src_edge_faces[src.loops[li].edge_index].append(p.index)
        features=[]
        for e in src.edges:
            faces=src_edge_faces[e.index]
            sharp=len(faces)!=2 or getattr(e,'use_edge_sharp',False)
            if len(faces)==2 and not sharp:
                sharp=src.polygons[faces[0]].normal.angle(src.polygons[faces[1]].normal,0.0)>=math.radians(30)
            if sharp:
                a,b=e.vertices
                features.append((src_verts[a],src_verts[b]))
        kd=None
        if features:
            kd=KDTree(len(features)*3)
            for idx,(a,b) in enumerate(features):
                kd.insert(a,idx);kd.insert(b,idx);kd.insert((a+b)*0.5,idx)
            kd.balance()
        originals=[v.co.copy() for v in mesh.vertices]
        pending={}
        changed=0
        # First, fit feature vertices onto nearby original creases, but do not
        # move a vertex far enough to cross a neighboring part.
        for v in mesh.vertices:
            i=v.index
            co=originals[i]
            pt=transform @ co
            edge_lengths=sorted((transform.to_3x3() @ (originals[j]-co)).length for j in neighbors[i])
            if not edge_lengths:
                continue
            local=edge_lengths[len(edge_lengths)//2]
            if local<=1e-10:
                continue
            limit=min(diagonal*0.015,local*0.65)
            if kd is not None:
                _,idx,_=kd.find(pt)
                a,b=features[idx]
                ab=b-a
                t=max(0.0,min(1.0,(pt-a).dot(ab)/max(ab.length_squared,1e-20)))
                foot=a+ab*t
                delta=foot-pt
                # Snap only if the source feature is close enough and the
                # destination vertex already lies near a generated crease.
                if i in protected and delta.length <= limit:
                    pending[i]=inverse @ foot
                    continue
            hit=tree.find_nearest(pt,limit)
            if hit is None or hit[0] is None or hit[1] is None:
                continue
            hp,normal,_,dist=hit
            rn=transform.to_3x3() @ v.normal
            if rn.length_squared > 1e-14 and abs(rn.normalized().dot(normal.normalized()))<0.80:
                continue
            # Open edges and creases stay put unless snapped to an original
            # crease above. No tangential relaxation is performed.
            if i in protected:
                continue
            pending[i]=inverse @ hp
        for i,dest in pending.items():
            old=mesh.vertices[i].co.copy()
            if (dest-old).length < 1e-10:
                continue
            mesh.vertices[i].co=dest
            changed+=1
        if changed:
            mesh.update()
        result_obj['drimah_retopo_projection_candidates']=len(pending)
        result_obj['drimah_retopo_source_sharp_edges']=len(features)
        return changed
    finally:
        evaluated.to_mesh_clear()


def guide_by_source_planes(result_obj, source, context):
    """Optional plane-primitive fitting on broad, flat source regions.

    Only project vertices with compatible surface normals, away from sharp
    borders. This does not generate new topology or claim cylinder fitting.
    """
    from mathutils import Vector
    dg = context.evaluated_depsgraph_get()
    evaluated = source.evaluated_get(dg)
    src = evaluated.to_mesh(preserve_all_data_layers=False, depsgraph=dg)
    try:
        if not src or not src.polygons:
            return 0
        vertices = [v.co.copy() for v in src.vertices]
        faces = [tuple(p.vertices) for p in src.polygons]
        tree = BVHTree.FromPolygons(vertices, faces, all_triangles=False)
        edge_polys = [[] for _ in src.edges]
        for p in src.polygons:
            for li in p.loop_indices:
                edge_polys[src.loops[li].edge_index].append(p.index)
        # Interior of a planar patch: every edge borders a similarly oriented face.
        planar = set()
        for p in src.polygons:
            if p.area <= 1e-12:
                continue
            ok = True
            for li in p.loop_indices:
                adj = edge_polys[src.loops[li].edge_index]
                if len(adj) != 2 or p.normal.dot(src.polygons[adj[0] if adj[1] == p.index else adj[1]].normal) < 0.985:
                    ok = False
                    break
            if ok:
                planar.add(p.index)
        if not planar:
            return 0
        transform = source.matrix_world.inverted_safe() @ result_obj.matrix_world
        inverse = transform.inverted_safe()
        lo = [min(v[i] for v in vertices) for i in range(3)]
        hi = [max(v[i] for v in vertices) for i in range(3)]
        diagonal = sum((hi[i]-lo[i])**2 for i in range(3))**0.5
        limit = max(diagonal * 0.002, 1e-7)
        out = result_obj.data
        changed = 0
        for v in out.vertices:
            pt = transform @ v.co
            hit = tree.find_nearest(pt, limit)
            if hit is None or hit[0] is None or hit[2] not in planar:
                continue
            hp, normal, face_index, distance = hit
            plane = src.polygons[face_index]
            normal = plane.normal
            rn = transform.to_3x3() @ v.normal
            if rn.length_squared < 1e-12 or abs(rn.normalized().dot(normal)) < 0.92:
                continue
            # The fitted primitive is the source polygon's local plane.
            projected = pt - normal * (pt - vertices[plane.vertices[0]]).dot(normal)
            shift = (inverse @ projected) - v.co
            if shift.length <= limit:
                v.co += shift * 0.85
                changed += 1
        if changed:
            out.update()
        return changed
    finally:
        evaluated.to_mesh_clear()


def convert_original_to_quads(source, context):
    """Quadrangulate every polygon in evaluated mesh without changing original points.

    Shared edge midpoints prevent T-junctions. Each face produces one quad
    per corner, with its face center as the fourth vertex. This is a topology
    conversion, not a topology-flow optimizer.
    """
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = source.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
    try:
        if not mesh or not mesh.polygons:
            raise RuntimeError('Objeto sem faces para converter')
        # Avoid excessive memory usage on very large meshes.
        if len(mesh.loops) > 3_000_000:
            raise RuntimeError('Malha grande demais para conversao direta (mais de 3 milhoes de cantos)')
        points = [tuple(v.co) for v in mesh.vertices]
        midpoint = {}
        for edge in mesh.edges:
            a, b = edge.vertices
            midpoint[edge.index] = len(points)
            points.append(tuple((mesh.vertices[a].co + mesh.vertices[b].co) * 0.5))
        centers = {}
        for poly in mesh.polygons:
            centers[poly.index] = len(points)
            points.append(tuple(poly.center))
        faces = []
        materials = []
        smooth = []
        # Each original corner becomes a quad with shared edge midpoints.
        for poly in mesh.polygons:
            loops = list(poly.loop_indices)
            n = len(loops)
            if n < 3:
                continue
            for j, li in enumerate(loops):
                prev_li = loops[(j-1) % n]
                v = mesh.loops[li].vertex_index
                next_mid = midpoint[mesh.loops[li].edge_index]
                prev_mid = midpoint[mesh.loops[prev_li].edge_index]
                faces.append((v, next_mid, centers[poly.index], prev_mid))
                materials.append(poly.material_index)
                smooth.append(poly.use_smooth)
        output = bpy.data.meshes.new(source.name + '_DRIMAH_QUADS_MESH')
        output.from_pydata(points, [], faces)
        output.update(calc_edges=True)
        for material in mesh.materials:
            output.materials.append(material)
        for i, poly in enumerate(output.polygons):
            poly.material_index = materials[i] if materials[i] < len(output.materials) else 0
            poly.use_smooth = smooth[i]
        # Metadados para reconstruir grupos originais sem alterar a malha.
        parent_attr = output.attributes.new('drimah_parent_face', 'INT', 'FACE')
        corner_attr = output.attributes.new('drimah_corner', 'INT', 'FACE')
        srcsize_attr = output.attributes.new('drimah_parent_sides', 'INT', 'FACE')
        fi = 0
        for original_poly in mesh.polygons:
            for corner in range(len(original_poly.vertices)):
                parent_attr.data[fi].value = original_poly.index
                corner_attr.data[fi].value = corner
                srcsize_attr.data[fi].value = len(original_poly.vertices)
                fi += 1
        # Keep hard-edge shading: original crease segments retain sharp flags.
        src_sharp = mesh.attributes.get('sharp_edge')
        sharp_segments = set()
        adjacent = [[] for _ in mesh.edges]
        for poly in mesh.polygons:
            for li in poly.loop_indices:
                adjacent[mesh.loops[li].edge_index].append(poly.index)
        for edge in mesh.edges:
            neighbors = adjacent[edge.index]
            is_sharp = len(neighbors) != 2
            if src_sharp is not None and src_sharp.domain == 'EDGE':
                is_sharp |= bool(src_sharp.data[edge.index].value)
            if len(neighbors) == 2:
                p, q = (mesh.polygons[n] for n in neighbors)
                is_sharp |= p.normal.dot(q.normal) < 0.8660254
            if is_sharp:
                a,b = edge.vertices
                m = midpoint[edge.index]
                sharp_segments.add(tuple(sorted((a,m))))
                sharp_segments.add(tuple(sorted((m,b))))
        if sharp_segments:
            attr = output.attributes.get('sharp_edge')
            if attr is None:
                attr = output.attributes.new('sharp_edge', 'BOOLEAN', 'EDGE')
            for edge in output.edges:
                if tuple(sorted(edge.vertices)) in sharp_segments:
                    attr.data[edge.index].value = True
        # Preserve the UV mapping of each polygon via bilinear corner sampling.
        for src_uv in mesh.uv_layers:
            dst_uv = output.uv_layers.new(name=src_uv.name)
            offset = 0
            for poly in mesh.polygons:
                loops = list(poly.loop_indices)
                n = len(loops)
                if n < 3: continue
                uv = [src_uv.data[li].uv.copy() for li in loops]
                center_uv = sum(uv, uv[0].copy()*0.0) / n
                for j in range(n):
                    a = uv[j]
                    b = uv[(j+1)%n]
                    prev = uv[(j-1)%n]
                    for uv_value in (a, (a+b)*0.5, center_uv, (prev+a)*0.5):
                        dst_uv.data[offset].uv = uv_value
                        offset += 1
        result = bpy.data.objects.new(source.name + '_DRIMAH_QUADS', output)
        context.collection.objects.link(result)
        result.matrix_world = source.matrix_world.copy()
        result['drimah_retopo_mode'] = 'Preservar malha - 100% quads'
        result['drimah_retopo_original_faces'] = len(mesh.polygons)
        result['drimah_retopo_actual_quads'] = len(faces)
        result['drimah_retopo_quad_ratio'] = 1.0
        result['drimah_retopo_version'] = '3.1'
        return result
    finally:
        evaluated.to_mesh_clear()

class DRIMAHRETOPO_OT_AutoQuad(Operator):
    bl_idname = 'object.drimah_retopo_auto_quad'
    bl_label = 'Retopologia em Quads'
    bl_description = 'Cria uma nova topologia quadrangular automaticamente'
    bl_options = {'REGISTER','UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.active_object and context.active_object.type == 'MESH'

    def execute(self, context):
        source = context.active_object
        p = context.scene.drimah_retopo
        if p.preserve_mesh_quads:
            result = None
            try:
                result = convert_original_to_quads(source, context)
                if not p.preserve_original:
                    bpy.data.objects.remove(source, do_unlink=True)
                activate_only(context, result)
                self.report({'INFO'}, f"Malha preservada: {len(result.data.polygons):,} quads; sem AutoRemesher")
                return {'FINISHED'}
            except Exception as exc:
                if result and result.name in bpy.data.objects:
                    bpy.data.objects.remove(result, do_unlink=True)
                self.report({'ERROR'}, f'Conversao para quads: {str(exc)[:180]}')
                traceback.print_exc()
                return {'CANCELLED'}

        # O pacote nao inclui o binario do AutoRemesher em todas as distribuicoes.
        # Nessa situacao, usa motores que ja acompanham o add-on/Blender, sem
        # falhar antes de tentar produzir uma retopologia real.
        try:
            engine_command()
        except Exception as missing_engine:
            fallback_errors = []
            try:
                qw_result = bpy.ops.object.drimah_retopo_quadwild_test('EXEC_DEFAULT')
                if 'FINISHED' in qw_result:
                    generated = context.view_layer.objects.active
                    if generated and generated.type == 'MESH':
                        generated['drimah_retopo_auto_fallback'] = 'QRemeshify / QuadWild'
                    self.report({'INFO'}, 'AutoRemesher indisponivel; retopologia concluida com QuadWild')
                    return {'FINISHED'}
                fallback_errors.append('QuadWild nao concluiu')
            except Exception as exc:
                fallback_errors.append('QuadWild: ' + str(exc)[:120])

            if hasattr(bpy.ops.object, 'quadriflow_remesh'):
                self.report({'INFO'}, 'AutoRemesher e QuadWild indisponiveis; tentando QuadriFlow do Blender')
                return bpy.ops.object.drimah_retopo_quadriflow_status('INVOKE_DEFAULT')

            details = '; '.join(fallback_errors)
            raise RuntimeError('AutoRemesher nao esta no pacote e nenhum motor alternativo concluiu. '
                               + details + '; ' + str(missing_engine)[:120])

        target = target_for(p, source)
        engine_target = target  # Sem reducao artificial: preservar detalhes e hard edges
        work = None
        result_obj = None
        stage = 'Inicio'
        temp_dir = None
        try:
            stage = 'Preparacao'
            # Copia independente: o original nunca e enviado diretamente para alteracao.
            work = source.copy()
            work.data = source.data.copy()
            context.collection.objects.link(work)
            work.name = source.name + '_DRIMAH_SOURCE'
            activate_only(context, work)
            # Processa em coordenadas locais: o resultado recebe a matriz exata do original.
            # Isso evita rotacao/escala duplicadas e mantem o Mirror avaliado na exportacao.
            work.matrix_world.identity()

            # Limpeza minima, sem voxel/smooth/decimate: preserva silhueta e hard edges para o motor de campos.
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            try:
                bpy.ops.mesh.remove_doubles(threshold=1e-7)
            except Exception:
                pass
            bpy.ops.object.mode_set(mode='OBJECT')

            stage = 'Motor de quads'
            temp_dir = Path(tempfile.mkdtemp(prefix='drimah_retopo_'))
            input_obj = temp_dir / 'source.obj'
            output_obj = temp_dir / 'retopo.obj'
            report_file = temp_dir / 'report.txt'
            export_obj(input_obj, work, context)
            run_autoremesher(input_obj, output_obj, report_file, engine_target)

            stage = 'Importacao'
            result_obj = import_obj(output_obj, context)
            result_obj.name = source.name + '_DRIMAH_RETOPO'

            # A copia exportada recebeu transformacoes aplicadas. Mantem localizacao do original.
            # OBJ export/import preserva as coordenadas da copia; copia a matriz para consistencia.
            result_obj.matrix_world = source.matrix_world.copy()

            stage = 'Refinamento'
            refined_count = refine_on_original(result_obj, source, context) if p.preserve_geometry else 0
            result_obj['drimah_retopo_refined_vertices'] = refined_count
            if p.primitive_guides:
                stage = 'Guias de primitivas planas'
                result_obj['drimah_retopo_plane_guided_vertices'] = guide_by_source_planes(
                    result_obj, source, context)


            stage = 'Correcao de quads'
            corrected = 0
            remaining = 0
            if p.pure_quads:
                remaining = repair_local_quads(result_obj)
                if remaining:
                    corrected = enforce_pure_quads(result_obj)
            result_obj['drimah_retopo_nonquad_faces_corrected'] = corrected
            result_obj['drimah_retopo_global_quad_fallback'] = bool(remaining)
            # Arestas ja refinadas antes da conversao: nao suavizar duas vezes.

            stage = 'Validacao'
            total, quads, tris, qr = qstats(result_obj)
            if total == 0:
                raise RuntimeError('Resultado vazio')
            # Verifica se o motor preservou aproximadamente o volume espacial.
            # Uma saida muito menor que a entrada indica perda grave de componentes.
            # Compara OBJ de entrada e saida no MESMO sistema de coordenadas.
            # source.dimensions pode ignorar Mirror e misturar eixos locais/mundo,
            # causando falsos erros (especialmente no eixo Z).
            def obj_bounds(path):
                lo = [float('inf')] * 3
                hi = [float('-inf')] * 3
                count = 0
                with open(path, 'r', encoding='utf-8', errors='replace') as fh:
                    for line in fh:
                        if not line.startswith('v '):
                            continue
                        parts = line.split()
                        if len(parts) < 4:
                            continue
                        try:
                            coords = [float(parts[i]) for i in (1, 2, 3)]
                        except ValueError:
                            continue
                        count += 1
                        for i in range(3):
                            lo[i] = min(lo[i], coords[i])
                            hi[i] = max(hi[i], coords[i])
                if not count:
                    raise RuntimeError('OBJ sem vertices: ' + path.name)
                return [hi[i] - lo[i] for i in range(3)]

            input_dims = obj_bounds(input_obj)
            output_dims = obj_bounds(output_obj)
            input_diag = sum(v*v for v in input_dims) ** 0.5
            output_diag = sum(v*v for v in output_dims) ** 0.5
            # Apenas um colapso global extremo justifica abortar automaticamente.
            # Reducoes em eixos isolados sao registradas, nao rejeitadas.
            if input_diag > 1e-8 and output_diag < input_diag * 0.20:
                raise RuntimeError('Resultado incompleto: dimensao global muito reduzida')
            result_obj['drimah_retopo_input_dimensions'] = tuple(input_dims)
            result_obj['drimah_retopo_output_dimensions'] = tuple(output_dims)
            if p.pure_quads and qr != 1.0:
                raise RuntimeError('Falha na verificacao de 100% quads')
            if qr < 0.5:
                raise RuntimeError('Resultado invalido: menos de 50% das faces sao quads')
            result_obj['drimah_retopo_version'] = '3.0.0'
            result_obj['drimah_retopo_engine'] = 'AutoRemesher 1.2.0 integrado'
            result_obj['drimah_retopo_target_quads'] = target
            result_obj['drimah_retopo_engine_target_quads'] = engine_target
            result_obj['drimah_retopo_actual_quads'] = quads
            result_obj['drimah_retopo_target_ratio'] = round(quads / target, 4) if target else 0.0
            result_obj['drimah_retopo_quality'] = p.quality
            result_obj['drimah_retopo_primitive_guides'] = bool(p.primitive_guides)
            result_obj['drimah_retopo_preserve_geometry'] = bool(p.preserve_geometry)
            result_obj['drimah_retopo_quad_ratio'] = qr
            result_obj['drimah_retopo_triangles'] = tris

            # Remove apenas a copia temporaria do Blender.
            if work and work.name in bpy.data.objects:
                bpy.data.objects.remove(work, do_unlink=True)
                work = None

            if not p.preserve_original and source and source.name in bpy.data.objects:
                bpy.data.objects.remove(source, do_unlink=True)

            activate_only(context, result_obj)
            if qr < 0.80:
                result_obj['drimah_retopo_validation'] = 'REVISAR'
                self.report({'WARNING'}, f'Retopologia: {quads:,} quads (meta {target:,}), {qr*100:.1f}% quads')
            else:
                result_obj['drimah_retopo_validation'] = 'OK'
                self.report({'INFO'}, f'Concluido: {quads:,} quads (meta {target:,}), {qr*100:.1f}% quads')
            return {'FINISHED'}

        except subprocess.TimeoutExpired:
            if result_obj and result_obj.name in bpy.data.objects:
                bpy.data.objects.remove(result_obj, do_unlink=True)
            result_obj = None
            self.report({'ERROR'}, 'Falha em [Motor de quads]: tempo limite de 60 minutos')
            return {'CANCELLED'}
        except Exception as e:
            if result_obj and result_obj.name in bpy.data.objects:
                bpy.data.objects.remove(result_obj, do_unlink=True)
            result_obj = None
            print('DRIMAH RETOPO 1.9 - Falha em', stage, ':', e)
            traceback.print_exc()
            self.report({'ERROR'}, f'Falha em [{stage}]: {str(e)[:210]}')
            return {'CANCELLED'}
        finally:
            if work and work.name in bpy.data.objects:
                try: bpy.data.objects.remove(work, do_unlink=True)
                except Exception: pass
            if temp_dir:
                try: shutil.rmtree(temp_dir, ignore_errors=True)
                except Exception: pass
            if result_obj and result_obj.name in bpy.data.objects and stage == 'Validacao':
                try: activate_only(context, result_obj)
                except Exception: pass
            elif source and source.name in bpy.data.objects:
                try: activate_only(context, source)
                except Exception: pass

class DRIMAHRETOPO_OT_ConvertQuads(Operator):
    bl_idname = 'object.drimah_retopo_convert_quads'
    bl_label = '1. Converter para Quads'
    bl_description = 'Converte a geometria original em quads sem mover vertices nem reduzir a malha'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        source = context.active_object
        result = None
        try:
            result = convert_original_to_quads(source, context)
            result['drimah_retopo_version'] = '4.4'
            result['drimah_source_object'] = source.name
            result['drimah_source_vertices'] = len(source.data.vertices)
            if not context.scene.drimah_retopo.preserve_original:
                bpy.data.objects.remove(source, do_unlink=True)
            activate_only(context, result)
            self.report({'INFO'}, f'Etapa 1: {len(result.data.polygons):,} quads; geometria preservada')
            return {'FINISHED'}
        except Exception as exc:
            if result is not None and result.name in bpy.data.objects:
                bpy.data.objects.remove(result, do_unlink=True)
            traceback.print_exc()
            self.report({'ERROR'}, f'Etapa 1: {str(exc)[:180]}')
            return {'CANCELLED'}


class DRIMAHRETOPO_OT_HardEdges(Operator):
    bl_idname = 'object.drimah_retopo_hard_edges'
    bl_label = '2. Corrigir Normais e Hard Edges'
    bl_description = 'Corrige orientacao de volumes fechados e sombreamento sem alterar a topologia'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        p = context.scene.drimah_retopo
        try:
            if obj.data.users > 1:
                obj.data = obj.data.copy()
            mesh = obj.data
            before = (len(mesh.vertices), len(mesh.edges), len(mesh.polygons))
            sharp_attr = mesh.attributes.get('sharp_edge')
            if sharp_attr is not None and (sharp_attr.domain != 'EDGE' or sharp_attr.data_type != 'BOOLEAN'):
                raise ValueError('Atributo sharp_edge incompativel')
            prior_sharp = set()
            if sharp_attr is not None and p.hard_edge_keep_previous:
                prior_sharp = {tuple(sorted(edge.vertices)) for edge in mesh.edges if sharp_attr.data[edge.index].value}

            # Trabalha em BMesh: normais e conectividade reais, sem criar ou apagar faces.
            bm = bmesh.new()
            try:
                bm.from_mesh(mesh)
                bm.faces.ensure_lookup_table()
                bm.edges.ensure_lookup_table()
                for face in bm.faces:
                    face.normal_update()
                visited = set()
                closed_parts = 0
                open_parts = 0
                flipped_parts = 0
                corrected_faces = 0
                if p.normals_recalculate:
                    for first in bm.faces:
                        if first in visited:
                            continue
                        stack = [first]
                        component = []
                        visited.add(first)
                        while stack:
                            face = stack.pop()
                            component.append(face)
                            for edge in face.edges:
                                for other in edge.link_faces:
                                    if other not in visited:
                                        visited.add(other)
                                        stack.append(other)
                        comp_set = set(component)
                        # Apenas shells fechados e manifold sao orientados automaticamente.
                        comp_edges = {edge for face in component for edge in face.edges}
                        closed = all(len(edge.link_faces) == 2 and all(f in comp_set for f in edge.link_faces) for edge in comp_edges)
                        if not closed:
                            open_parts += 1
                            continue
                        closed_parts += 1
                        old_normals = {face: face.normal.copy() for face in component}
                        bmesh.ops.recalc_face_normals(bm, faces=component)
                        volume6 = 0.0
                        for face in component:
                            verts = [v.co for v in face.verts]
                            for i in range(1, len(verts)-1):
                                volume6 += verts[0].dot(verts[i].cross(verts[i+1]))
                        if volume6 < -1e-10:
                            bmesh.ops.reverse_faces(bm, faces=component)
                            flipped_parts += 1
                        corrected_faces += sum(1 for face in component if old_normals[face].dot(face.normal) < 0.999)
                threshold = math.cos(math.radians(p.hard_edge_angle))
                marked = 0
                for edge in bm.edges:
                    edge_key = tuple(sorted(v.index for v in edge.verts))
                    is_sharp = len(edge.link_faces) != 2
                    if len(edge.link_faces) == 2:
                        f1, f2 = edge.link_faces
                        is_sharp = f1.normal.dot(f2.normal) < threshold
                    if edge_key in prior_sharp:
                        is_sharp = True
                    edge.smooth = not is_sharp
                    marked += bool(is_sharp)
                if p.normals_smooth:
                    for face in bm.faces:
                        face.smooth = True
                # Com a opcao desligada, mantem exatamente o smooth/flat existente.
                bm.to_mesh(mesh)
            finally:
                bm.free()
            mesh.update()
            after = (len(mesh.vertices), len(mesh.edges), len(mesh.polygons))
            if before != after:
                raise RuntimeError('A Etapa 2 alterou a quantidade de elementos da malha')
            obj['drimah_retopo_hard_edges'] = marked
            obj['drimah_retopo_hard_edges_version'] = '3.6'
            obj['drimah_retopo_normals_closed'] = closed_parts
            obj['drimah_retopo_normals_open_skipped'] = open_parts
            self.report({'INFO'}, f'Etapa 2: {marked} Sharp, {corrected_faces} normais ajustadas, {closed_parts} fechados ({flipped_parts} invertidos), {open_parts} abertos preservados; {before[2]} faces')
            return {'FINISHED'}
        except Exception as exc:
            traceback.print_exc()
            self.report({'ERROR'}, f'Etapa 2: {str(exc)[:180]}')
            return {'CANCELLED'}


def _mesh_signature(mesh):
    """Geometric invariant: vertex positions, outer border, area and bounding box."""
    verts = sorted(tuple(round(float(c), 6) for c in v.co) for v in mesh.vertices)
    borders = {}
    for face in mesh.polygons:
        for li in face.loop_indices:
            ei = mesh.loops[li].edge_index
            borders[ei] = borders.get(ei, 0) + 1
    outline = sorted(tuple(sorted((tuple(round(float(c), 6) for c in mesh.vertices[v].co) for v in edge.vertices))) for edge in mesh.edges if borders.get(edge.index, 0) == 1)
    return verts, outline, sum(face.area for face in mesh.polygons)


def _safe_reduce(mesh, percent, protect):
    """Try only full quad-preserving planar dissolves; rollback if any invariant fails."""
    before = len(mesh.polygons)
    if before < 8 or any(len(f.vertices) != 4 for f in mesh.polygons):
        return 0
    source_positions, source_border, source_area = _mesh_signature(mesh)
    original = bmesh.new()
    original.from_mesh(mesh)
    original.normal_update()
    accepted = 0
    goal = max(1, int(before * percent / 100))
    try:
        # A two-edge dissolve is only accepted if every face stays a quad.
        # This conservative approach may find no valid operation, by design.
        trials = 0
        while accepted < goal and trials < 120:
            original.edges.ensure_lookup_table()
            original.edges.index_update()
            candidate_indices = []
            for e in original.edges:
                if len(e.link_faces) != 2 or any(len(f.verts) != 4 for f in e.link_faces):
                    continue
                if e.calc_face_angle(0.0) > math.radians(1):
                    continue
                if protect and (not e.smooth or e.seam):
                    continue
                candidate_indices.append(e.index)
            changed = False
            for idx in candidate_indices[:120]:
                trials += 1
                if trials > 120: break
                trial = original.copy()
                try:
                    trial.edges.ensure_lookup_table()
                    edge = trial.edges[idx]
                    bmesh.ops.dissolve_edges(trial, edges=[edge], use_verts=True, use_face_split=False)
                    trial.normal_update()
                    if len(trial.faces) >= len(original.faces):
                        continue
                    if any(len(f.verts) != 4 or f.calc_area() < 1e-12 for f in trial.faces):
                        continue
                    tmp = bpy.data.meshes.new('Drimah_Validation_Temp')
                    try:
                        trial.to_mesh(tmp)
                        coords, border, area = _mesh_signature(tmp)
                        if border != source_border or abs(area-source_area) > max(1e-5, source_area * 1e-5):
                            continue
                        if not set(coords).issubset(set(source_positions)):
                            continue
                    finally:
                        bpy.data.meshes.remove(tmp)
                    original.free()
                    original = trial
                    trial = None
                    changed = True
                    accepted = before - len(original.faces)
                    break
                finally:
                    if trial is not None: trial.free()
            if not changed: break
        if accepted:
            original.to_mesh(mesh)
            mesh.update()
        return accepted
    finally:
        original.free()


class DRIMAHRETOPO_OT_Optimize(Operator):
    bl_idname = 'object.drimah_retopo_optimize'
    bl_label = '2. Testar Decimate (Experimental)'
    bl_description = 'Cria uma copia separada e aplica Decimate Collapse; pode gerar triangulos'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        source = context.active_object
        p = context.scene.drimah_retopo
        before = len(source.data.polygons)
        if before < 4:
            self.report({'WARNING'}, 'Malha pequena demais para reduzir')
            return {'CANCELLED'}
        result = None
        try:
            # Nunca modificar a origem. Uma copia experimental e obrigatoria.
            result = source.copy()
            result.data = source.data.copy()
            result.name = source.name + '_Decimate_Experimental'
            context.collection.objects.link(result)
            # Modificadores existentes podem ser dependentes de outros objetos;
            # nao reaplicar modificadores antigos. O novo modificador atua sobre a copia.
            activate_only(context, result)
            mod = result.modifiers.new(name='Drimah_Decimate_Experimental', type='DECIMATE')
            mod.decimate_type = 'COLLAPSE'
            mod.ratio = max(0.05, 1.0 - p.optimize_reduction / 100.0)
            mod.use_collapse_triangulate = False
            bpy.ops.object.modifier_apply(modifier=mod.name)
            after = len(result.data.polygons)
            tris = sum(len(f.vertices) == 3 for f in result.data.polygons)
            quads = sum(len(f.vertices) == 4 for f in result.data.polygons)
            if after >= before or after == 0:
                bpy.data.objects.remove(result, do_unlink=True)
                activate_only(context, source)
                self.report({'WARNING'}, f'Decimate nao reduziu: {before} -> {after}; original preservado')
                return {'CANCELLED'}
            self.report({'INFO'}, f'EXPERIMENTAL: {before} -> {after} faces; {quads} quads, {tris} triangulos. Original preservado.')
            return {'FINISHED'}
        except Exception as exc:
            if result is not None and result.name in bpy.data.objects:
                bpy.data.objects.remove(result, do_unlink=True)
            activate_only(context, source)
            traceback.print_exc()
            self.report({'ERROR'}, 'Decimate: ' + str(exc)[:180])
            return {'CANCELLED'}



class DRIMAHRETOPO_OT_SafeQuadReduce(Operator):
    bl_idname = 'object.drimah_retopo_safe_quad_reduce'
    bl_label = '3. Otimizar Quads (Seguro)'
    bl_description = 'Reconstroi quads da malha original vinculada a Etapa 1, sem mover vertices; cancela se nao puder garantir 100% quads'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        import bmesh
        from mathutils import Vector
        result = None
        selected = context.active_object
        before = len(selected.data.polygons)
        source_name = selected.get('drimah_source_object')
        if not source_name:
            self.report({'WARNING'}, 'Etapa 3: selecione o resultado da Etapa 1; referencia da origem ausente')
            return {'CANCELLED'}
        original = bpy.data.objects.get(source_name)
        if original is None or original.type != 'MESH' or original == selected:
            self.report({'WARNING'}, 'Etapa 3: objeto original nao encontrado; nenhuma geometria alterada')
            return {'CANCELLED'}
        try:
            depsgraph = context.evaluated_depsgraph_get()
            evaluated = original.evaluated_get(depsgraph)
            candidate = bpy.data.meshes.new_from_object(evaluated, preserve_all_data_layers=True, depsgraph=depsgraph)
            try:
                # The first vertices of step 1 are exact copies of the evaluated source vertices.
                n = len(candidate.vertices)
                if n != int(selected.get('drimah_source_vertices', -1)) or n > len(selected.data.vertices):
                    raise ValueError('A malha de origem mudou desde a Etapa 1; gere a Etapa 1 novamente')
                for i in range(n):
                    if (candidate.vertices[i].co - selected.data.vertices[i].co).length > 1e-5:
                        raise ValueError('Vertices da origem foram alterados; operacao cancelada por seguranca')
                bm = bmesh.new()
                try:
                    bm.from_mesh(candidate)
                    bm.normal_update()
                    triangles = [f for f in bm.faces if len(f.verts) == 3]
                    if triangles:
                        # Pair compatible source triangles; never subdivide to force quads.
                        bmesh.ops.join_triangles(bm, faces=triangles,
                            angle_face_threshold=0.35, angle_shape_threshold=0.35,
                            cmp_seam=True, cmp_sharp=True, cmp_uvs=True, cmp_vcols=True,
                            cmp_materials=True)
                    counts = [len(f.verts) for f in bm.faces]
                    if not counts or any(c != 4 for c in counts):
                        raise ValueError('Origem contem faces sem pares quad seguros; resultado mantido intacto')
                    if len(counts) >= before:
                        raise ValueError('Nao foi encontrada reducao segura de quads')
                    bm.to_mesh(candidate)
                    candidate.update()
                finally:
                    bm.free()
                # Only the checked candidate becomes a new scene object.
                result = bpy.data.objects.new(selected.name + '_QUADS_OTIMIZADOS', candidate)
                context.collection.objects.link(result)
                result.matrix_world = selected.matrix_world.copy()
                result['drimah_source_object'] = source_name
                result['drimah_engine'] = 'Reversao geometrica segura'
                result['drimah_faces_before'] = before
                result['drimah_faces_after'] = len(candidate.polygons)
                activate_only(context, result)
                after = len(candidate.polygons)
                self.report({'INFO'}, f'Quads otimizados: {before:,} -> {after:,} (-{100*(before-after)/before:.1f}%). Forma preservada; original intacto')
                return {'FINISHED'}
            finally:
                if result is None and candidate.name in bpy.data.meshes:
                    bpy.data.meshes.remove(candidate)
        except Exception as exc:
            if result is not None and result.name in bpy.data.objects:
                bpy.data.objects.remove(result, do_unlink=True)
            activate_only(context, selected)
            self.report({'WARNING'}, 'Etapa 3: ' + str(exc)[:190])
            return {'CANCELLED'}

class DRIMAHRETOPO_OT_RecoverQuads(Operator):
    bl_idname = 'object.drimah_retopo_recover_quads'
    bl_label = '4. Recuperar Quads (sem subdividir)'
    bl_description = 'Une pares de triangulos em quads validos; cria copia e nunca aumenta as faces'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        source = context.active_object
        before = len(source.data.polygons)
        before_tris = sum(len(f.vertices) == 3 for f in source.data.polygons)
        if before_tris < 2:
            self.report({'WARNING'}, 'Etapa 4: menos de dois triangulos; nenhuma conversao necessaria')
            return {'CANCELLED'}
        result = None
        bm = None
        try:
            p = context.scene.drimah_retopo
            result = source.copy()
            result.data = source.data.copy()
            result.name = source.name + '_Quads_Recuperados'
            context.collection.objects.link(result)
            # A malha base deve ser a geometria atual, sem reaplicar modificadores existentes.
            bm = bmesh.new()
            bm.from_mesh(result.data)
            bm.normal_update()
            threshold = math.radians(p.quad_join_angle)
            candidates = []
            for e in bm.edges:
                if not e.is_manifold or not e.is_contiguous or not e.smooth or e.seam:
                    continue
                a, b = e.link_faces
                if len(a.verts) != 3 or len(b.verts) != 3:
                    continue
                angle = a.normal.angle(b.normal)
                if angle > threshold:
                    continue
                # Quatro vertices distintos, contorno convexo e sem quad degenerado.
                unique = set(a.verts) | set(b.verts)
                if len(unique) != 4:
                    continue
                other_a = next(v for v in a.verts if v not in e.verts)
                other_b = next(v for v in b.verts if v not in e.verts)
                axis = e.verts[1].co - e.verts[0].co
                cross_a = axis.cross(other_a.co - e.verts[0].co)
                cross_b = axis.cross(other_b.co - e.verts[0].co)
                if cross_a.length_squared < 1e-14 or cross_b.length_squared < 1e-14 or cross_a.dot(cross_b) >= 0:
                    continue
                # Prioriza unioes planas e quadrangulos com diagonais razoaveis.
                diag = (other_a.co - other_b.co).length
                side = axis.length
                if min(diag, side) < 1e-8 or max(diag, side) / min(diag, side) > 12:
                    continue
                candidates.append((angle, abs(math.log(diag / side)), e))
            candidates.sort(key=lambda x: (x[0], x[1]))
            merged = 0
            for _, _, edge in candidates:
                if not edge.is_valid or len(edge.link_faces) != 2:
                    continue
                fa, fb = edge.link_faces
                if not fa.is_valid or not fb.is_valid or len(fa.verts) != 3 or len(fb.verts) != 3:
                    continue
                try:
                    # Unir duas faces triangulares em uma unica face quad.
                    ret = bmesh.ops.dissolve_edges(bm, edges=[edge], use_verts=False, use_face_split=False)
                    if any(f.is_valid and len(f.verts) == 4 for f in ret.get('region', [])):
                        merged += 1
                    else:
                        # Contagem final tambem confere a operacao.
                        merged += 1
                except (ValueError, RuntimeError):
                    continue
            bm.to_mesh(result.data)
            result.data.update()
            after = len(result.data.polygons)
            after_tris = sum(len(f.vertices) == 3 for f in result.data.polygons)
            ngons = sum(len(f.vertices) > 4 for f in result.data.polygons)
            if after >= before or ngons:
                bpy.data.objects.remove(result, do_unlink=True)
                result = None
                activate_only(context, source)
                self.report({'WARNING'}, 'Etapa 4: nenhuma uniao segura ou topologia invalida; original preservado')
                return {'CANCELLED'}
            result['drimah_quads_recovered_from'] = source.name
            result['drimah_quads_faces_before'] = before
            result['drimah_quads_faces_after'] = after
            activate_only(context, result)
            self.report({'INFO'}, f'Etapa 4: {before:,} -> {after:,} faces; {before_tris:,} -> {after_tris:,} triangulos; {before-after:,} pares unidos. Triangulos restantes exigem outra estrategia.')
            return {'FINISHED'}
        except Exception as exc:
            if result is not None and result.name in bpy.data.objects:
                bpy.data.objects.remove(result, do_unlink=True)
            activate_only(context, source)
            traceback.print_exc()
            self.report({'ERROR'}, 'Etapa 4: ' + str(exc)[:180])
            return {'CANCELLED'}
        finally:
            if bm is not None:
                bm.free()

def _point_rebuild_candidates(mesh, groups, parent, corner):
    """Rebuild candidate quad boundaries from original corner points.

    Every parent is a set of four quads produced by button 1. Reconstructing
    parent corners is a point-cloud operation: the first vertex of each child
    quad is the original corner. Connectivity is used ONLY to check boundaries.
    """
    from collections import defaultdict
    candidates = {}
    for pid, group in groups.items():
        if len(group) != 4:
            continue
        ordered = sorted(group, key=lambda i: corner.data[i].value)
        if [corner.data[i].value for i in ordered] != [0, 1, 2, 3]:
            continue
        if any(mesh.attributes['drimah_parent_sides'].data[i].value != 4 for i in ordered):
            continue
        vs = tuple(mesh.polygons[i].vertices[0] for i in ordered)
        if len(set(vs)) != 4:
            continue
        from mathutils.geometry import normal as polygon_normal
        coords = [mesh.vertices[v].co for v in vs]
        n = polygon_normal(*coords)
        if n.length_squared < 1e-12:
            continue
        area = sum((coords[(j+1)%4]-coords[j]).cross(coords[(j+2)%4]-coords[(j+1)%4]).length for j in range(4))
        if area < 1e-10:
            continue
        scale = max((coords[(j+1)%4]-coords[j]).length for j in range(4))
        if abs((coords[3]-coords[0]).dot(n)) > scale * 0.0001:
            continue
        if any(mesh.polygons[i].normal.dot(n) < 0.999 for i in group):
            continue
        if len({mesh.polygons[i].material_index for i in group}) != 1:
            continue
        candidates[pid] = vs

    # Boundary compatibility: merging a parent removes its edge midpoints.
    # Only merge a whole parent-adjacency component if every parent qualifies.
    edge_parents = defaultdict(set)
    for f in mesh.polygons:
        for li in f.loop_indices:
            edge_parents[mesh.loops[li].edge_index].add(parent.data[f.index].value)
    adjacent = defaultdict(set)
    for ps in edge_parents.values():
        if len(ps) > 1:
            for pid in ps:
                adjacent[pid].update(ps - {pid})
    accepted = set()
    seen = set()
    for pid in groups:
        if pid in seen:
            continue
        pending = [pid]
        comp = set()
        while pending:
            current = pending.pop()
            if current in seen:
                continue
            seen.add(current)
            comp.add(current)
            pending.extend(adjacent[current] - seen)
        if comp <= candidates.keys():
            accepted.update(comp)
    return accepted, candidates


def _point_mesh_signature(mesh):
    """Inspect topology, including boundaries, without requiring a closed mesh."""
    from collections import Counter
    edge_use = Counter()
    for poly in mesh.polygons:
        verts = list(poly.vertices)
        if len(verts) != 4 or len(set(verts)) != 4 or poly.area <= 1e-12:
            raise ValueError('Face nao quadrangular ou degenerada')
        for i, v in enumerate(verts):
            edge_use[tuple(sorted((v, verts[(i + 1) % 4])))] += 1
    return edge_use


def _contour_guided_relax(out, reference, strength=0.18):
    """Conservative curvature-aware smoothing of *existing* quad vertices.

    Topology is unchanged. Lock boundary, crease and extraordinary vertices;
    accept only moves that preserve local quad areas and surface proximity.
    This is a local contour-flow experiment, not global quad meshing.
    """
    from collections import defaultdict
    from mathutils import Vector
    from mathutils.bvhtree import BVHTree
    if not strength or not out.polygons:
        return 0
    # BVH is created from the immutable button-1 mesh, not from a modified copy.
    ref_verts = [v.co.copy() for v in reference.vertices]
    ref_faces = [tuple(p.vertices) for p in reference.polygons]
    tree = BVHTree.FromPolygons(ref_verts, ref_faces, all_triangles=False)
    adjacency = defaultdict(set)
    edge_faces = defaultdict(list)
    vertex_faces = defaultdict(list)
    for poly in out.polygons:
        verts = tuple(poly.vertices)
        for v in verts:
            vertex_faces[v].append(poly.index)
        for j, a in enumerate(verts):
            b = verts[(j + 1) % 4]
            key = tuple(sorted((a,b)))
            edge_faces[key].append(poly.index)
            adjacency[a].add(b)
            adjacency[b].add(a)
    locked = set()
    normals = [poly.normal.copy() for poly in out.polygons]
    for (a,b), linked in edge_faces.items():
        if len(linked) != 2 or normals[linked[0]].dot(normals[linked[1]]) < 0.94:
            locked.update((a,b))
    sharp = out.attributes.get('sharp_edge')
    if sharp and sharp.domain == 'EDGE':
        for edge in out.edges:
            if sharp.data[edge.index].value:
                locked.update(edge.vertices)
    original = [v.co.copy() for v in out.vertices]
    proposed = {}
    for idx, neighbors in adjacency.items():
        if idx in locked or len(neighbors) != 4 or len(vertex_faces[idx]) != 4:
            continue
        # Only near a curved contour: avoid needlessly changing broad flat surfaces.
        linked = vertex_faces[idx]
        if min(normals[i].dot(normals[j]) for i in linked for j in linked) > 0.998:
            continue
        co = original[idx]
        avg = sum((original[j] for j in neighbors), Vector()) / 4.0
        candidate = co.lerp(avg, strength)
        hit = tree.find_nearest(candidate)
        if not hit or hit[0] is None:
            continue
        projected = hit[0]
        local_scale = min((original[j] - co).length for j in neighbors)
        if local_scale < 1e-7 or (projected - co).length > local_scale * 0.12:
            continue
        # Require that the projected position stays close to the intended smoothed point.
        if (projected - candidate).length > local_scale * 0.10:
            continue
        valid = True
        for face_index in linked:
            poly = out.polygons[face_index]
            coords = [projected if v == idx else original[v] for v in poly.vertices]
            cross_a = (coords[1]-coords[0]).cross(coords[2]-coords[0])
            cross_b = (coords[2]-coords[0]).cross(coords[3]-coords[0])
            if cross_a.length < 1e-10 or cross_b.length < 1e-10:
                valid = False
                break
            if cross_a.dot(normals[face_index]) <= 0 or cross_b.dot(normals[face_index]) <= 0:
                valid = False
                break
        if valid:
            proposed[idx] = projected.copy()
    # Commit candidates one at a time with local checks against already moved points.
    moved = 0
    for idx, newco in proposed.items():
        old = out.vertices[idx].co.copy()
        out.vertices[idx].co = newco
        safe = True
        for fi in vertex_faces[idx]:
            poly = out.polygons[fi]
            cs = [out.vertices[v].co for v in poly.vertices]
            n1 = (cs[1]-cs[0]).cross(cs[2]-cs[0])
            n2 = (cs[2]-cs[0]).cross(cs[3]-cs[0])
            if n1.dot(normals[fi]) < 1e-9 or n2.dot(normals[fi]) < 1e-9:
                safe = False
                break
        if safe:
            moved += 1
        else:
            out.vertices[idx].co = old
    out.update()
    return moved


class DRIMAHRETOPO_OT_ControlMesh(Operator):
    bl_idname = 'object.drimah_retopo_control_mesh'
    bl_label = '2. Reconstruir por Pontos e Contornos'
    bl_description = 'Cria novas faces com base nos vertices e verifica compatibilidade com a malha original'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return context.mode == 'OBJECT' and obj is not None and obj.type == 'MESH'

    def execute(self, context):
        from collections import defaultdict
        source = context.active_object
        mesh = source.data
        parent = mesh.attributes.get('drimah_parent_face')
        corner = mesh.attributes.get('drimah_corner')
        sides = mesh.attributes.get('drimah_parent_sides')
        if not all((parent, corner, sides)):
            self.report({'WARNING'}, 'Execute primeiro o Botao 1 desta versao')
            return {'CANCELLED'}
        groups = defaultdict(list)
        for i in range(len(mesh.polygons)):
            groups[parent.data[i].value].append(i)
        try:
            original_edges = _point_mesh_signature(mesh)
            accepted, candidate_points = _point_rebuild_candidates(mesh, groups, parent, corner)
            if not accepted:
                self.report({'WARNING'}, 'Pontos analisados; nenhuma regiao segura para reconstruir. Original preservado.')
                return {'CANCELLED'}

            # Generate a fresh polygon list from corner points for accepted
            # patches. For other patches retain existing four-point boundaries.
            faces = []
            materials = []
            smooth = []
            uvfaces = [[] for _ in mesh.uv_layers]
            merged = 0
            for pid, group in groups.items():
                if pid in accepted:
                    ordered = sorted(group, key=lambda i: corner.data[i].value)
                    faces.append(candidate_points[pid])
                    materials.append(mesh.polygons[ordered[0]].material_index)
                    smooth.append(mesh.polygons[ordered[0]].use_smooth)
                    for j, layer in enumerate(mesh.uv_layers):
                        uvfaces[j].append([tuple(layer.data[mesh.polygons[i].loop_start].uv) for i in ordered])
                    merged += 1
                else:
                    for i in group:
                        poly = mesh.polygons[i]
                        faces.append(tuple(poly.vertices))
                        materials.append(poly.material_index)
                        smooth.append(poly.use_smooth)
                        for j, layer in enumerate(mesh.uv_layers):
                            uvfaces[j].append([tuple(layer.data[k].uv) for k in poly.loop_indices])

            # Preflight with the SAME point indices as the input. A source
            # mesh can already contain non-manifold edges; never add new ones.
            from collections import Counter
            new_edges = Counter()
            for face in faces:
                if len(set(face)) != 4:
                    raise ValueError('Quad invalido na reconstrucao por pontos')
                for i in range(4):
                    new_edges[tuple(sorted((face[i], face[(i+1)%4])))] += 1
            if any(count > max(2, original_edges.get(edge, 0)) for edge, count in new_edges.items()):
                raise ValueError('Reconstrucao criaria nova aresta nao-manifold')
            if any(count > 2 and count > original_edges.get(edge, 0) for edge, count in new_edges.items()):
                raise ValueError('Conectividade piorou em aresta existente')
            if len(faces) >= len(mesh.polygons):
                self.report({'WARNING'}, 'Nao houve reducao segura; original preservado')
                return {'CANCELLED'}

            out = bpy.data.meshes.new(source.name + '_PONTOS_MESH')
            try:
                out.from_pydata([tuple(v.co) for v in mesh.vertices], [], faces)
                out.update(calc_edges=True)
                for mat in mesh.materials:
                    out.materials.append(mat)
                for i, f in enumerate(out.polygons):
                    f.material_index = materials[i]
                    f.use_smooth = smooth[i]
                for j, layer in enumerate(mesh.uv_layers):
                    dst = out.uv_layers.new(name=layer.name)
                    index = 0
                    for uvface in uvfaces[j]:
                        for uv in uvface:
                            dst.data[index].uv = uv
                            index += 1
                sharp = mesh.attributes.get('sharp_edge')
                if sharp is not None and sharp.domain == 'EDGE':
                    sharp_keys = {tuple(sorted(e.vertices)) for e in mesh.edges if sharp.data[e.index].value}
                    attr = out.attributes.new('sharp_edge', 'BOOLEAN', 'EDGE')
                    for edge in out.edges:
                        attr.data[edge.index].value = tuple(sorted(edge.vertices)) in sharp_keys
                # Remove unused points only after all indices and UVs are assigned.
                bm = bmesh.new()
                try:
                    bm.from_mesh(out)
                    bmesh.ops.delete(bm, geom=[v for v in bm.verts if not v.link_faces], context='VERTS')
                    bm.to_mesh(out)
                finally:
                    bm.free()
                out.update()
                _point_mesh_signature(out)
                moved = 0
                options = context.scene.drimah_retopo
                if options.contour_relax:
                    moved = _contour_guided_relax(out, mesh, options.contour_strength / 100.0)
                if len(out.polygons) >= len(mesh.polygons):
                    raise ValueError('Sem reducao de faces')
                result = bpy.data.objects.new(source.name + '_PONTOS', out)
                context.collection.objects.link(result)
                result.matrix_world = source.matrix_world.copy()
                result['drimah_retopo_version'] = '4.8'
                result['drimah_contour_points_adjusted'] = moved
                result['drimah_retopo_mode'] = 'Reconstrucao por pontos com verificacao topologica'
                result['drimah_faces_before'] = len(mesh.polygons)
                result['drimah_faces_after'] = len(out.polygons)
                activate_only(context, result)
                self.report({'INFO'}, f'Pontos: {len(mesh.polygons):,} -> {len(out.polygons):,} quads; {merged} regioes reconstruidas; {moved} pontos ajustados')
                return {'FINISHED'}
            except Exception:
                if out.name in bpy.data.meshes and out.users == 0:
                    bpy.data.meshes.remove(out)
                raise
        except Exception as exc:
            traceback.print_exc()
            self.report({'ERROR'}, 'Reconstrucao por pontos: ' + str(exc)[:150])
            return {'CANCELLED'}

# Dependency diagnostics: no network requests or installations without user action.
def _drimah_dependencies():
    checks = []
    try:
        import bmesh as _bm
        checks.append(('BMesh', True, 'Incluido no Blender'))
    except Exception:
        checks.append(('BMesh', False, 'Recurso interno indisponivel'))
    try:
        checks.append(('QuadriFlow', hasattr(bpy.ops.object, 'quadriflow_remesh'), 'Integrado ao Blender'))
    except Exception:
        checks.append(('QuadriFlow', False, 'Operador nao encontrado'))
    try:
        engine = engine_command()
        exists = bool(engine and os.path.isfile(str(engine)))
        checks.append(('AutoRemesher', exists, 'Motor incluido no pacote' if exists else 'Binario ausente para este sistema'))
    except Exception:
        checks.append(('AutoRemesher', False, 'Motor nao localizado'))
    # Optional extensions may be provided by Blender Extensions or legacy add-ons.
    import importlib.util
    for name, modules in [('LoopTools', ('bl_ext.blender_org.looptools', 'mesh_looptools')),
                          ('Bsurfaces', ('bl_ext.blender_org.bsurfaces_gpl_edition', 'mesh_bsurfaces'))]:
        installed = False
        for module in modules:
            try:
                if importlib.util.find_spec(module) is not None:
                    installed = True
                    break
            except (ImportError, ModuleNotFoundError, ValueError):
                pass
        checks.append((name, installed, 'Opcional; nao exigido para etapas 1 e 2'))
    return checks

class DRIMAHRETOPO_OT_CheckDependencies(Operator):
    bl_idname = 'object.drimah_retopo_check_dependencies'
    bl_label = 'Verificar dependencias'
    bl_description = 'Verifica recursos locais sem baixar nem instalar nada'
    bl_options = {'REGISTER'}

    def execute(self, context):
        checks = _drimah_dependencies()
        for name, available, note in checks:
            print('[Drimah Retopo]', name, 'OK' if available else 'AUSENTE', note)
        context.scene['drimah_deps_last_check'] = ' | '.join(
            name + ': ' + ('OK' if ok else 'Ausente') for name, ok, _ in checks)
        missing = [name for name, ok, _ in checks if not ok and name not in {'AutoRemesher', 'LoopTools', 'Bsurfaces'}]
        self.report({'INFO'}, 'Verificacao concluida; ausentes: ' + ', '.join(missing) if missing else 'Todas as dependencias detectadas')
        return {'FINISHED'}

class DRIMAHRETOPO_OT_OpenExtensions(Operator):
    bl_idname = 'object.drimah_retopo_open_extensions'
    bl_label = 'Abrir extensoes oficiais'
    bl_description = 'Abre a pagina oficial de extensoes do Blender no navegador; nenhuma instalacao automatica'
    bl_options = {'REGISTER'}

    def execute(self, context):
        bpy.ops.wm.url_open(url='https://extensions.blender.org/')
        return {'FINISHED'}



def _scan_surface_points(obj):
    """Inspect sampled positions, surface normals, feature edges and spacing.

    Does not assume proximity alone implies connectivity: original faces remain
    the geometric reference for the quadrangulation engine.
    """
    from mathutils import Vector
    import statistics
    mesh = obj.data
    if not mesh.vertices or not mesh.polygons:
        raise ValueError('Malha sem pontos ou faces')
    spacing = []
    boundary_edges = 0
    hard_edges = 0
    for edge in mesh.edges:
        a, b = edge.vertices
        length = (mesh.vertices[a].co - mesh.vertices[b].co).length
        if length > 1e-9:
            spacing.append(length)
    # Compute connectivity and crease density without relying on object mode operators.
    edge_faces = {}
    for poly in mesh.polygons:
        verts = list(poly.vertices)
        for i in range(len(verts)):
            key = tuple(sorted((verts[i], verts[(i + 1) % len(verts)])))
            edge_faces.setdefault(key, []).append(poly.index)
    for faces in edge_faces.values():
        if len(faces) == 1:
            boundary_edges += 1
        elif len(faces) == 2 and mesh.polygons[faces[0]].normal.dot(mesh.polygons[faces[1]].normal) < 0.866:
            hard_edges += 1
    return {'points': len(mesh.vertices), 'faces': len(mesh.polygons),
            'median_spacing': statistics.median(spacing) if spacing else 0,
            'boundaries': boundary_edges, 'hard_edges': hard_edges,
            'nonmanifold': sum(1 for faces in edge_faces.values() if len(faces) > 2)}


# Experimental QRemeshify/QuadWild engine, shipped for the selected operating system.
# GPL-3.0-or-later; upstream https://github.com/ksami/QRemeshify
# Registered lazily to avoid affecting the two proven native Drimah operations.
# Resolve engine classes from Blender's RNA registry, rather than assuming
# bpy.types exposes every dynamically registered class as an attribute.
def _drimah_rna_class(base, name):
    try:
        return base.bl_rna_get_subclass_py(name, None)
    except (AttributeError, RuntimeError):
        return None


# Classes do motor devem ser registradas UMA vez ao ativar o add-on.
# Nunca registrar/desregistrar RNA durante a execucao de uma operacao.
from .qremeshify_engine.props import QWPropertyGroup, QRPropertyGroup
from .qremeshify_engine.operator import QREMESH_OT_Remesh

_ENGINE_CLASSES = (QWPropertyGroup, QRPropertyGroup, QREMESH_OT_Remesh)
_engine_owned = []

def _drimah_enable_quadwild():
    # A chamada de reconstrucao apenas verifica o motor ja inicializado.
    try:
        bpy.ops.qremeshify.remesh.get_rna_type()
    except (AttributeError, RuntimeError) as exc:
        raise RuntimeError('Motor QuadWild nao registrado. Reative o Drimah Retopo e reinicie o Blender.') from exc


class DRIMAHRETOPO_OT_QuadWildTest(Operator):
    bl_idname = 'object.drimah_retopo_quadwild_test'
    bl_label = 'Motor QuadWild interno (experimental)'
    bl_description = 'Gera nova malha usando QRemeshify/QuadWild; nao altera o objeto original'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or context.mode != 'OBJECT':
            self.report({'ERROR'}, 'Selecione um objeto Mesh em Object Mode')
            return {'CANCELLED'}
        original = obj
        old_names = set(bpy.data.objects.keys())
        try:
            _drimah_enable_quadwild()
            # Run on an independent copy, not on the original or button-1 output.
            copy = original.copy()
            copy.data = original.data.copy()
            context.collection.objects.link(copy)
            copy.name = original.name + '_QW_input'
            bpy.ops.object.select_all(action='DESELECT')
            copy.select_set(True)
            context.view_layer.objects.active = copy
            scan = _scan_surface_points(original)
            props = context.scene.quadwild_props
            # The source surface and sampled points guide a global quad field.
            # Keep a nonzero feature budget for creases and open boundaries.
            density = context.scene.drimah_retopo.point_density / 100.0
            feature_factor = 1.0 + min(0.35, (scan['hard_edges'] + scan['boundaries']) / max(1, scan['points']))
            context.scene.quadpatches_props.scaleFact = max(0.25, min(3.0, 1.0 / (density * feature_factor)))
            props.enableSharp = True
            props.useCache = False
            props.debug = False
            result = bpy.ops.qremeshify.remesh()
            if 'FINISHED' not in result:
                raise RuntimeError('O motor QRemeshify cancelou a operacao')
            generated = context.view_layer.objects.active
            if not generated or generated == copy or generated.type != 'MESH':
                raise RuntimeError('O motor nao gerou um novo objeto Mesh')
            if not generated.data.polygons:
                raise RuntimeError('Resultado vazio')
            _point_mesh_signature(generated.data)
            # Never silently accept a mesh with worse nonmanifold incidence.
            outscan = _scan_surface_points(generated)
            if outscan['nonmanifold'] > scan['nonmanifold']:
                raise RuntimeError('Reconstrucao aumentou arestas nao-manifold')
            nonquads = sum(1 for p in generated.data.polygons if len(p.vertices) != 4)
            if nonquads:
                raise RuntimeError(f'Resultado rejeitado: {nonquads} faces nao sao quads')
            generated.name = original.name + '_Drimah_Digitalizado_48'
            original.hide_set(False)
            original.select_set(False)
            generated['drimah_retopo_version'] = '4.8'
            generated['drimah_scanned_points'] = scan['points']
            generated['drimah_scanned_hard_edges'] = scan['hard_edges']
            generated['drimah_scanned_boundaries'] = scan['boundaries']
            self.report({'INFO'}, f'Digitalizacao: {scan["points"]} pontos analisados; {len(generated.data.polygons)} quads; original preservado')
            return {'FINISHED'}
        except Exception as e:
            # Remove newly created temporary/result objects if the run failed.
            for name in list(set(bpy.data.objects.keys()) - old_names):
                candidate = bpy.data.objects.get(name)
                if candidate is not None:
                    bpy.data.objects.remove(candidate, do_unlink=True)
            original.hide_set(False)
            bpy.ops.object.select_all(action='DESELECT')
            original.select_set(True)
            context.view_layer.objects.active = original
            self.report({'ERROR'}, 'Reconstrucao por pontos falhou: ' + str(e)[:140])
            return {'CANCELLED'}


class DRIMAHRETOPO_OT_QuadWildWithStatus(Operator):
    """Mostra um status antes de iniciar o motor nativo, que bloqueia a interface."""
    bl_idname = 'object.drimah_retopo_quadwild_status'
    bl_label = 'Remesh QuadWild'
    bl_description = 'Executa QuadWild mostrando um aviso enquanto processa'
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None

    def invoke(self, context, event):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or context.mode != 'OBJECT':
            self.report({'ERROR'}, 'Selecione um objeto Mesh em Object Mode')
            return {'CANCELLED'}
        p = context.scene.drimah_retopo
        p.progress_active = True
        p.progress_stage = 4
        p.progress_percent = 0
        p.progress_status = 'Aguarde... Processando...'
        if context.area:
            context.area.tag_redraw()
        self._timer = context.window_manager.event_timer_add(0.25, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type != 'TIMER':
            return {'PASS_THROUGH'}
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None
        p = context.scene.drimah_retopo
        try:
            result = bpy.ops.object.drimah_retopo_quadwild_test('EXEC_DEFAULT')
            if 'FINISHED' in result:
                p.progress_percent = 0
                p.progress_status = ''
                self.report({'INFO'}, 'QuadWild concluído')
            else:
                p.progress_status = ''
        except Exception as exc:
            p.progress_status = ''
            self.report({'ERROR'}, p.progress_status)
        finally:
            p.progress_active = False
            if context.area:
                context.area.tag_redraw()
        return {'FINISHED'}


class DRIMAHRETOPO_OT_Reconstruct(Operator):
    bl_idname = 'object.drimah_retopo_reconstruct'
    bl_label = '2 - Reconstruir Quads'
    bl_description = 'Executa o metodo selecionado sem instalar outro add-on'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        method = context.scene.drimah_retopo.reconstruction_engine
        if method == 'QUADWILD':
            return bpy.ops.object.drimah_retopo_quadwild_test()
        if not context.active_object or context.active_object.type != 'MESH':
            self.report({'ERROR'}, 'Selecione uma malha')
            return {'CANCELLED'}
        if context.active_object.data.attributes.get('drimah_parent_face') is None:
            self.report({'ERROR'}, 'Execute primeiro o Botao 1 para usar Pontos e contornos')
            return {'CANCELLED'}
        return bpy.ops.object.drimah_retopo_control_mesh()


class DRIMAHRETOPO_OT_PointCloud(Operator):
    bl_idname = 'object.drimah_retopo_point_cloud'
    bl_label = 'Mostrar somente pontos'
    bl_description = 'Cria uma copia com os vertices do objeto, sem arestas nem faces'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        source = context.active_object
        coords = [tuple(v.co) for v in source.data.vertices]
        if not coords:
            self.report({'WARNING'}, 'Objeto sem vertices')
            return {'CANCELLED'}
        mesh = bpy.data.meshes.new(source.name + '_PONTOS')
        mesh.from_pydata(coords, [], [])
        mesh.update()
        result = bpy.data.objects.new(source.name + '_PONTOS', mesh)
        try:
            context.collection.objects.link(result)
            result.matrix_world = source.matrix_world.copy()
            result.show_in_front = True
            result['drimah_point_source'] = source.name
            result['drimah_point_count'] = len(coords)
            source.hide_set(True)
            bpy.ops.object.select_all(action='DESELECT')
            result.select_set(True)
            context.view_layer.objects.active = result
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(type='VERT')
            bpy.ops.mesh.select_all(action='SELECT')
            self.report({'INFO'}, f'{len(coords):,} pontos criados; zero arestas e zero faces')
            return {'FINISHED'}
        except Exception as exc:
            try:
                if context.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass
            source.hide_set(False)
            bpy.data.objects.remove(result, do_unlink=True)
            self.report({'ERROR'}, str(exc)[:180])
            return {'CANCELLED'}


class DRIMAHRETOPO_OT_FacesFromPoints(Operator):
    bl_idname = 'object.drimah_retopo_faces_from_points'
    bl_label = 'Criar Faces'
    bl_description = 'Reconstrói quads a partir dos pontos, usando a conectividade da malha de referência'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return bool(obj and obj.type == 'MESH' and obj.get('drimah_point_source') and context.mode in {'OBJECT', 'EDIT_MESH'})

    def execute(self, context):
        points = context.active_object
        # Mesh data accessed only in Object Mode; edit-mode data may be stale.
        if context.mode == 'EDIT_MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
        ref_name = points.get('drimah_point_source', '')
        reference = bpy.data.objects.get(ref_name)
        if reference is None or reference.type != 'MESH':
            self.report({'ERROR'}, 'Malha de referencia nao encontrada; mantenha o objeto usado para criar os pontos')
            return {'CANCELLED'}
        if len(points.data.vertices) != len(reference.data.vertices):
            self.report({'ERROR'}, 'A quantidade de pontos mudou; nao e possivel mapear as faces com seguranca')
            return {'CANCELLED'}
        # The source mesh must already consist of quads. Do not invent connections.
        if not reference.data.polygons or any(len(face.vertices) != 4 for face in reference.data.polygons):
            self.report({'ERROR'}, 'A referencia precisa ter somente faces quadrangulares (execute Converter para Quads primeiro)')
            return {'CANCELLED'}
        coords = [tuple(v.co) for v in points.data.vertices]
        faces = [tuple(face.vertices) for face in reference.data.polygons]
        mesh = bpy.data.meshes.new(points.name + '_FACES')
        result = None
        try:
            mesh.from_pydata(coords, [], faces)
            mesh.update(calc_edges=True)
            if mesh.validate(verbose=False, clean_customdata=False):
                raise RuntimeError('Validacao detectou geometria invalida; reconstrucao cancelada')
            if len(mesh.polygons) != len(faces) or any(len(p.vertices) != 4 for p in mesh.polygons):
                raise RuntimeError('Faces reconstruidas nao passaram na verificacao de quads')
            result = bpy.data.objects.new(points.name + '_FACES', mesh)
            context.collection.objects.link(result)
            result.matrix_world = points.matrix_world.copy()
            result['drimah_reconstructed_from_points'] = True
            result['drimah_reference_object'] = reference.name
            points.hide_set(True)
            bpy.ops.object.select_all(action='DESELECT')
            result.select_set(True)
            context.view_layer.objects.active = result
            self.report({'INFO'}, f'{len(faces):,} quads criados a partir de {len(coords):,} pontos')
            return {'FINISHED'}
        except Exception as exc:
            if result is not None:
                bpy.data.objects.remove(result, do_unlink=True)
            elif mesh.name in bpy.data.meshes:
                bpy.data.meshes.remove(mesh)
            self.report({'ERROR'}, f'Falha ao criar faces: {str(exc)[:160]}')
            return {'CANCELLED'}

class DRIMAHRETOPO_OT_TraceGuides(Operator):
    bl_idname = 'object.drimah_retopo_trace_guides'
    bl_label = 'Tracar guias'
    bl_description = 'Identifica contornos e vincos da superficie e desenha uma rede-guia sem faces'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return bool(ob and ob.type == 'MESH' and context.mode in {'OBJECT', 'EDIT_MESH'} and ob.get('drimah_point_source'))

    def execute(self, context):
        import math
        from mathutils import Vector
        points = context.active_object
        if context.mode == 'EDIT_MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
        ref = bpy.data.objects.get(points.get('drimah_point_source', ''))
        if not ref or ref.type != 'MESH' or len(points.data.vertices) != len(ref.data.vertices):
            self.report({'ERROR'}, 'Referencia original indisponivel ou numero de pontos diferente')
            return {'CANCELLED'}
        # A feature edge is an open boundary or a crease between adjacent faces.
        # The source supplies topology ONLY to detect geometric boundaries, not
        # to rebuild its faces. The guide mesh is independent and has no faces.
        neighbors = [[] for _ in ref.data.edges]
        edge_map = {tuple(sorted(e.vertices)):e.index for e in ref.data.edges}
        for face in ref.data.polygons:
            for edge_key in face.edge_keys:
                idx = edge_map.get(tuple(sorted(edge_key)))
                if idx is not None:
                    neighbors[idx].append(face.index)
        threshold = math.radians(40.0)
        guide_edges = []
        for edge in ref.data.edges:
            fs = neighbors[edge.index]
            if len(fs) != 2 or ref.data.polygons[fs[0]].normal.angle(ref.data.polygons[fs[1]].normal) >= threshold:
                guide_edges.append(tuple(edge.vertices))
        if not guide_edges:
            self.report({'WARNING'}, 'Nao foram encontrados contornos ou vincos acima de 40 graus')
            return {'CANCELLED'}
        coords = [tuple(v.co) for v in points.data.vertices]
        mesh = bpy.data.meshes.new(ref.name + '_GUIAS_mesh')
        mesh.from_pydata(coords, guide_edges, [])
        mesh.update()
        guides = bpy.data.objects.new(ref.name + '_GUIAS', mesh)
        context.collection.objects.link(guides)
        guides.matrix_world = points.matrix_world.copy()
        guides['drimah_guide_source'] = ref.name
        guides['drimah_point_object'] = points.name
        guides.display_type = 'WIRE'
        guides.show_in_front = True
        points.hide_set(True)
        bpy.ops.object.select_all(action='DESELECT')
        guides.select_set(True)
        context.view_layer.objects.active = guides
        self.report({'INFO'}, f'{len(guide_edges)} segmentos-guia; zero faces; referencia preservada')
        return {'FINISHED'}


def _drimah_diagnostic(event, detail=''):
    """Durable breadcrumbs for Blender crashes; do not raise from diagnostics."""
    try:
        log_path = Path(tempfile.gettempdir()) / 'Drimah-Retopo-diagnostico.txt'
        with log_path.open('a', encoding='utf-8') as handle:
            handle.write(f'{datetime.datetime.now().isoformat(timespec="seconds")} | {event} | {detail}\n')
            handle.flush()
            os.fsync(handle.fileno())
    except Exception:
        pass


class DRIMAHRETOPO_OT_SurfaceFromGuides(Operator):
    bl_idname = 'object.drimah_retopo_surface_from_guides'
    bl_label = 'Reconstruir superficie'
    bl_description = 'Reconstrucao com acompanhamento por etapas; o motor QuadWild nao fornece porcentagem interna'
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _phase = 0
    _source_name = ''

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return bool(ob and ob.type == 'MESH' and context.mode == 'OBJECT' and ob.get('drimah_guide_source'))

    def _reset_progress(self, context):
        p = context.scene.drimah_retopo
        p.progress_active = False
        p.progress_stage = 0
        p.progress_percent = 0
        p.progress_status = ''
        if context.area:
            context.area.tag_redraw()
        _drimah_diagnostic('INICIO', f'objeto={context.active_object.name if context.active_object else "nenhum"}; versao=5.6')

    def _progress(self, context, stage, pct, message):
        p = context.scene.drimah_retopo
        p.progress_active = True
        p.progress_stage = stage
        p.progress_percent = pct
        p.progress_status = 'Aguarde... Processando...'
        _drimah_diagnostic('PROGRESSO', f'etapa={stage}/6; percentual interno indisponivel; {p.progress_status}')
        if context.area:
            context.area.tag_redraw()

    def _cleanup(self, context, status, message):
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        p = context.scene.drimah_retopo
        p.progress_active = False
        p.progress_status = ''
        p.progress_stage = 0
        p.progress_percent = 0
        _drimah_diagnostic('FIM', f'{status}: {message}')
        if context.area:
            context.area.tag_redraw()
        return {status}

    def invoke(self, context, event):
        self._phase = 0
        self._source_name = context.active_object.name
        self._reset_progress(context)
        # First draw is always zero; subsequent timer events advance stages.
        self._timer = context.window_manager.event_timer_add(0.15, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        # Script/background invocation: no modal event loop available.
        self._phase = 0
        self._source_name = context.active_object.name
        self._reset_progress(context)
        self._progress(context, 1, 5, 'Preparando referencia')
        return self._run_blocking(context)

    def modal(self, context, event):
        if event.type == 'ESC' and self._phase < 3:
            return self._cleanup(context, 'CANCELLED', 'Cancelado antes de iniciar o motor')
        if event.type != 'TIMER':
            return {'PASS_THROUGH'}
        if self._phase == 0:
            self._phase = 1
            self._progress(context, 2, 25, 'Validando guias e superficie')
            return {'RUNNING_MODAL'}
        if self._phase == 1:
            self._phase = 2
            self._progress(context, 3, 35, 'Motor QuadWild em preparacao; ESC cancela agora')
            # Give Blender a redraw opportunity before entering the native call.
            return {'RUNNING_MODAL'}
        self._phase = 3
        return self._run_blocking(context)

    def _run_blocking(self, context):
        guides = context.active_object
        ref = bpy.data.objects.get(guides.get('drimah_guide_source', '')) if guides else None
        if not ref or ref.type != 'MESH':
            self.report({'ERROR'}, 'Superficie original nao encontrada')
            return self._cleanup(context, 'CANCELLED', 'Referencia nao encontrada')
        bpy.ops.object.select_all(action='DESELECT')
        ref.hide_set(False)
        ref.select_set(True)
        context.view_layer.objects.active = ref
        try:
            self._progress(context, 4, 35, 'Reconstruindo (motor nativo sem progresso interno)')
            _drimah_diagnostic('MOTOR_NATIVO_ENTRADA', f'referencia={ref.name}; vertices={len(ref.data.vertices)}; faces={len(ref.data.polygons)}')
            result = bpy.ops.object.drimah_retopo_quadwild_test()
            _drimah_diagnostic('MOTOR_NATIVO_SAIDA', str(result))
            if 'FINISHED' not in result:
                raise RuntimeError('Motor cancelou a reconstrucao')
            self._progress(context, 5, 90, 'Validando quads e conectividade')
            output = context.active_object
            if not output or output.type != 'MESH' or output == ref:
                raise RuntimeError('Nenhuma nova malha gerada')
            output.name = ref.name + '_Drimah_56'
            output['drimah_guide_object'] = guides.name
            output['drimah_retopo_version'] = '5.6'
            output['drimah_reconstruction_source'] = ref.name
            output['drimah_face_count'] = len(output.data.polygons)
            self._progress(context, 6, 98, 'Finalizando objeto')
            guides.hide_set(True)
            return self._cleanup(context, 'FINISHED', 'Reconstrucao concluida')
        except Exception as exc:
            _drimah_diagnostic('ERRO', traceback.format_exc())
            guides.hide_set(False)
            bpy.ops.object.select_all(action='DESELECT')
            guides.select_set(True)
            context.view_layer.objects.active = guides
            self.report({'ERROR'}, 'Falha na reconstrucao: ' + str(exc)[:140])
            return self._cleanup(context, 'CANCELLED', 'Falha: veja Drimah-Retopo-diagnostico.txt em TEMP')


class DRIMAHRETOPO_OT_QuadriFlowWithStatus(Operator):
    """Cria uma copia e executa o QuadriFlow integrado ao Blender."""
    bl_idname = 'object.drimah_retopo_quadriflow_status'
    bl_label = 'Remesh QuadriFlow'
    bl_description = 'Cria uma nova malha usando o QuadriFlow nativo; preserva o original'
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None

    def invoke(self, context, event):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or context.mode != 'OBJECT':
            self.report({'ERROR'}, 'Selecione um objeto Mesh em Object Mode')
            return {'CANCELLED'}
        if not hasattr(bpy.ops.object, 'quadriflow_remesh'):
            self.report({'ERROR'}, 'QuadriFlow nao esta disponivel nesta versao do Blender')
            return {'CANCELLED'}
        p = context.scene.drimah_retopo
        p.progress_active = True
        p.progress_stage = 4
        p.progress_percent = 0
        p.progress_status = 'Aguarde... Processando...'
        if context.area:
            context.area.tag_redraw()
        self._timer = context.window_manager.event_timer_add(0.25, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type != 'TIMER':
            return {'PASS_THROUGH'}
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None
        p = context.scene.drimah_retopo
        original = context.active_object
        result_obj = None
        try:
            # Independent mesh data: the source object is never remeshed in place.
            result_obj = original.copy()
            result_obj.data = original.data.copy()
            result_obj.name = original.name + '_QuadriFlow'
            result_obj.data.name = result_obj.name + '_Mesh'
            context.collection.objects.link(result_obj)
            bpy.ops.object.select_all(action='DESELECT')
            result_obj.select_set(True)
            context.view_layer.objects.active = result_obj
            target = max(500, min(int(p.custom_faces), 2000000))
            bpy.ops.object.quadriflow_remesh(target_faces=target)
            result_obj['drimah_remesh_engine'] = 'Blender QuadriFlow'
            result_obj['drimah_source_object'] = original.name
            bpy.ops.object.select_all(action='DESELECT')
            original.select_set(True)
            result_obj.select_set(True)
            context.view_layer.objects.active = result_obj
            p.progress_percent = 0
            p.progress_status = ''
            self.report({'INFO'}, 'QuadriFlow concluido; original preservado')
            return {'FINISHED'}
        except Exception as exc:
            if result_obj is not None and result_obj.name in bpy.data.objects:
                bpy.data.objects.remove(result_obj, do_unlink=True)
            if original and original.name in bpy.data.objects:
                bpy.ops.object.select_all(action='DESELECT')
                original.select_set(True)
                context.view_layer.objects.active = original
            p.progress_status = ''
            self.report({'ERROR'}, 'QuadriFlow falhou: ' + str(exc)[:140])
            return {'CANCELLED'}
        finally:
            p.progress_active = False
            if context.area:
                context.area.tag_redraw()



class DRIMAHRETOPO_PT_Main(Panel):
    bl_label = 'Drimah Retopo 5.19'
    bl_idname = 'DRIMAHRETOPO_PT_main'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Drimah Retopo'

    def draw(self, context):
        l = self.layout
        p = context.scene.drimah_retopo
        obj = context.active_object
        valid = bool(obj and obj.type == 'MESH' and context.mode == 'OBJECT')
        info = l.box()
        if valid:
            info.label(text=f'Objeto: {obj.name}', icon='MESH_DATA')
            info.label(text=f'Faces: {len(obj.data.polygons):,}')
        else:
            info.label(text='Selecione uma malha no Modo Objeto', icon='INFO')

        deps_header = l.row(align=True)
        deps_header.prop(p, 'show_dependencies', text='Dependencias e Motores',
                         icon='TRIA_DOWN' if p.show_dependencies else 'TRIA_RIGHT', emboss=False)
        if p.show_dependencies:
            deps = l.box()
            for name, available, note in _drimah_dependencies():
                line = deps.row(align=True)
                line.label(text=name, icon='CHECKMARK' if available else 'ERROR')
                line.label(text='OK' if available else 'Opcional' if name in {'LoopTools','Bsurfaces','AutoRemesher'} else 'Ausente')
            deps.operator('object.drimah_retopo_check_dependencies', icon='FILE_REFRESH')
            deps.operator('object.drimah_retopo_open_extensions', icon='URL')
            deps.label(text='AutoRemesher nao e necessario para botoes 1 e 2', icon='INFO')
            deps.label(text='Nao ha download integrado do motor', icon='INFO')

        step1 = l.box()
        step1.label(text='Geometria em Quads', icon='MESH_GRID')
        step1.prop(p, 'preserve_original')
        # Cada operador usa uma linha independente, como os controles da seção Pontos.
        # Isso preserva o espaçamento vertical normal do Blender entre os botões.
        for operator_id, label, icon_name in (
            ('object.drimah_retopo_convert_quads', 'Converter para Quads', 'MOD_REMESH'),
            ('object.drimah_retopo_quadwild_status', 'Remesh QuadWild', 'MOD_REMESH'),
            ('object.drimah_retopo_quadriflow_status', 'Remesh QuadriFlow', 'MESH_GRID'),
            ('object.drimah_retopo_auto_quad', 'Retopologia automática', 'PLAY'),
        ):
            button_row = step1.row()
            button_row.enabled = valid
            button_row.operator(operator_id, text=label, icon=icon_name)

        step2 = l.box()
        step2.label(text='Pontos', icon='VERTEXSEL')
        col = step2.column()
        col.enabled = valid
        col.operator('object.drimah_retopo_point_cloud', text='Mostrar somente pontos', icon='VERTEXSEL')
        row = step2.row()
        row.enabled = bool(obj and obj.type == 'MESH' and obj.get('drimah_point_source') and context.mode in {'OBJECT', 'EDIT_MESH'})
        row.operator('object.drimah_retopo_trace_guides', text='Tracar guias', icon='CURVE_PATH')
        guides_row = step2.row()
        guides_row.enabled = bool(obj and obj.get('drimah_guide_source') and context.mode == 'OBJECT')
        guides_row.operator('object.drimah_retopo_surface_from_guides', text='Reconstruir superficie', icon='FACESEL')

        # Fast Remesher integrado; as ferramentas originais do DRIMAH permanecem intactas.
        fr = l.box()
        fr.label(text='Fast Remesher', icon='MOD_REMESH')
        fr.label(text='Ferramentas integradas', icon='INFO')
        frrow = fr.row(align=True)
        frrow.enabled = valid
        frrow.operator('fastremesher.auto_detect_preset', text='Detectar', icon='VIEWZOOM')
        frrow.operator('fastremesher.preflight', text='Verificar malha', icon='CHECKMARK')
        frrow = fr.row(align=True)
        frrow.enabled = valid
        frrow.operator('fastremesher.hardsurface', text='Hard Surface', icon='MOD_REMESH')
        frrow.operator('fastremesher.organic', text='Orgânico', icon='MESH_UVSPHERE')
        # Gerar Malha fica sozinho em sua própria linha, conforme solicitado.
        frrow = fr.row()
        frrow.enabled = valid
        frrow.operator('fastremesher.garment', text='Gerar Malha', icon='MESH_DATA')
        restore_row = fr.row()
        restore_row.enabled = bool(obj and obj.type == 'MESH' and obj.get('fastremesher_backup_object'))
        restore_row.operator('fastremesher.restore_original', text='Restaurar original', icon='LOOP_BACK')

        # Indicador simples: sem barra, etapas ou percentuais.
        if p.progress_active:
            l.label(text='Aguarde... Processando...', icon='TIME')

classes = (DRIMAHRETOPO_Properties, DRIMAHRETOPO_OT_TraceGuides, DRIMAHRETOPO_OT_SurfaceFromGuides, DRIMAHRETOPO_OT_FacesFromPoints, DRIMAHRETOPO_OT_PointCloud, DRIMAHRETOPO_OT_QuadWildTest, DRIMAHRETOPO_OT_QuadWildWithStatus, DRIMAHRETOPO_OT_QuadriFlowWithStatus, DRIMAHRETOPO_OT_Reconstruct, DRIMAHRETOPO_OT_ControlMesh, DRIMAHRETOPO_OT_AutoQuad, DRIMAHRETOPO_OT_ConvertQuads, DRIMAHRETOPO_OT_HardEdges, DRIMAHRETOPO_OT_Optimize, DRIMAHRETOPO_OT_SafeQuadReduce, DRIMAHRETOPO_OT_RecoverQuads, DRIMAHRETOPO_OT_CheckDependencies, DRIMAHRETOPO_OT_OpenExtensions, DRIMAHRETOPO_PT_Main)

def _remove_legacy_registration():
    if hasattr(bpy.types.Scene, 'drimah_retopo'):
        try: del bpy.types.Scene.drimah_retopo
        except Exception: pass
    for name in ('DRIMAHRETOPO_OT_TraceGuides','DRIMAHRETOPO_OT_SurfaceFromGuides','DRIMAHRETOPO_OT_FacesFromPoints','DRIMAHRETOPO_OT_PointCloud','DRIMAHRETOPO_OT_QuadWildTest','DRIMAHRETOPO_OT_Reconstruct','DRIMAHRETOPO_OT_ControlMesh','DRIMAHRETOPO_PT_Main','DRIMAHRETOPO_OT_OpenExtensions','DRIMAHRETOPO_OT_CheckDependencies','DRIMAHRETOPO_OT_RecoverQuads','DRIMAHRETOPO_OT_SafeQuadReduce','DRIMAHRETOPO_OT_QuadriFlow','DRIMAHRETOPO_OT_Optimize','DRIMAHRETOPO_OT_HardEdges','DRIMAHRETOPO_OT_ConvertQuads','DRIMAHRETOPO_OT_AutoQuad','DRIMAHRETOPO_Properties'):
        old = getattr(bpy.types, name, None)
        if old:
            try: bpy.utils.unregister_class(old)
            except Exception: pass

def register():
    _remove_legacy_registration()
    # Registrar classes do motor em ordem, antes de seus PointerProperties.
    # Uma classe existente de outra instalacao nao deve ser removida.
    _engine_owned.clear()
    registered = []
    try:
        for cls in _ENGINE_CLASSES:
            if getattr(cls, 'is_registered', False):
                continue
            bpy.utils.register_class(cls)
            _engine_owned.append(cls)
        if not hasattr(bpy.types.Scene, 'quadwild_props'):
            bpy.types.Scene.quadwild_props = PointerProperty(type=QWPropertyGroup)
            _engine_owned.append('quadwild_props')
        if not hasattr(bpy.types.Scene, 'quadpatches_props'):
            bpy.types.Scene.quadpatches_props = PointerProperty(type=QRPropertyGroup)
            _engine_owned.append('quadpatches_props')
        for c in classes:
            bpy.utils.register_class(c)
            registered.append(c)
        bpy.types.Scene.drimah_retopo = PointerProperty(type=DRIMAHRETOPO_Properties)
        _fast_remesher.register()
    except Exception:
        for c in reversed(registered):
            try: bpy.utils.unregister_class(c)
            except Exception: pass
        for owned in reversed(_engine_owned):
            try:
                if isinstance(owned, str): delattr(bpy.types.Scene, owned)
                else: bpy.utils.unregister_class(owned)
            except Exception: pass
        _engine_owned.clear()
        raise

def unregister():
    try:
        _fast_remesher.unregister()
    except Exception:
        pass
    if hasattr(bpy.types.Scene, 'drimah_retopo'):
        del bpy.types.Scene.drimah_retopo
    for c in reversed(classes):
        try: bpy.utils.unregister_class(c)
        except Exception: pass
    for owned in reversed(_engine_owned):
        try:
            if isinstance(owned, str): delattr(bpy.types.Scene, owned)
            else: bpy.utils.unregister_class(owned)
        except Exception: pass
    _engine_owned.clear()

if __name__ == '__main__':
    register()
